package cn.com.do1.component.convenience.house.vo;

import cn.com.do1.common.annotation.bean.FormatMask;
import cn.com.do1.common.framebase.dqdp.IBaseDBVO;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司
 * All rights reserved.
 * User: ${tempDataMap.user}
 */
public class TbYsjdHouseVO{

    private String id;


    private String houseNo;


    private String houseAddress;


    private String banName;


    private String houseNumber;


    private String propertyOwner;


    private String houseArea;


    private String purpose;


    private String situation;


    private String structure;


    private String banAddress;


    private String banNo;

    private String communityName;

    private String gridName;

    private String gridOperatorName;

    private String light;

    private String banId;


    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return this.id;
    }


    public void setHouseNo(String houseNo) {
        this.houseNo = houseNo;
    }

    public String getHouseNo() {
        return this.houseNo;
    }


    public void setHouseAddress(String houseAddress) {
        this.houseAddress = houseAddress;
    }

    public String getHouseAddress() {
        return this.houseAddress;
    }


    public void setBanName(String banName) {
        this.banName = banName;
    }

    public String getBanName() {
        return this.banName;
    }


    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getHouseNumber() {
        return this.houseNumber;
    }


    public void setPropertyOwner(String propertyOwner) {
        this.propertyOwner = propertyOwner;
    }

    public String getPropertyOwner() {
        return this.propertyOwner;
    }


    public void setHouseArea(String houseArea) {
        this.houseArea = houseArea;
    }

    public String getHouseArea() {
        return this.houseArea;
    }


    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getPurpose() {
        return this.purpose;
    }


    public void setSituation(String situation) {
        this.situation = situation;
    }

    public String getSituation() {
        return this.situation;
    }


    public void setStructure(String structure) {
        this.structure = structure;
    }

    public String getStructure() {
        return this.structure;
    }


    public String getBanAddress() {
        return banAddress;
    }

    public void setBanAddress(String banAddress) {
        this.banAddress = banAddress;
    }

    public void setBanNo(String banNo) {
        this.banNo = banNo;
    }

    public String getBanNo() {
        return this.banNo;
    }

    public String getCommunityName() {
        return communityName;
    }

    public void setCommunityName(String communityName) {
        this.communityName = communityName;
    }

    public String getGridName() {
        return gridName;
    }

    public void setGridName(String gridName) {
        this.gridName = gridName;
    }

    public String getGridOperatorName() {
        return gridOperatorName;
    }

    public void setGridOperatorName(String gridOperatorName) {
        this.gridOperatorName = gridOperatorName;
    }

    public String getLight() {
        return light;
    }

    public void setLight(String light) {
        this.light = light;
    }

    public String getBanId() {
        return banId;
    }

    public void setBanId(String banId) {
        this.banId = banId;
    }
}
