package cn.com.do1.component.reportdanger.reportdanger.vo;

import cn.com.do1.common.annotation.bean.FormatMask;
import cn.com.do1.common.framebase.dqdp.IBaseVO;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class TbYsjdDangerCommentVo implements Serializable, IBaseVO {
    private String commentId;
    private String reportdangerId;
    private String content;
    private String creator;

    @FormatMask(type = "date", value = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    private String status;
    private String time;
    private String personName;
    private String headPic;
    private String type;

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> _getTableNames() {
        return null;
    }

    public String getCommentId() {
        return this.commentId;
    }

    public void setCommentId(String commentId) {
        this.commentId = commentId;
    }

    public String getReportdangerId() {
        return reportdangerId;
    }

    public void setReportdangerId(String reportdangerId) {
        this.reportdangerId = reportdangerId;
    }

    public String getContent() {
        return this.content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreator() {
        return this.creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Date getCreateTime() {
        return this.createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPersonName() {
        return this.personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getHeadPic() {
        return this.headPic;
    }

    public void setHeadPic(String headPic) {
        this.headPic = headPic;
    }

    public String getTime() {
        return this.time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
