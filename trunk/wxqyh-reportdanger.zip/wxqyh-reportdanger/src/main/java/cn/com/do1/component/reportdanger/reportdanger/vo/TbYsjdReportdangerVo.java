package cn.com.do1.component.reportdanger.reportdanger.vo;

import java.util.Arrays;
import java.util.List;

import cn.com.do1.common.annotation.bean.DictDesc;
import cn.com.do1.common.annotation.bean.FormatMask;
import cn.com.do1.common.annotation.bean.PageView;
import cn.com.do1.common.annotation.bean.Validation;
import cn.com.do1.common.framebase.dqdp.IBaseVO;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司
 * All rights reserved.
 * User: zoulele
 */
public class TbYsjdReportdangerVo implements IBaseVO {
	private String id;

	@Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$", name = "community")
	@PageView(showType = "input", showOrder = 1, showName = "community", showLength = 36)
	private String community;
	
	private String communityName;

	@Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "theBan")
	@PageView(showType = "input", showOrder = 2, showName = "theBan", showLength = 100)
	private String theBan;

	@Validation(must = false, length = 50, fieldType = "pattern", regex = "^.*$", name = "address")
	@PageView(showType = "input", showOrder = 3, showName = "address", showLength = 50)
	private String address;

	@Validation(must = false, length = 500, fieldType = "pattern", regex = "^.*$", name = "describes")
	@PageView(showType = "input", showOrder = 4, showName = "describes", showLength = 500)
	private String describes;

	@Validation(must = false, length = 500, fieldType = "pattern", regex = "^.*$", name = "relatedPerson")
	@PageView(showType = "input", showOrder = 5, showName = "relatedPerson", showLength = 500)
	private String relatedPerson;

	@Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$", name = "creatorUser")
	@PageView(showType = "input", showOrder = 6, showName = "creatorUser", showLength = 36)
	private String creatorUser;

    @FormatMask(type = "date", value = "yyyy-MM-dd HH:mm")
	private String creatorTime;

	@Validation(must = false, length = 2, fieldType = "pattern", regex = "^.*$", name = "status")
	@PageView(showType = "input", showOrder = 8, showName = "status", showLength = 2)
	private String status;
	
	/**
     * 状态描述
     */
    @DictDesc(refField = "status", typeName = "reportdangerStatus")
	private String statusDesc;

	@Validation(must = false, length = 2, fieldType = "pattern", regex = "^.*$", name = "overtimeStatus")
	@PageView(showType = "input", showOrder = 9, showName = "overtimeStatus", showLength = 2)
	private String overtimeStatus;

	/**
     * 状态描述
     */
    @DictDesc(refField = "overtimeStatus", typeName = "overtimeStatusDesc")
	private String overtimeStatusDesc;
	
	@Validation(must = false, length = 2, fieldType = "pattern", regex = "^.*$", name = "lightStatus")
	@PageView(showType = "input", showOrder = 10, showName = "lightStatus", showLength = 2)
	private String lightStatus;
	/**
     * 状态描述
     */
    @DictDesc(refField = "lightStatus", typeName = "lightType")
    private String lightStatusDesc;

	@Validation(must = false, length = 500, fieldType = "pattern", regex = "^.*$", name = "result")
	@PageView(showType = "input", showOrder = 11, showName = "result", showLength = 500)
	private String result;

	@Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "dangerType")
	@PageView(showType = "input", showOrder = 12, showName = "dangerType", showLength = 100)
	private String dangerType;

    @FormatMask(type = "date", value = "yyyy-MM-dd HH:mm")
	private String reportTime;

    @FormatMask(type = "date", value = "yyyy-MM-dd HH:mm")
	private String handleTime;

	@Validation(must = false, length = 1000, fieldType = "pattern", regex = "^.*$", name = "approvers")
	@PageView(showType = "input", showOrder = 15, showName = "approvers", showLength = 1000)
	private String approvers;

	@Validation(must = false, length = 50, fieldType = "pattern", regex = "^.*$", name = "currentNode")
	@PageView(showType = "input", showOrder = 16, showName = "currentNode", showLength = 50)
	private String currentNode;

	@Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$", name = "currentNodeId")
	@PageView(showType = "input", showOrder = 17, showName = "currentNodeId", showLength = 36)
	private String currentNodeId;

	@Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "remark")
	@PageView(showType = "input", showOrder = 18, showName = "remark", showLength = 100)
	private String remark;

	@Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "theBanName")
    @PageView(showType = "input", showOrder = 2, showName = "theBanName", showLength = 100)
    private java.lang.String theBanName;
    @Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "remark")
    @PageView(showType = "input", showOrder = 18, showName = "handleUser", showLength = 100)
    private java.lang.String handleUser;
    
    private java.lang.String commentCount;
    @Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "title")
    @PageView(showType = "input", showOrder = 18, showName = "title", showLength = 100)
    private java.lang.String title;
    private java.lang.String reportType;
    private java.lang.String personName;
    private java.lang.String headPic;

	private List<String> tableNames;

	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return this.id;
	}

	public void setCommunity(String community) {
		this.community = community;
	}

	public String getCommunity() {
		return this.community;
	}

	public void setTheBan(String theBan) {
		this.theBan = theBan;
	}

	public String getTheBan() {
		return this.theBan;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress() {
		return this.address;
	}

	public void setDescribes(String describes) {
		this.describes = describes;
	}

	public String getDescribes() {
		return this.describes;
	}

	public void setRelatedPerson(String relatedPerson) {
		this.relatedPerson = relatedPerson;
	}

	public String getRelatedPerson() {
		return this.relatedPerson;
	}

	public void setCreatorUser(String creatorUser) {
		this.creatorUser = creatorUser;
	}

	public String getCreatorUser() {
		return this.creatorUser;
	}

	public void setCreatorTime(String creatorTime) {
		this.creatorTime = creatorTime;
	}

	public String getCreatorTime() {
		return this.creatorTime;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return this.status;
	}
	
	public String getStatusDesc() {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    public void setOvertimeStatus(String overtimeStatus) {
		this.overtimeStatus = overtimeStatus;
	}

	public String getOvertimeStatus() {
		return this.overtimeStatus;
	}

	public void setLightStatus(String lightStatus) {
		this.lightStatus = lightStatus;
	}

	public String getLightStatus() {
		return this.lightStatus;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getResult() {
		return this.result;
	}

	public void setDangerType(String dangerType) {
		this.dangerType = dangerType;
	}

	public String getDangerType() {
		return this.dangerType;
	}

	public void setReportTime(String reportTime) {
		this.reportTime = reportTime;
	}

	public String getReportTime() {
		return this.reportTime;
	}

	public void setHandleTime(String handleTime) {
		this.handleTime = handleTime;
	}

	public String getHandleTime() {
		return this.handleTime;
	}

	public void setApprovers(String approvers) {
		this.approvers = approvers;
	}

	public String getApprovers() {
		return this.approvers;
	}

	public void setCurrentNode(String currentNode) {
		this.currentNode = currentNode;
	}

	public String getCurrentNode() {
		return this.currentNode;
	}

	public void setCurrentNodeId(String currentNodeId) {
		this.currentNodeId = currentNodeId;
	}

	public String getCurrentNodeId() {
		return this.currentNodeId;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRemark() {
		return this.remark;
	}

	public java.lang.String getTheBanName() {
        return theBanName;
    }

    public void setTheBanName(java.lang.String theBanName) {
        this.theBanName = theBanName;
    }

    public java.lang.String getHandleUser() {
        return handleUser;
    }

    public void setHandleUser(java.lang.String handleUser) {
        this.handleUser = handleUser;
    }

    public java.lang.String getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(java.lang.String commentCount) {
        this.commentCount = commentCount;
    }

    public java.lang.String getTitle() {
        return title;
    }

    public void setTitle(java.lang.String title) {
        this.title = title;
    }

    public java.lang.String getReportType() {
        return reportType;
    }

    public void setReportType(java.lang.String reportType) {
        this.reportType = reportType;
    }

    public String getLightStatusDesc() {
        return lightStatusDesc;
    }

    public void setLightStatusDesc(String lightStatusDesc) {
        this.lightStatusDesc = lightStatusDesc;
    }
    
    
    public String getOvertimeStatusDesc() {
        return overtimeStatusDesc;
    }

    public void setOvertimeStatusDesc(String overtimeStatusDesc){
        this.overtimeStatusDesc = overtimeStatusDesc;
    }

    public java.lang.String getPersonName() {
        return personName;
    }

    public void setPersonName(java.lang.String personName) {
        this.personName = personName;
    }

    public java.lang.String getHeadPic() {
        return headPic;
    }

    public void setHeadPic(java.lang.String headPic) {
        this.headPic = headPic;
    }

    public String getCommunityName() {
        return communityName;
    }

    public void setCommunityName(String communityName) {
        this.communityName = communityName;
    }

    /**
	 * 获取数据库中对应的表名
	 * @return
	 */
	public List<String> _getTableNames() {
		if (tableNames == null || tableNames.isEmpty()) {
			tableNames = Arrays.asList("TB_YSJD_REPORTDANGER".split(","));
		}
		return tableNames;
	}
}
