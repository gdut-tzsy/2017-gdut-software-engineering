package cn.com.do1.component.reportdanger.reportdanger.model;

import cn.com.do1.common.annotation.bean.PageView;
import cn.com.do1.common.annotation.bean.Validation;
import cn.com.do1.common.framebase.dqdp.IBaseDBVO;
import cn.com.do1.common.util.reflation.ConvertUtil;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司 All rights reserved. User: zoulele
 */
public class TbYsjdReportdangerPo implements IBaseDBVO {

    private java.lang.String id;

    @Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$", name = "community")
    @PageView(showType = "input", showOrder = 1, showName = "community", showLength = 36)
    private java.lang.String community;

    @Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "theBan")
    @PageView(showType = "input", showOrder = 2, showName = "theBan", showLength = 100)
    private java.lang.String theBan;
    
    @Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "theBanName")
    @PageView(showType = "input", showOrder = 2, showName = "theBanName", showLength = 100)
    private java.lang.String theBanName;

    @Validation(must = false, length = 50, fieldType = "pattern", regex = "^.*$", name = "address")
    @PageView(showType = "input", showOrder = 3, showName = "address", showLength = 50)
    private java.lang.String address;

    @Validation(must = false, length = 500, fieldType = "pattern", regex = "^.*$", name = "describes")
    @PageView(showType = "input", showOrder = 4, showName = "describes", showLength = 500)
    private java.lang.String describes;

    @Validation(must = false, length = 500, fieldType = "pattern", regex = "^.*$", name = "relatedPerson")
    @PageView(showType = "input", showOrder = 5, showName = "relatedPerson", showLength = 500)
    private java.lang.String relatedPerson;

    @Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$", name = "creatorUser")
    @PageView(showType = "input", showOrder = 6, showName = "creatorUser", showLength = 36)
    private java.lang.String creatorUser;

    @Validation(must = false, length = 19, fieldType = "datetime", name = "creatorTime")
    @PageView(showType = "datetime", showOrder = 7, showName = "creatorTime", showLength = 19)
    private java.util.Date creatorTime;

    @Validation(must = false, length = 2, fieldType = "pattern", regex = "^.*$", name = "status")
    @PageView(showType = "input", showOrder = 8, showName = "status", showLength = 2)
    private java.lang.String status;

    @Validation(must = false, length = 2, fieldType = "pattern", regex = "^.*$", name = "overtimeStatus")
    @PageView(showType = "input", showOrder = 9, showName = "overtimeStatus", showLength = 2)
    private java.lang.String overtimeStatus;

    @Validation(must = false, length = 2, fieldType = "pattern", regex = "^.*$", name = "lightStatus")
    @PageView(showType = "input", showOrder = 10, showName = "lightStatus", showLength = 2)
    private java.lang.String lightStatus;

    @Validation(must = false, length = 500, fieldType = "pattern", regex = "^.*$", name = "result")
    @PageView(showType = "input", showOrder = 11, showName = "result", showLength = 500)
    private java.lang.String result;

    @Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "dangerType")
    @PageView(showType = "input", showOrder = 12, showName = "dangerType", showLength = 100)
    private java.lang.String dangerType;

    @Validation(must = false, length = 19, fieldType = "datetime", name = "reportTime")
    @PageView(showType = "datetime", showOrder = 13, showName = "reportTime", showLength = 19)
    private java.util.Date reportTime;

    @Validation(must = false, length = 19, fieldType = "datetime", name = "handleTime")
    @PageView(showType = "datetime", showOrder = 14, showName = "handleTime", showLength = 19)
    private java.util.Date handleTime;

    @Validation(must = false, length = 1000, fieldType = "pattern", regex = "^.*$", name = "approvers")
    @PageView(showType = "input", showOrder = 15, showName = "approvers", showLength = 1000)
    private java.lang.String approvers;

    @Validation(must = false, length = 50, fieldType = "pattern", regex = "^.*$", name = "currentNode")
    @PageView(showType = "input", showOrder = 16, showName = "currentNode", showLength = 50)
    private java.lang.String currentNode;

    @Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$", name = "currentNodeId")
    @PageView(showType = "input", showOrder = 17, showName = "currentNodeId", showLength = 36)
    private java.lang.String currentNodeId;

    @Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "remark")
    @PageView(showType = "input", showOrder = 18, showName = "remark", showLength = 100)
    private java.lang.String remark;
    
    @Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "remark")
    @PageView(showType = "input", showOrder = 18, showName = "handleUser", showLength = 100)
    private java.lang.String handleUser;
    
    @Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$", name = "handleUserId")
    @PageView(showType = "input", showOrder = 18, showName = "handleUserId", showLength = 36)
    private java.lang.String handleUserId;
    
    private Integer commentCount;
    
    @Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "title")
    @PageView(showType = "input", showOrder = 18, showName = "title", showLength = 100)
    private java.lang.String title;
    private java.lang.String reportType;
    public void setId(java.lang.String id) {
        this.id = id;
    }

    public java.lang.String getId() {
        return this.id;
    }

    public void setCommunity(java.lang.String community) {
        this.community = community;
    }

    public java.lang.String getCommunity() {
        return this.community;
    }

    public void setTheBan(java.lang.String theBan) {
        this.theBan = theBan;
    }

    public java.lang.String getTheBan() {
        return this.theBan;
    }

    public void setAddress(java.lang.String address) {
        this.address = address;
    }

    public java.lang.String getAddress() {
        return this.address;
    }

    public void setDescribes(java.lang.String describes) {
        this.describes = describes;
    }

    public java.lang.String getDescribes() {
        return this.describes;
    }

    public void setRelatedPerson(java.lang.String relatedPerson) {
        this.relatedPerson = relatedPerson;
    }

    public java.lang.String getRelatedPerson() {
        return this.relatedPerson;
    }

    public void setCreatorUser(java.lang.String creatorUser) {
        this.creatorUser = creatorUser;
    }

    public java.lang.String getCreatorUser() {
        return this.creatorUser;
    }

    public void setCreatorTime(java.util.Date creatorTime) {
        this.creatorTime = creatorTime;
    }

    public void setCreatorTime(java.lang.String creatorTime) {
        this.creatorTime = ConvertUtil.cvStUtildate(creatorTime);
    }

    public java.util.Date getCreatorTime() {
        return this.creatorTime;
    }

    public void setStatus(java.lang.String status) {
        this.status = status;
    }

    public java.lang.String getStatus() {
        return this.status;
    }

    public void setOvertimeStatus(java.lang.String overtimeStatus) {
        this.overtimeStatus = overtimeStatus;
    }

    public java.lang.String getOvertimeStatus() {
        return this.overtimeStatus;
    }

    public void setLightStatus(java.lang.String lightStatus) {
        this.lightStatus = lightStatus;
    }

    public java.lang.String getLightStatus() {
        return this.lightStatus;
    }

    public void setResult(java.lang.String result) {
        this.result = result;
    }

    public java.lang.String getResult() {
        return this.result;
    }

    public void setDangerType(java.lang.String dangerType) {
        this.dangerType = dangerType;
    }

    public java.lang.String getDangerType() {
        return this.dangerType;
    }

    public void setReportTime(java.util.Date reportTime) {
        this.reportTime = reportTime;
    }

    public void setReportTime(java.lang.String reportTime) {
        this.reportTime = ConvertUtil.cvStUtildate(reportTime);
    }

    public java.util.Date getReportTime() {
        return this.reportTime;
    }

    public void setHandleTime(java.util.Date handleTime) {
        this.handleTime = handleTime;
    }

    public void setHandleTime(java.lang.String handleTime) {
        this.handleTime = ConvertUtil.cvStUtildate(handleTime);
    }

    public java.util.Date getHandleTime() {
        return this.handleTime;
    }

    public void setApprovers(java.lang.String approvers) {
        this.approvers = approvers;
    }

    public java.lang.String getApprovers() {
        return this.approvers;
    }

    public void setCurrentNode(java.lang.String currentNode) {
        this.currentNode = currentNode;
    }

    public java.lang.String getCurrentNode() {
        return this.currentNode;
    }

    public void setCurrentNodeId(java.lang.String currentNodeId) {
        this.currentNodeId = currentNodeId;
    }

    public java.lang.String getCurrentNodeId() {
        return this.currentNodeId;
    }

    public void setRemark(java.lang.String remark) {
        this.remark = remark;
    }

    public java.lang.String getRemark() {
        return this.remark;
    }

    public java.lang.String getHandleUserId() {
        return handleUserId;
    }

    public void setHandleUserId(java.lang.String handleUserId) {
        this.handleUserId = handleUserId;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public java.lang.String getHandleUser() {
        return handleUser;
    }

    public void setHandleUser(java.lang.String handleUser) {
        this.handleUser = handleUser;
    }
    

    public java.lang.String getTheBanName() {
        return theBanName;
    }

    public void setTheBanName(java.lang.String theBanName) {
        this.theBanName = theBanName;
    }

    public java.lang.String getTitle() {
        return title;
    }

    public void setTitle(java.lang.String title) {
        this.title = title;
    }
    
    

    public java.lang.String getReportType() {
        return reportType;
    }

    public void setReportType(java.lang.String reportType) {
        this.reportType = reportType;
    }

    
    
    /**
     * 获取数据库中对应的表名
     * 
     * @return
     */
    public String _getTableName() {
        return "tb_ysjd_reportdanger";
    }

    /**
     * 获取对应表的主键字段名称
     * 
     * @return
     */
    public String _getPKColumnName() {
        return "id";
    }

    /**
     * 获取主键值
     * 
     * @return
     */
    public String _getPKValue() {
        return String.valueOf(id);
    }

    /**
     * 设置主键的值
     * 
     * @return
     */
    public void _setPKValue(Object value) {
        this.id = (java.lang.String) value;
    }
}
