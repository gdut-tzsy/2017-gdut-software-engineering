package cn.com.do1.component.reportdanger.reportdanger.model;

import cn.com.do1.common.annotation.bean.PageView;
import cn.com.do1.common.annotation.bean.Validation;
import cn.com.do1.common.framebase.dqdp.IBaseDBVO;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司 All rights reserved. User: zoulele
 */
public class TbYsjdApprovalPo implements IBaseDBVO {

    private java.lang.String id;
    @Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$", name = "reportdangerId")
    @PageView(showType = "input", showOrder = 1, showName = "reportdangerId", showLength = 36)
    private java.lang.String reportdangerId;

    @Validation(must = false, length = 50, fieldType = "pattern", regex = "^.*$", name = "approvalName")
    @PageView(showType = "input", showOrder = 2, showName = "approvalName", showLength = 50)
    private java.lang.String approvalName;
    
    @Validation(must = false, length = 200, fieldType = "pattern", regex = "^.*$", name = "describes")
    @PageView(showType = "input", showOrder = 4, showName = "describes", showLength = 200)
    private java.lang.String describes;

    @Validation(must = false, length = 1000, fieldType = "pattern", regex = "^.*$", name = "userId")
    @PageView(showType = "input", showOrder = 3, showName = "userId", showLength = 1000)
    private java.lang.String userId;

    @Validation(must = false, length = 1000, fieldType = "pattern", regex = "^.*$", name = "wxUserId")
    @PageView(showType = "input", showOrder = 3, showName = "wxUserId", showLength = 1000)
    private java.lang.String wxUserId;

    @Validation(must = false, length = 36, fieldType = "pattern", regex = "^\\\\d*$", name = "createUser")
    @PageView(showType = "input", showOrder = 5, showName = "createUser", showLength = 36)
    private java.lang.String createUser;

    @Validation(must=false, length=19, fieldType = "datetime", name ="creatorTime") 
    @PageView(showType = "datetime", showOrder = 3, showName ="createTime", showLength=19) 
    private java.util.Date createTime;
    
    @Validation(must=false, length=19, fieldType = "datetime", name ="updateTime") 
    @PageView(showType = "datetime", showOrder = 3, showName ="updateTime", showLength=19) 
    private java.util.Date updateTime;
    
    @Validation(must = false, length = 8, fieldType = "pattern", regex = "^.*$")
    @PageView(showName = "status", showType = "input", showOrder = 5, showLength = 8)
    private String status;
    
    @Validation(must = false, length = 11, fieldType = "pattern", regex = "^\\\\d*$", name = "sort")
    @PageView(showType = "input", showOrder = 4, showName = "sort", showLength = 11)
    private java.lang.Integer sort;

    @Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "remarks")
    @PageView(showType = "input", showOrder = 5, showName = "remarks", showLength = 100)
    private java.lang.String remarks;
    
    

    public void setId(java.lang.String id) {
        this.id = id;
    }

    public java.lang.String getId() {
        return this.id;
    }

  

    public java.lang.String getReportdangerId() {
        return reportdangerId;
    }

    public void setReportdangerId(java.lang.String reportdangerId) {
        this.reportdangerId = reportdangerId;
    }

    public java.lang.String getApprovalName() {
        return approvalName;
    }

    public void setApprovalName(java.lang.String approvalName) {
        this.approvalName = approvalName;
    }

    public java.lang.String getDescribes() {
        return describes;
    }

    public void setDescribes(java.lang.String describes) {
        this.describes = describes;
    }

    public java.lang.String getUserId() {
        return userId;
    }

    public void setUserId(java.lang.String userId) {
        this.userId = userId;
    }

    public java.lang.String getWxUserId() {
        return wxUserId;
    }

    public void setWxUserId(java.lang.String wxUserId) {
        this.wxUserId = wxUserId;
    }


    public java.util.Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(java.util.Date createTime) {
        this.createTime = createTime;
    }

    public java.util.Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(java.util.Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public java.lang.Integer getSort() {
        return sort;
    }

    public void setSort(java.lang.Integer sort) {
        this.sort = sort;
    }

    public java.lang.String getRemarks() {
        return remarks;
    }

    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }

    

    public java.lang.String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(java.lang.String createUser) {
        this.createUser = createUser;
    }

    /**
     * 获取数据库中对应的表名
     * 
     * @return
     */
    public String _getTableName() {
        return "tb_ysjd_approval";
    }

    /**
     * 获取对应表的主键字段名称
     * 
     * @return
     */
    public String _getPKColumnName() {
        return "id";
    }

    /**
     * 获取主键值
     * 
     * @return
     */
    public String _getPKValue() {
        return String.valueOf(id);
    }

    /**
     * 设置主键的值
     * 
     * @return
     */
    public void _setPKValue(Object value) {
        this.id = (java.lang.String) value;
    }
}
