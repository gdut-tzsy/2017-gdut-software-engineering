package cn.com.do1.component.reportdanger.reportdanger.model;

import cn.com.do1.common.annotation.bean.PageView;
import cn.com.do1.common.annotation.bean.Validation;
import cn.com.do1.common.framebase.dqdp.IBaseDBVO;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司 All rights reserved. User: zoulele
 */
public class TbYsjdCommunityUserPo implements IBaseDBVO {

    /**
     * <p>Field id: 主键</p>
     */
    private java.lang.String id;

    /**
     * <p>Field dangerId: 隐患描述ID</p>
     */
    @Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$", name = "dangerId")
    @PageView(showType = "input", showOrder = 1, showName = "dangerId", showLength = 36)
    private java.lang.String dangerId;

    /**
     * <p>Field communityId: 社区ID</p>
     */
    @Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$", name = "communityId")
    @PageView(showType = "input", showOrder = 2, showName = "communityId", showLength = 36)
    private java.lang.String communityId;

    /**
     * <p>Field userId: 负责人ID</p>
     */
    @Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$", name = "userId")
    @PageView(showType = "input", showOrder = 3, showName = "userId", showLength = 36)
    private java.lang.String userId;

    /**
     * <p>Field userName: 负责人姓名</p>
     */
    @Validation(must = false, length = 20, fieldType = "pattern", regex = "^.*$", name = "userName")
    @PageView(showType = "input", showOrder = 4, showName = "userName", showLength = 20)
    private java.lang.String userName;

    /**
     * <p>Field headPic: 负责人头像</p>
     */
    @Validation(must = false, length = 200, fieldType = "pattern", regex = "^.*$", name = "headPic")
    @PageView(showType = "input", showOrder = 5, showName = "headPic", showLength = 200)
    private java.lang.String headPic;

    /**
     * <p>Field wxUserId: 负责人wx_user_id</p>
     */
    @Validation(must = false, length = 50, fieldType = "pattern", regex = "^.*$", name = "wxUserId")
    @PageView(showType = "input", showOrder = 6, showName = "wxUserId", showLength = 50)
    private java.lang.String wxUserId;

    public java.lang.String getId() {
        return this.id;
    }

    public void setId(java.lang.String id) {
        this.id = id;
    }

    public java.lang.String getDangerId() {
        return this.dangerId;
    }

    public void setDangerId(java.lang.String dangerId) {
        this.dangerId = dangerId;
    }

    public java.lang.String getCommunityId() {
        return this.communityId;
    }

    public void setCommunityId(java.lang.String communityId) {
        this.communityId = communityId;
    }

    public java.lang.String getUserId() {
        return this.userId;
    }

    public void setUserId(java.lang.String userId) {
        this.userId = userId;
    }

    public java.lang.String getUserName() {
        return this.userName;
    }

    public void setUserName(java.lang.String userName) {
        this.userName = userName;
    }

    public java.lang.String getHeadPic() {
        return this.headPic;
    }

    public void setHeadPic(java.lang.String headPic) {
        this.headPic = headPic;
    }

    public java.lang.String getWxUserId() {
        return this.wxUserId;
    }

    public void setWxUserId(java.lang.String wxUserId) {
        this.wxUserId = wxUserId;
    }

    /**
     * 获取数据库中对应的表名
     * 
     * @return
     */
    public String _getTableName() {
        return "tb_ysjd_community_user";
    }

    /**
     * 获取对应表的主键字段名称
     * 
     * @return
     */
    public String _getPKColumnName() {
        return "id";
    }

    /**
     * 获取主键值
     * 
     * @return
     */
    public String _getPKValue() {
        return String.valueOf(id);
    }

    /**
     * 设置主键的值
     * 
     * @return
     */
    public void _setPKValue(Object value) {
        this.id = (java.lang.String) value;
    }
}
