package cn.com.do1.component.reportdanger.reportdanger.dao.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.do1.common.dac.Pager;
import cn.com.do1.common.exception.BaseException;
import cn.com.do1.common.framebase.dqdp.BaseDAOImpl;
import cn.com.do1.component.reportdanger.reportdanger.dao.IDangerDescribeDao;
import cn.com.do1.component.reportdanger.reportdanger.vo.CommunityVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdCommunityUserVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdDangerVo;

public class DangerDescribeDaoImpl extends BaseDAOImpl implements IDangerDescribeDao {
    private final static transient Logger logger = LoggerFactory.getLogger(DangerDescribeDaoImpl.class);

    /**
     * <p>Title: searchTbYsjdDangerPO</p>
     * <p>Description: 分页查询隐患描述</p>
     * @param searchMap 条件
     * @param pager 分页
     * @return Pager 隐患描述信息
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     * @see cn.com.do1.component.reportdanger.reportdanger.dao.IDangerDescribeDao#searchTbYsjdDangerPO(java.util.Map, cn.com.do1.common.dac.Pager)
     */
    @Override
    public Pager searchTbYsjdDangerPO(Map<String, Object> searchMap, Pager pager) throws Exception, BaseException {
        String searchSQL = "SELECT * FROM tb_ysjd_danger "
                + " ORDER BY IF(ISNULL(sort),1,0) ,sort,creator_time DESC ";
        String countSQL = "select count(1) from (" + searchSQL.replaceAll("(?i)\\basc\\b|\\bdesc\\b", "").replaceAll("(?i)order\\s+by\\s+\\S+(\\s*[,\\s*\\S+])*", "")+"  ) a ";
        return super.pageSearchByField(TbYsjdDangerVo.class, countSQL, searchSQL, searchMap, pager);
    }

    /**
     * <p>Title: deleteCommunityByDangerId</p>
     * <p>Description: 根据隐患描述id删除负责人</p>
     * @param id 隐患描述id
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     * @see cn.com.do1.component.reportdanger.reportdanger.dao.IDangerDescribeDao#deleteCommunityByDangerId(java.lang.String)
     */
    @Override
    public void deleteCommunityByDangerId(String id) throws Exception, BaseException {
        String sql ="DELETE FROM tb_ysjd_community_user WHERE danger_id = :id ";
        this.preparedSql(sql);
        this.setPreValue("id", id);
        this.executeUpdate();
    }
    
    /**
     * <p>Title: getCommunity</p>
     * <p>Description: 查询社区</p>
     * @param depIdSys 社区节点id
     * @return List 社区名称
     * @throws SQLException SQLException异常
     * @see cn.com.do1.component.building.building.dao.IBuildingDAO#getCommunity(java.lang.String)
     */
    @Override
    public List<CommunityVo> getCommunity(String depIdSys) throws SQLException {
        String sql = "SELECT a.id,a.department_name FROM tb_department_info a WHERE a.parent_depart = :depIdSys ORDER BY a.show_order ";
        this.preparedSql(sql);
        this.setPreValue("depIdSys", depIdSys);
        return getList(CommunityVo.class);
    }

    @Override
    public List<TbYsjdCommunityUserVo> getCommunityUserByComIdAndDesId(String id, String communityId) throws Exception,
            BaseException {
        String sql = "SELECT a.* FROM tb_ysjd_community_user a WHERE a.danger_id = :id AND a.community_id = :communityId ";
        this.preparedSql(sql);
        this.setPreValue("id", id);
        this.setPreValue("communityId", communityId);
        return getList(TbYsjdCommunityUserVo.class);
    }
}
