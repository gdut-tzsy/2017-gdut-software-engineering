package cn.com.do1.component.reportdanger.reportdanger.ui;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.do1.common.annotation.struts.CatchException;
import cn.com.do1.common.annotation.struts.JSONOut;
import cn.com.do1.common.dac.Pager;
import cn.com.do1.common.exception.BaseException;
import cn.com.do1.common.framebase.struts.BaseAction;
import cn.com.do1.component.addressbook.contact.service.IContactService;
import cn.com.do1.component.addressbook.contact.vo.UserOrgVO;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdDangerPO;
import cn.com.do1.component.reportdanger.reportdanger.service.IDangerDescribeService;
import cn.com.do1.component.reportdanger.reportdanger.vo.CommunityVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdCommunityUserVo;
import cn.com.do1.dqdp.core.ConfigMgr;
import cn.com.do1.dqdp.core.DqdpAppContext;
import cn.com.do1.dqdp.core.permission.IUser;

public class DangerDescribeAction extends BaseAction {
    private final static transient Logger logger = LoggerFactory.getLogger(DangerDescribeAction.class);
    /**
     * <p>Field ids: 接收的id集合</p>
     */
    private String[] ids;
    /**
     * <p>Field id: 接收的id</p>
     */
    private String id;
    /**
     * <p>Field tbYsjdDangerPO: 隐患描述po</p>
     */
    private TbYsjdDangerPO tbYsjdDangerPO;
    
    public String[] getIds() {
        return this.ids;
    }
    public void setIds(String[] ids) {
        this.ids = ids;
    }
    public String getId() {
        return this.id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public TbYsjdDangerPO getTbYsjdDangerPO() {
        return this.tbYsjdDangerPO;
    }
    public void setTbYsjdDangerPO(TbYsjdDangerPO tbYsjdDangerPO) {
        this.tbYsjdDangerPO = tbYsjdDangerPO;
    }

    /**
     * <p>Field contactService: contactService接口</p>
     */
    @Resource
    private IContactService contactService;
    
    /**
     * <p>Field dangerDescribeService: dangerDescribeService接口</p>
     */
    @Resource
    private IDangerDescribeService dangerDescribeService;
    
    /**
     * <p>Description: 分页查询隐患描述</p>
     * @param searchMap 条件
     * @param pager 分页
     * @return Pager 隐患描述信息
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     */
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "查询成功", faileMsg = "查询失败"))
    public void ajaxSearch() throws Exception, BaseException {
        Pager pager = new Pager(ServletActionContext.getRequest(), getPageSize());
        IUser user = (IUser) DqdpAppContext.getCurrentUser();
        String userId = user.getUsername();
        UserOrgVO userInfoVo = this.contactService.getOrgByUserId(userId);
        if (userInfoVo == null) {
            throw new BaseException("登录人的信息为空");
        }
        Map<String, Object> searchMap = getSearchValue();
        pager = this.dangerDescribeService.searchTbYsjdDangerPO(searchMap, pager);
        addJsonPager("pageData", pager);
    }
    
    /**
     * <p>Description: 批量删除</p>
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     */
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "查询成功", faileMsg = "查询失败"))
    public void batchDeleteDescribe() throws Exception, BaseException {
        IUser user = (IUser) DqdpAppContext.getCurrentUser();
        String userName = user.getUsername();
        UserOrgVO userOrgVO = this.contactService.getOrgByUserId(userName);
        if(userOrgVO == null){
            setActionResult("1001","登录人信息为空，请重新登录！");
            return ;
        }
        String msg= this.dangerDescribeService.batchDeleteDescribe(ids);
        setActionResult("0",msg);
    }
    
    /**
     * <p>Description: 查询社区</p>
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     */
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "查询成功", faileMsg = "查询失败"))
    public void getCommunity() throws Exception, BaseException {
        String depIdSys = ConfigMgr.get("building", "depIdSys", "");
        List<CommunityVo> list = this.dangerDescribeService.getCommunity(depIdSys);
        addJsonArray("communityList", list);
    }
    
    /**
     * <p>Description: 新增隐患描述</p>
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     */
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "保存成功", faileMsg = "保存失败"))
    public void addTbYsjdDangerPO() throws Exception, BaseException {
        IUser user = (IUser) DqdpAppContext.getCurrentUser();
        String userName = user.getUsername();
        UserOrgVO userOrgVO = this.contactService.getOrgByUserId(userName);
        if(userOrgVO == null){
            setActionResult("1001","登录人信息为空，请重新登录！");
            return ;
        }
        HttpServletRequest request = ServletActionContext.getRequest();
        String describejson = request.getParameter("describejson");
        this.dangerDescribeService.addTbYsjdDangerPO(this.tbYsjdDangerPO,describejson);
    }
    
    /**
     * <p>Description: 新增隐患描述</p>
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     */
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "保存成功", faileMsg = "保存失败"))
    public void updateTbYsjdDangerPO() throws Exception, BaseException {
        IUser user = (IUser) DqdpAppContext.getCurrentUser();
        String userName = user.getUsername();
        UserOrgVO userOrgVO = this.contactService.getOrgByUserId(userName);
        if(userOrgVO == null){
            setActionResult("1001","登录人信息为空，请重新登录！");
            return ;
        }
        HttpServletRequest request = ServletActionContext.getRequest();
        String describejson = request.getParameter("describejson");
        String id = request.getParameter("id");
        this.dangerDescribeService.updateTbYsjdDangerPO(this.tbYsjdDangerPO,describejson,id);
    }
    
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "查询成功", faileMsg = "查询失败"))
    public void getDanger() throws Exception, BaseException {
        IUser user = (IUser) DqdpAppContext.getCurrentUser();
        String userName = user.getUsername();
        UserOrgVO userOrgVO = this.contactService.getOrgByUserId(userName);
        if(userOrgVO == null){
            setActionResult("1001","登录人信息为空，请重新登录！");
            return ;
        }
        HttpServletRequest request = ServletActionContext.getRequest();
        String id = request.getParameter("id");
        TbYsjdDangerPO po = this.dangerDescribeService.searchByPk(TbYsjdDangerPO.class, id);
        String depIdSys = ConfigMgr.get("building", "depIdSys", "");
        List<CommunityVo> list = this.dangerDescribeService.getCommunity(depIdSys);
        for (int i = 0; i < list.size(); i++) {
            String communityId = list.get(i).getId();
            List<TbYsjdCommunityUserVo> vo = this.dangerDescribeService.getCommunityUserByComIdAndDesId(id,communityId);
            CommunityVo cvo = list.get(i);
            cvo.setToPersons(vo);
        }
        addJsonArray("communityList", list);
        addJsonFormateObj("tbYsjdDangerPO", po);
    }
}
