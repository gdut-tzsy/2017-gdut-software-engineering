package cn.com.do1.component.reportdanger.reportdanger.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.do1.common.annotation.reger.ProcesserUnit;
import cn.com.do1.component.report.report.vo.ReportTaskVO;
import cn.com.do1.component.wxqyh.task.IReportExt;

@ProcesserUnit(name = "dangerReport")
public class DangerReport implements IReportExt {
    private static final transient Logger logger = LoggerFactory.getLogger(DangerReport.class);
    @Override
    public void doSome(ReportTaskVO report) {
        String type = report.getReportType();
        logger.info("=======================================隐患管理导出："+type);
        //整治情况统计表
        if("dangerReport".equals(type)){//整治情况统计表
            logger.info("=======================================整治情况统计表");
            DangerUtil.exportDanger(report);
        }else if("dangerSummary".equals(type)){//整治情况汇总表 
            logger.info("=======================================整治情况汇总表 ");
            DangerUtil.exportSummaryDanger(report);
        }
    }
}
