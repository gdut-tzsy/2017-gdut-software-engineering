package cn.com.do1.component.reportdanger.reportdanger.service.impl;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.com.do1.common.dac.Pager;
import cn.com.do1.common.exception.BaseException;
import cn.com.do1.common.framebase.dqdp.BaseService;
import cn.com.do1.common.util.AssertUtil;
import cn.com.do1.component.addressbook.contact.service.IContactService;
import cn.com.do1.component.addressbook.contact.vo.UserRedundancyInfoVO;
import cn.com.do1.component.reportdanger.reportdanger.dao.IDangerDescribeDao;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdCommunityUserPo;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdDangerPO;
import cn.com.do1.component.reportdanger.reportdanger.service.IDangerDescribeService;
import cn.com.do1.component.reportdanger.reportdanger.vo.CommunityVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdCommunityUserVo;

/**
* Copyright &copy; 2010 广州市道一信息技术有限公司
* All rights reserved.
* User: cuijianpeng
*/
@Service("dangerDescribeService")
public class DangerDescribeServiceImpl extends BaseService implements IDangerDescribeService {
    private final static transient Logger logger = LoggerFactory.getLogger(DangerDescribeServiceImpl .class);
    
    private IDangerDescribeDao dangerDescribeDao;
    
    private IContactService contactService;
    
    @Resource
    public void setDangerDescribeDao(IDangerDescribeDao dangerDescribeDao) {
        this.dangerDescribeDao = dangerDescribeDao;
        setDAO(dangerDescribeDao);
    }

    @Resource(name = "contactService")
    public void setContactService(IContactService contactService) {
        this.contactService = contactService;
    }
    
    /**
     * <p>Title: searchTbYsjdDangerPO</p>
     * <p>Description: 分页查询隐患描述</p>
     * @param searchMap 条件
     * @param pager 分页
     * @return Pager 隐患描述信息
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     * @see cn.com.do1.component.reportdanger.reportdanger.service.IDangerDescribeService#searchTbYsjdDangerPO(java.util.Map, cn.com.do1.common.dac.Pager)
     */
    @Override
    public Pager searchTbYsjdDangerPO(Map<String, Object> searchMap, Pager pager) throws Exception, BaseException {
        return this.dangerDescribeDao .searchTbYsjdDangerPO(searchMap, pager);
    }

    /**
     * <p>Description: 批量删除</p>
     * @param ids id集合
     * @return String 信息
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     * @see cn.com.do1.component.reportdanger.reportdanger.service.IDangerDescribeService#batchDeleteDescribe(java.lang.String[])
     */
    @Override
    public String batchDeleteDescribe(String[] ids) throws Exception, BaseException {
        StringBuilder rMsg=new StringBuilder("");
        if (ids != null && ids.length > 0){ 
            rMsg.append("");
            List<String> list=Arrays.asList(ids);
            TbYsjdDangerPO po;
            int failCount=0;
            for (String id : list) {
                po= this.searchByPk(TbYsjdDangerPO.class, id);
                if(po==null){
                    rMsg.append(id+":不存在;");
                    failCount=failCount+1;
                    continue;
                }
                this.dangerDescribeDao.deleteCommunityByDangerId(id);
                this.dangerDescribeDao.delete(po);
            }
            if(failCount==0){
                rMsg.append("删除成功");
            }
        }else{
            rMsg.append("没有可删除的数据!");
        }
        return rMsg.toString();
    }

    /**
     * <p>Description: 查询社区</p>
     * @param depIdSys 社区节点id
     * @return List 社区名称
     * @throws SQLException SQLException异常
     * @see cn.com.do1.component.building.building.service.IBuildingService#getCommunity(java.lang.String)
     */
    @Override
    public List<CommunityVo> getCommunity(String depIdSys) throws SQLException {
        return this.dangerDescribeDao.getCommunity(depIdSys);
    }

    /**
     * <p>Title: addTbYsjdDangerPO</p>
     * <p>Description: 新增隐患描述</p>
     * @param tbYsjdDangerPO 隐患描述po
     * @param describejson 负责人json
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     * @see cn.com.do1.component.reportdanger.reportdanger.service.IDangerDescribeService#addTbYsjdDangerPO(cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdDangerPO, java.lang.String)
     */
    @Override
    public void addTbYsjdDangerPO(TbYsjdDangerPO tbYsjdDangerPO, String describejson) throws Exception, BaseException {
        String dangerId = UUID.randomUUID().toString();
        tbYsjdDangerPO.setId(dangerId);
        tbYsjdDangerPO.setCreatorTime(new Date());
        this.dangerDescribeDao.insert(tbYsjdDangerPO);
        describejson = describejson.replaceAll("\n", "\\\\n");
        JSONArray new_jsonArray=JSONArray.fromObject(describejson);
        Collection java_collection=JSONArray.toCollection(new_jsonArray); 
        if (java_collection!=null && !java_collection.isEmpty()) {  
            Iterator it=java_collection.iterator();  
            while (it.hasNext()) {
                JSONObject jsonObj=JSONObject.fromObject(it.next());
                String userIds=jsonObj.getString("userIds"); //负责人
                String community=jsonObj.getString("community"); //社区id
                String[] personlist = userIds.split(",");
                for (int i = 0; i < personlist.length; i++) {
                    String userId = personlist[i].trim();
                    personlist[i] = userId;
                }
                List<UserRedundancyInfoVO> userList = this.contactService.getUserRedundancySortListByUserId(personlist);
                if ((null != userList) && (userList.size() > 0)) {
                    for (UserRedundancyInfoVO userRedundancyInfoVO : userList) {
                        TbYsjdCommunityUserPo po = new TbYsjdCommunityUserPo();
                        po.setId(UUID.randomUUID().toString());
                        po.setDangerId(dangerId);
                        po.setCommunityId(community);
                        po.setUserId(userRedundancyInfoVO.getUserId());
                        po.setUserName(userRedundancyInfoVO.getPersonName());
                        po.setHeadPic(userRedundancyInfoVO.getHeadPic());
                        po.setWxUserId(userRedundancyInfoVO.getWxUserId());
                        this.dangerDescribeDao.insert(po);
                    }
                }
            }
        }
    }

    /**
     * <p>Title: getCommunityUserByComIdAndDesId</p>
     * <p>Description: 查询负责人</p>
     * @param id 隐患描述id
     * @param communityId 社区id
     * @return List 负责人list
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     * @see cn.com.do1.component.reportdanger.reportdanger.service.IDangerDescribeService#getCommunityUserByComIdAndDesId(java.lang.String, java.lang.String)
     */
    @Override
    public List<TbYsjdCommunityUserVo> getCommunityUserByComIdAndDesId(String id, String communityId) throws Exception,
            BaseException {
        return this.dangerDescribeDao.getCommunityUserByComIdAndDesId(id, communityId);
    }

    /**
     * <p>Title: updateTbYsjdDangerPO</p>
     * <p>Description: 更新隐患描述</p>
     * @param tbYsjdDangerPO 隐患描述po
     * @param describejson 负责人json
     * @param id 隐患描述id
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     * @see cn.com.do1.component.reportdanger.reportdanger.service.IDangerDescribeService#updateTbYsjdDangerPO(cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdDangerPO, java.lang.String, java.lang.String)
     */
    @Override
    public void updateTbYsjdDangerPO(TbYsjdDangerPO tbYsjdDangerPO, String describejson, String id) throws Exception, BaseException {
        tbYsjdDangerPO.setId(id);
        tbYsjdDangerPO.setCreatorTime(new Date());
        this.dangerDescribeDao.update(tbYsjdDangerPO, false);
        this.dangerDescribeDao.deleteCommunityByDangerId(id);
        if ("2".equals(tbYsjdDangerPO.getLightStatus())) {
            describejson = describejson.replaceAll("\n", "\\\\n");
            JSONArray new_jsonArray=JSONArray.fromObject(describejson);
            Collection java_collection=JSONArray.toCollection(new_jsonArray); 
            if (java_collection!=null && !java_collection.isEmpty()) {  
                Iterator it=java_collection.iterator();  
                while (it.hasNext()) {
                    JSONObject jsonObj=JSONObject.fromObject(it.next());
                    String userIds=jsonObj.getString("userIds"); //负责人
                    String community=jsonObj.getString("community"); //社区id
                    String[] personlist = userIds.split(",");
                    for (int i = 0; i < personlist.length; i++) {
                        String userId = personlist[i].trim();
                        personlist[i] = userId;
                    }
                    List<UserRedundancyInfoVO> userList = this.contactService.getUserRedundancySortListByUserId(personlist);
                    if ((null != userList) && (userList.size() > 0)) {
                        for (UserRedundancyInfoVO userRedundancyInfoVO : userList) {
                            TbYsjdCommunityUserPo po = new TbYsjdCommunityUserPo();
                            po.setId(UUID.randomUUID().toString());
                            po.setDangerId(id);
                            po.setCommunityId(community);
                            po.setUserId(userRedundancyInfoVO.getUserId());
                            po.setUserName(userRedundancyInfoVO.getPersonName());
                            po.setHeadPic(userRedundancyInfoVO.getHeadPic());
                            po.setWxUserId(userRedundancyInfoVO.getWxUserId());
                            this.dangerDescribeDao.insert(po);
                        }
                    }
                }
            }
        }
    }
}
