package cn.com.do1.component.reportdanger.reportdanger.model;

import cn.com.do1.common.framebase.dqdp.IBaseDBVO;
import cn.com.do1.common.util.reflation.ConvertUtil;
import cn.com.do1.common.annotation.bean.PageView;
import cn.com.do1.common.annotation.bean.Validation;
import cn.com.do1.common.annotation.bean.DictDesc;
import cn.com.do1.common.annotation.bean.FormatMask;
import java.util.Date;
import oracle.sql.TIMESTAMP;

/**
* Copyright &copy; 2010 广州市道一信息技术有限公司
* All rights reserved.
* User: zoulele
*/
public class TbYsjdDangerPO implements IBaseDBVO {

	    private java.lang.String id;
    
    
						@Validation(must=false, length=36, fieldType = "pattern",  regex = "^.*$", name ="danger") 
@PageView(showType = "input", showOrder = 1, showName ="danger", showLength=36) 

			    private java.lang.String danger;
    
    
						@Validation(must=false, length=2, fieldType = "pattern",  regex = "^.*$", name ="lightStatus") 
@PageView(showType = "input", showOrder = 2, showName ="lightStatus", showLength=2) 

			    private java.lang.String lightStatus;
    
    
						@Validation(must=false, length=19, fieldType = "datetime", name ="creatorTime") 
@PageView(showType = "datetime", showOrder = 3, showName ="creatorTime", showLength=19) 

			    private java.util.Date creatorTime;
    
    
						@Validation(must=false, length=11, fieldType = "pattern",  regex = "^\\\\d*$", name ="sort") 
@PageView(showType = "input", showOrder = 4, showName ="sort", showLength=11) 

			    private java.lang.Integer sort;
    
    
						@Validation(must=false, length=100, fieldType = "pattern",  regex = "^.*$", name ="remark") 
@PageView(showType = "input", showOrder = 5, showName ="remark", showLength=100) 

			    private java.lang.String remark;
						
						@Validation(must=false, length=100, fieldType = "pattern",  regex = "^.*$", name ="regulationDepart") 
@PageView(showType = "input", showOrder = 6, showName ="regulationDepart", showLength=100) 
						
				private java.lang.String regulationDepart;
    
    


    public void setId(java.lang.String id){
        this.id=id;
    }
						
    public java.lang.String getId(){
        return this.id;
    }
    

    public void setDanger(java.lang.String danger){
        this.danger=danger;
    }
						
    public java.lang.String getDanger(){
        return this.danger;
    }
    

    public void setLightStatus(java.lang.String lightStatus){
        this.lightStatus=lightStatus;
    }
						
    public java.lang.String getLightStatus(){
        return this.lightStatus;
    }
    

    public void setCreatorTime(java.util.Date creatorTime){
        this.creatorTime=creatorTime;
    }
	    public void setCreatorTime(java.lang.String creatorTime){
       this.creatorTime=ConvertUtil.cvStUtildate(creatorTime);
    }
						
    public java.util.Date getCreatorTime(){
        return this.creatorTime;
    }
    

    public void setSort(java.lang.Integer sort){
        this.sort=sort;
    }
			    public void setSort(java.lang.String sort){
       this.sort=ConvertUtil.cvStIntg(sort);
    }
				
    public java.lang.Integer getSort(){
        return this.sort;
    }
    

    public void setRemark(java.lang.String remark){
        this.remark=remark;
    }
						
    public java.lang.String getRemark(){
        return this.remark;
    }
    

    public java.lang.String getRegulationDepart() {
        return this.regulationDepart;
    }

    public void setRegulationDepart(java.lang.String regulationDepart) {
        this.regulationDepart = regulationDepart;
    }

    /**
    * 获取数据库中对应的表名
    *
    * @return
    */
    public String _getTableName() {
        return "tb_ysjd_danger";
    }

    /**
    * 获取对应表的主键字段名称
    *
    * @return
    */
    public String _getPKColumnName() {
        return "id";
    }

    /**
    * 获取主键值
    *
    * @return
    */
    public String _getPKValue() {
        return String.valueOf(id);
    }

    /**
    * 设置主键的值
    *
    * @return
    */
    public void _setPKValue(Object value) {
        this.id=(java.lang.String)value;
    }
}
