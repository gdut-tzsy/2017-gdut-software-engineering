package cn.com.do1.component.reportdanger.reportdanger.vo;

import cn.com.do1.common.annotation.bean.PageView;
import cn.com.do1.common.annotation.bean.Validation;
import cn.com.do1.common.framebase.dqdp.IBaseDBVO;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司 All rights reserved. User: zoulele
 */
public class TbYsjdCommunityUserVo {

    /**
     * <p>Field id: 主键</p>
     */
    private java.lang.String id;

    /**
     * <p>Field dangerId: 隐患描述ID</p>
     */
    private java.lang.String dangerId;

    /**
     * <p>Field communityId: 社区ID</p>
     */
    private java.lang.String communityId;

    /**
     * <p>Field userId: 负责人ID</p>
     */
    private java.lang.String userId;

    /**
     * <p>Field userName: 负责人姓名</p>
     */
    private java.lang.String userName;

    /**
     * <p>Field headPic: 负责人头像</p>
     */
    private java.lang.String headPic;

    /**
     * <p>Field wxUserId: 负责人wx_user_id</p>
     */
    private java.lang.String wxUserId;

    public java.lang.String getId() {
        return this.id;
    }

    public void setId(java.lang.String id) {
        this.id = id;
    }

    public java.lang.String getDangerId() {
        return this.dangerId;
    }

    public void setDangerId(java.lang.String dangerId) {
        this.dangerId = dangerId;
    }

    public java.lang.String getCommunityId() {
        return this.communityId;
    }

    public void setCommunityId(java.lang.String communityId) {
        this.communityId = communityId;
    }

    public java.lang.String getUserId() {
        return this.userId;
    }

    public void setUserId(java.lang.String userId) {
        this.userId = userId;
    }

    public java.lang.String getUserName() {
        return this.userName;
    }

    public void setUserName(java.lang.String userName) {
        this.userName = userName;
    }

    public java.lang.String getHeadPic() {
        return this.headPic;
    }

    public void setHeadPic(java.lang.String headPic) {
        this.headPic = headPic;
    }

    public java.lang.String getWxUserId() {
        return this.wxUserId;
    }

    public void setWxUserId(java.lang.String wxUserId) {
        this.wxUserId = wxUserId;
    }


}
