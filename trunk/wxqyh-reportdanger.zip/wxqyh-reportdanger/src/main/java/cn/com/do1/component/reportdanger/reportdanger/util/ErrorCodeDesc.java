package cn.com.do1.component.reportdanger.reportdanger.util;

public enum ErrorCodeDesc
{
  system_error("-1", "系统出现异常，请稍后再试！"), 

  query_parameters_is_null("23001", "查询参数为空"), 
  template_is_not_exist("23002", "假期类型不存在"), 
  branch_json_is_null("23003", "分支信息为空"), 
  branch_is_not_vip("23004", "分支流程仅限vip用户使用"), 
  revoked_askId_is_null("23005", "销假的请假单不存在"), 
  template_fixed_flow_is_null("23006", "获取流程失败"), 
  Branch_id_is_not_exist("23007", "分支流程不存在"), 
  ask_is_not_revoked("23008", "该请假单不能销假"), 
  ask_sum_days_is_null("23009", "总天数为空"), 
  not_vip_use_revoked("23010", "销假功能仅限VIP用户使用"), 
  free_flow_not_revoked("23011", "自由流程的请假单无法销假"), 
  ask_is_not_exist("23012", "请假单已删除"), 
  branch_flow_is_not_exist("23013", "找不到可用的流程，请联系后台管理员"), 
  user_info_erro("23013", "用户信息有误"), 
  not_vip_use_type_range("23014", "类型可见范围限制仅限vip用户使用"), 
  template_range_is_null("23015", "特定对象不能为空"), 
  flow_is_not_exist("23016", "流程已被删除，请重新提单");

  private String code;
  private String desc;

  private ErrorCodeDesc(String _nCode, String _nDesc) {
    this.code = _nCode;
    this.desc = _nDesc;
  }

  public String getCode()
  {
    return this.code;
  }

  public void setCode(String code)
  {
    this.code = code;
  }

  public String getDesc()
  {
    return this.desc;
  }

  public void setDesc(String desc)
  {
    this.desc = desc;
  }
}
