package cn.com.do1.component.reportdanger.reportdanger.ui;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.struts2.ServletActionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.do1.common.annotation.struts.ActionRoles;
import cn.com.do1.common.annotation.struts.CatchException;
import cn.com.do1.common.annotation.struts.JSONOut;
import cn.com.do1.common.annotation.struts.SearchValueType;
import cn.com.do1.common.annotation.struts.SearchValueTypes;
import cn.com.do1.common.dac.Pager;
import cn.com.do1.common.exception.BaseException;
import cn.com.do1.common.util.AssertUtil;
import cn.com.do1.common.util.string.StringUtil;
import cn.com.do1.component.addressbook.contact.model.TbQyPicPO;
import cn.com.do1.component.addressbook.contact.vo.UserInfoVO;
import cn.com.do1.component.addressbook.department.vo.TbDepartmentInfoVO;
import cn.com.do1.component.core.WxqyhAppContext;
import cn.com.do1.component.flow.flow.service.IFlowAuditService;
import cn.com.do1.component.flow.flow.service.IFlowTemplateService;
import cn.com.do1.component.flow.flow.vo.ChooseBoxVO;
import cn.com.do1.component.flow.flow.vo.FlowAuditVO;
import cn.com.do1.component.flow.flow.vo.FlowNodeVO;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdDangerCommentPo;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdReportdangerPo;
import cn.com.do1.component.reportdanger.reportdanger.service.ReportdangerService;
import cn.com.do1.component.reportdanger.reportdanger.util.ErrorCodeDesc;
import cn.com.do1.component.reportdanger.reportdanger.vo.CountDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdApprovalVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdBanVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdDangerCommentVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdRecipientVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdReportdangerVo;
import cn.com.do1.component.todo.todo.service.IToDoService;
import cn.com.do1.component.uploadfile.imageupload.service.IFileMediaService;
import cn.com.do1.component.util.Configuration;
import cn.com.do1.component.util.TimeHelper;
import cn.com.do1.component.util.WxqyhPortalBaseAction;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司 All rights reserved. User: zoulele
 */
public class reportPortalAction extends WxqyhPortalBaseAction {
    private final static transient Logger logger = LoggerFactory.getLogger(reportPortalAction.class);
    private IFlowTemplateService flowTemplateService;
    private ReportdangerService reportdangerService;
    private IFileMediaService fileMediaService;
    private TbYsjdReportdangerPo tbYsjdReportdangerPO;
    private IFlowAuditService flowAuditService;
    private TbYsjdDangerCommentPo tbYsjdDangerCommentPo;
    private IToDoService todoService;
    private String ids[];
    private String id;
    private String relatives;
    private String imageUrls;
    private String userIds;
    private String mediaIds[];
    private String signImg;
    private String flowId;
    private String flowDpId;
    private String choiseFlowUser;
    private String nextNodeId;
    private String lightStatus;
    private String currentNodeId;
    private Integer size;

    public ReportdangerService getReportdangerService() {
        return reportdangerService;
    }

    @Resource
    public void setReportdangerService(ReportdangerService reportdangerService) {
        this.reportdangerService = reportdangerService;
    }

    @Resource(name = "todoService")
    public void setTodoService(IToDoService todoService) {
        this.todoService = todoService;
    }

    @Resource(name = "flowAuditService")
    public void setFlowAuditService(IFlowAuditService flowAuditService) {
        this.flowAuditService = flowAuditService;
    }

    @Resource(name = "flowTemplateService")
    public void setFlowTemplateService(IFlowTemplateService flowTemplateService) {
        this.flowTemplateService = flowTemplateService;
    }
    
    @Resource
    public void setFileMediaService(IFileMediaService fileMediaService) {
        this.fileMediaService = fileMediaService;
    }

    public String[] getIds() {
        return ids;
    }

    public void setIds(String[] ids) {
        this.ids = ids;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public String getRelatives() {
        return relatives;
    }

    public void setRelatives(String relatives) {
        this.relatives = relatives;
    }

    public String getImageUrls() {
        return imageUrls;
    }

    public void setImageUrls(String imageUrls) {
        this.imageUrls = imageUrls;
    }

    /**
     * 列表查询时，页面要传递的参数
     */
    @SearchValueTypes(nameFormat = "false", value = { @SearchValueType(name = "title", type = "string", format = "%%%s%%") })
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "查询成功", faileMsg = "查询失败"))
    public void ajaxSearch() throws Exception, BaseException {
        UserInfoVO sendUser = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());
        String userId = sendUser.getUserId();
        Pager pager = new Pager(ServletActionContext.getRequest(), 10);
        Map<String, Object> searchValue = getSearchValue();
        searchValue.put("userId", userId);

        pager = reportdangerService.searchTbYsjdReportdanger(searchValue, pager);
        boolean hasMore = false;
        if (pager.getCurrentPage() < pager.getTotalPages()) {
            hasMore = true;
        }
        addJsonObj("hasMore", hasMore);
        addJsonPager("pageData", pager);
    }

    /**
     * 列表查询时，页面要传递的参数
     */
    @SearchValueTypes(nameFormat = "false", value = { @SearchValueType(name = "title", type = "string", format = "%%%s%%") })
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "查询成功", faileMsg = "查询失败"))
    public void searchView() throws Exception, BaseException {
        UserInfoVO sendUser = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());
        String userId = sendUser.getUserId();
        TbYsjdReportdangerVo vo = this.reportdangerService.getTbYsjdReportdangerVo(id);
        
        if (null == vo) {
            logger.error("该隐患上报已删除");
            setActionResult("1000", "该隐患上报已删除");
            return;
        }
        List<TbQyPicPO> picList = this.contactService.getPicListByGroupId(id);
        List<TbQyPicPO> resultList = this.contactService.getPicListByGroupId(id+"result");
        List<TbYsjdRecipientVo> recipient = this.reportdangerService.getDangerRecipient(id, "1");

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("askId", id);
        Pager comments = new Pager(ServletActionContext.getRequest(), this.size);
        comments = this.reportdangerService.getDangerComment(map, comments);
        List<TbYsjdDangerCommentVo> list = (List<TbYsjdDangerCommentVo>) comments.getPageData();
        if (!AssertUtil.isEmpty(list) && list.size() > 0) {
            for (TbYsjdDangerCommentVo cvo : list) {
                cvo.setTime(TimeHelper.getFriendlyDesc(cvo.getCreateTime()));
            }
        }
        
        if("1".equals(vo.getReportType())){
            List<TbYsjdApprovalVo> approvalList = this.reportdangerService.getApprovalVoList(id);
            addJsonArray("approvalList", approvalList);
        }
        
        //获取附件
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("orgId", sendUser.getOrgId());
        paramMap.put("groupId", id);
        paramMap.put("groupType", 1);
        addJsonArray("mediaList", fileMediaService.getMediaByGroupId(paramMap));
        
        
        addJsonArray("comments", list);
        addJsonObj("getBat", getBat(sendUser, vo));
        addJsonObj("picList", picList);
        addJsonObj("resultList", resultList);
        addJsonObj("recipient", recipient);
        addJsonObj("vo", vo);
    }
    
    @JSONOut(catchException = @CatchException(errCode = "1003", successMsg = "操作成功", faileMsg = "操作失败"))
    public void updataStatus() throws Exception, BaseException {
        HttpServletRequest request = ServletActionContext.getRequest();
        boolean isWeChatApp = WxqyhAppContext.isWeChatApp(request);
        UserInfoVO userVO = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());
        String taskId = request.getParameter("askId");
        String status = request.getParameter("status");
        String reason = request.getParameter("reason");
        TbYsjdReportdangerPo po = this.reportdangerService.searchByPk(TbYsjdReportdangerPo.class, taskId);
        if (StringUtil.isNullEmpty(this.signImg)) {
            this.signImg = "";
        }
        
        if (AssertUtil.isEmpty(po)) {
            setActionResult("3", "此请假已删除!");
            return;
        }
        if ("3".equals(po.getStatus())) {
            setActionResult("3", "该隐患上报已完结，请重新进入页面！");
            return;
        }
        this.reportdangerService.updataStatus(po, userVO, status, reason,this.mediaIds,this.imageUrls);
    }

    private String getBat(UserInfoVO sendUser, TbYsjdReportdangerVo vo) throws Exception, BaseException {
        String retStr = "";
        Boolean isCreator = false; //是否创建人
        Boolean isApprovers = false; //是否当前审批人
        String userId = sendUser.getUserId();
        if (userId.equals(vo.getCreatorUser())) {
            isCreator = true;
        }
        if("1".equals(vo.getReportType())){
            if(userId.equals(vo.getCreatorUser())){
                isApprovers = true;
            }else{
                List<TbYsjdRecipientVo> recipient = this.reportdangerService.getDangerRecipient(vo.getId(), "0");
                for (TbYsjdRecipientVo userVo : recipient) {
                    if (userId.equals(userVo.getUserId())) {
                        isApprovers = true;
                        break;
                    }
                }
            }
        } else {
            List<TbYsjdRecipientVo> recipient = this.reportdangerService.getDangerRecipient(vo.getId(), "0");
            for (TbYsjdRecipientVo userVo : recipient) {
                if (userId.equals(userVo.getUserId())&&!userVo.getUserId().equals(vo.getCreatorUser())) {
                //if (userId.equals(userVo.getUserId())) {
                    isApprovers = true;
                    break;
                }
            }
            /*List<TbQyUserInfoVO> personList = this.todoService.findTodoUserInfoByRefId(vo.getId());
            if (!AssertUtil.isEmpty(personList) && personList.size() > 0) {
                for (TbQyUserInfoVO userVo : personList) {
                    if (userId.equals(userVo.getUserId())) {
                        isApprovers = true;
                        break;
                    }
                }
            }*/
        }
        

        if ("2".equals(vo.getStatus()) && isApprovers && isCreator) {
            return "0"; //已处理，且是当前处理人和创建人：显示确认转灯按钮和重新编号处理结果
        }
        if ("1".equals(vo.getStatus()) && isApprovers) {
            return "1"; //待处理，且是当前处理人：显示处理按钮
        }
        if ("2".equals(vo.getStatus()) && isApprovers) {
            return "2"; //已处理，且是当前处理人：显示重新编号处理结果
        }
        if ("2".equals(vo.getStatus()) && isCreator) {
            return "3"; //已处理，且是创建人：显示确认转灯按钮
        }
        return "4";
    }

    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "查询成功", faileMsg = "查询失败"))
    public void getDangerUser() throws Exception, BaseException {
        Map<String, Object> searchValue = getSearchValue();
        List<String> dangerUser = reportdangerService.getDangerUser(searchValue);
        addJsonObj("dangerUser", dangerUser);
    }

    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "查询成功", faileMsg = "查询失败"))
    public void searchCountDangerVoList() throws Exception, BaseException {
        List<CountDangerVo> countList = reportdangerService.searchCountDangerVoList(getSearchValue());
        if(!AssertUtil.isEmpty(countList)){
            for (CountDangerVo vo : countList) {
                vo.setProgressLeft(searchNum(vo.getProgressLeft()));
                vo.setProgressRight(searchNum(vo.getProgressRight()));
            }
        }
        addJsonObj("countList", countList);
    }

    public String searchNum(String countNum) {
        DecimalFormat df = new DecimalFormat("#.00");
        if(!AssertUtil.isEmpty(countNum)){
            Double number = Double.parseDouble(countNum);
            if(number<=0){
                return "0";
            }else{
                countNum = df.format(number);
            }
            return countNum;
        }else{
            return "0";
        }
    }
    
    public void setTbYsjdReportdangerPO(TbYsjdReportdangerPo tbYsjdReportdangerPO) {
        this.tbYsjdReportdangerPO = tbYsjdReportdangerPO;
    }

    public TbYsjdReportdangerPo getTbYsjdReportdangerPO() {
        return this.tbYsjdReportdangerPO;
    }

    @ActionRoles({ "reportdangerAdd" })
    public void addTbYsjdReportdangerPO() throws BaseException {
        super.ajaxAdd(tbYsjdReportdangerPO);
    }

    @ActionRoles({ "reportdangerUpdate" })
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "修改成功", faileMsg = "修改失败"))
    public void modifyTbYsjdReportdangerPO() throws BaseException, Exception {
        PropertyUtils.setProperty(tbYsjdReportdangerPO, tbYsjdReportdangerPO._getPKColumnName(), id);
        this.reportdangerService.updatePO(tbYsjdReportdangerPO, false);
    }

    @ActionRoles({ "reportdangerUpdate" })
    public void updateTbYsjdReportdangerPO() {
        super.ajaxUpdate(tbYsjdReportdangerPO);
    }

    @ActionRoles({ "reportdangerDel" })
    public void deleteTbYsjdReportdangerPO() {
        if (AssertUtil.isEmpty(id))
            id = ids[0];
        tbYsjdReportdangerPO._setPKValue(id);
        super.ajaxDelete(tbYsjdReportdangerPO);
    }

    @ActionRoles({ "reportdangerDel" })
    public void batchDeleteTbYsjdReportdangerPO() {
        super.ajaxBatchDelete(TbYsjdReportdangerPo.class, ids);
    }

    @ActionRoles({ "reportdangerView" })
    @JSONOut(catchException = @CatchException(errCode = "1005", successMsg = "查询成功", faileMsg = "查询失败"))
    public void ajaxView() throws Exception, BaseException {
        TbYsjdReportdangerPo tbYsjdReportdangerPO = reportdangerService.searchByPk(TbYsjdReportdangerPo.class, id);
        addJsonFormateObj("tbYsjdReportdangerPO", tbYsjdReportdangerPO);//注意，PO才用addJsonFormateObj，如果是VO，要采用addJsonObj
    }

    /**
     * 列表查询时，页面要传递的参数
     */
    @JSONOut(catchException = @CatchException(errCode = "1005", successMsg = "查询成功", faileMsg = "查询失败"))
    public void onloadAdd() throws Exception, BaseException {
        UserInfoVO userInfo = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());
        String deptName = "";
        if (!AssertUtil.isEmpty(userInfo)) {
            String deptNames = userInfo.getDeptFullNames();
            if (!AssertUtil.isEmpty(deptNames)) {
                String pitDepts[] = deptNames.split(";");
                for (String str : pitDepts) {
                    String depts[] = str.split("->");
                    if ("社区".equals(depts[0])) {
                        deptName = depts[0] + "->" + depts[1];
                        break;
                    }
                }
            }
        }
        TbDepartmentInfoVO deptInfo = this.reportdangerService.searchDepartmentInfoVO(deptName);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("grid", deptInfo.getId());
        List<TbYsjdBanVo> ysjdBan = getBanVoList(userInfo);
        List<TbYsjdDangerVo> ysjdDanger = this.reportdangerService.searchYsjdDangerVo(lightStatus);

        if("2".equals(lightStatus)){
            String branchId = new StringBuilder().append("reportdanger").append(userInfo.getOrgId().replace("-", ""))
                    .toString();
            List list = this.flowAuditService.findBranchFlowTemplateByRefId(branchId, userInfo.getOrgId());
            if ((!AssertUtil.isAllEmpty(new Object[] { list })) && (list.size() > 0)) {
                addJsonObj("branchNodeInfo",
                        getBranchFlowFirstNodeInfo(((ChooseBoxVO) list.get(0)).getId(), userInfo.getOrgId()));
            } else {
                setActionResult(ErrorCodeDesc.branch_flow_is_not_exist.getCode(),
                        ErrorCodeDesc.branch_flow_is_not_exist.getDesc());
                return;
            }
            addJsonArray("flowlist", list);
        }
        addJsonArray("ysjdBan", ysjdBan);
        addJsonArray("ysjdDanger", ysjdDanger);
        addJsonObj("deptInfo", deptInfo);
    }

    @JSONOut(catchException = @CatchException(errCode = "1005", successMsg = "查询成功", faileMsg = "查询失败"))
    public void getYsjdBanVoList() throws Exception, BaseException {
        UserInfoVO userInfo = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());
        List<TbYsjdBanVo> ysjdBan = getBanVoList(userInfo);
        addJsonArray("ysjdBan", ysjdBan);
    }

    private List<TbYsjdBanVo> getBanVoList(UserInfoVO userInfo) throws SQLException {
        String deptName = "";
        if (!AssertUtil.isEmpty(userInfo)) {
            String deptNames = userInfo.getDeptFullNames();
            if (!AssertUtil.isEmpty(deptNames)) {
                String pitDepts[] = deptNames.split(";");
                for (String str : pitDepts) {
                    String depts[] = str.split("->");
                    if ("社区".equals(depts[0])) {
                        deptName = str;
                        break;
                    }
                }
            }
        }
        TbDepartmentInfoVO deptInfo = this.reportdangerService.searchDepartmentInfoVO(deptName);
        Map<String, Object> map = getSearchValue();
        //map.put("grid", userInfo.getDeptIds());
        map.put("grid", deptInfo.getId());
        List<TbYsjdBanVo> ysjdBan = this.reportdangerService.searchYsjdBanVo(map);
        return ysjdBan;
    }

    @JSONOut(catchException = @CatchException(errCode = "1005", successMsg = "查询成功", faileMsg = "查询失败"))
    public void getYsjdDangerVoList() throws Exception, BaseException {
        UserInfoVO userInfo = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());
        List<TbYsjdDangerVo> ysjdDanger = this.reportdangerService.searchYsjdDangerVo(lightStatus);
        addJsonFormateObj("ysjdDanger", ysjdDanger);
    }

    @JSONOut(catchException = @CatchException(errCode = "1005", successMsg = "隐患上报成功", faileMsg = "隐患上报失败"))
    public void addReportdangerPO() throws BaseException, Exception {

        UserInfoVO userInfo = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());

        this.tbYsjdReportdangerPO.setCreatorTime(new Date());
        String id = UUID.randomUUID().toString();
        this.tbYsjdReportdangerPO.setId(id);
        this.tbYsjdReportdangerPO.setCreatorUser(userInfo.getUserId());
        this.tbYsjdReportdangerPO.setStatus("1");
        this.tbYsjdReportdangerPO.setOvertimeStatus("0");
        this.tbYsjdReportdangerPO.setReportTime(new Date());

        Map<String, String> branchMap = new HashMap<String, String>();
        branchMap.put("flowId", this.flowId);
        branchMap.put("groupId", this.tbYsjdReportdangerPO.getId());
        branchMap.put("orId", userInfo.getOrgId());
        branchMap.put("userId", userInfo.getUserId());
        branchMap.put("dpId", this.flowDpId);
        branchMap.put("choiseFlowUser", this.choiseFlowUser);
        branchMap.put("nextNodeId", this.nextNodeId);
        branchMap.put("currentNodeId", this.currentNodeId);
        branchMap.put("versionsId",
                new StringBuilder().append("reportdanger").append(userInfo.getOrgId().replace("-", "")).toString());

        this.reportdangerService.addReportdangerPO(this.tbYsjdReportdangerPO, userInfo, this.relatives, this.imageUrls,
                this.flowId, this.flowDpId, this.choiseFlowUser, branchMap);
    }
    
    @JSONOut(catchException = @CatchException(errCode = "1005", successMsg = "隐患上报成功", faileMsg = "隐患上报失败"))
    public void addDangerPO() throws BaseException, Exception {
        UserInfoVO userInfo = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());
        this.tbYsjdReportdangerPO.setCreatorTime(new Date());
        String id = UUID.randomUUID().toString();
        this.tbYsjdReportdangerPO.setId(id);
        this.tbYsjdReportdangerPO.setCreatorUser(userInfo.getUserId());
        this.tbYsjdReportdangerPO.setStatus("1");
        this.tbYsjdReportdangerPO.setOvertimeStatus("0");
        this.tbYsjdReportdangerPO.setReportTime(new Date());

        this.reportdangerService.addReportdangerPO(this.tbYsjdReportdangerPO, userInfo, this.relatives, this.imageUrls);
    }

    @JSONOut(catchException = @CatchException(errCode = "-1", successMsg = "查询成功", faileMsg = "查询失败"))
    public void getFormNextNodeInfo() throws Exception, BaseException {
        HttpServletRequest request = ServletActionContext.getRequest();
        UserInfoVO userVO = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());
        String definition_id = new StringBuilder().append("reportdanger").append(userVO.getOrgId().replace("-", ""))
                .toString();
        Map fieldMap = getSearchValue();
        boolean isInstancesFlow = false;
        if (!StringUtil.isNullEmpty(this.id)) {
            isInstancesFlow = this.flowAuditService.isAlreadyInstancesFlowNode(this.id).booleanValue();
        }
        Map map = new HashMap();
        map.put("flowId", this.flowId);
        map.put("definition_id", definition_id);
        map.put("work_id", this.id);
        map.put("currentNodeId", this.currentNodeId);
        List<FlowNodeVO> nextNodeList = this.flowAuditService.findNextNodeInfo(
                isInstancesFlow == true ? (String) map.get("work_id") : (String) map.get("definition_id"), fieldMap,
                isInstancesFlow, (String) map.get("currentNodeId"));
        addJsonArray("nextNodeList", nextNodeList);
    }

    private FlowAuditVO getBranchFlowFirstNodeInfo(String flow_id, String orgId) throws Exception, BaseException {
        if ((!StringUtil.isNullEmpty(flow_id))
                && (!AssertUtil.isEmpty(this.flowAuditService.isHaveFlow(flow_id, orgId)))) {
            return this.flowAuditService.getFlowAuditFirstNodeByRefId(flow_id, true);
        }
        return this.flowAuditService.getFlowAuditFirstNodeByRefId(flow_id, false);
    }

    @JSONOut(catchException = @CatchException(errCode = "-1", successMsg = "查询成功", faileMsg = "查询失败"))
    public void listComment() throws Exception, BaseException {
        Map map = new HashMap();
        map.put("askId", id);
        Pager comments = new Pager(ServletActionContext.getRequest(), this.size);
        comments = this.reportdangerService.getDangerComment(map, comments);
        List<TbYsjdDangerCommentVo> list = (List<TbYsjdDangerCommentVo>) comments.getPageData();
        if (!AssertUtil.isEmpty(list) && list.size() > 0) {
            for (TbYsjdDangerCommentVo cvo : list) {
                cvo.setTime(TimeHelper.getFriendlyDesc(cvo.getCreateTime()));
            }
        }
        addJsonArray("comments", list);
        boolean hasMore = false;
        if (comments.getCurrentPage() < comments.getTotalPages()) {
            hasMore = true;
        }
        addJsonObj("hasMore", Boolean.valueOf(hasMore));
        this.tbYsjdReportdangerPO = new TbYsjdReportdangerPo();
        this.tbYsjdReportdangerPO.setCommentCount(Integer.valueOf((int)comments.getTotalRows()));
        addJsonFormateObj("tbTaskinfo", this.tbYsjdReportdangerPO);
    }

    @JSONOut(catchException = @CatchException(errCode = "1005", successMsg = "查询成功", faileMsg = "查询失败"))
    public void commitComment() throws Exception, BaseException {
        UserInfoVO userInfo = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());

        List<TbYsjdDangerCommentPo> list = this.reportdangerService.getCommentsByUserID(userInfo.getUserId(),
                this.tbYsjdDangerCommentPo.getReportdangerId());
        if (!AssertUtil.isEmpty(list)) {
            TbYsjdDangerCommentPo po = (TbYsjdDangerCommentPo) list.get(0);
            if (new Date().getTime() - po.getCreateTime().getTime() <= Configuration.COMMENT_INTERVAL * 1000) {
                return;
            }
        }

        String commentId = UUID.randomUUID().toString();
        String content = this.tbYsjdDangerCommentPo.getContent();
        this.tbYsjdDangerCommentPo.setCommentId(commentId);
        this.tbYsjdDangerCommentPo.setCreator(userInfo.getUserId());
        this.tbYsjdDangerCommentPo.setPersonName(userInfo.getPersonName());
        this.tbYsjdDangerCommentPo.setHeadPic(userInfo.getHeadPic());
        this.tbYsjdDangerCommentPo.setWxUserId(userInfo.getWxUserId());
        this.tbYsjdDangerCommentPo.setDepartmentId(userInfo.getDeptIdsForRedundancy());
        this.tbYsjdDangerCommentPo.setDepartmentName(userInfo.getDeptFullNamesForRedundancy());
        this.tbYsjdDangerCommentPo.setCreateTime(new Date());
        this.tbYsjdDangerCommentPo.setStatus("0");
        if (!StringUtil.isNullEmpty(this.signImg)) {
            this.tbYsjdDangerCommentPo.setContent(new StringBuilder().append(content).append(this.signImg).toString());
        }
        this.reportdangerService.insertPO(this.tbYsjdDangerCommentPo, false);

        this.tbYsjdReportdangerPO = ((TbYsjdReportdangerPo) this.reportdangerService.searchByPk(
                TbYsjdReportdangerPo.class, this.tbYsjdDangerCommentPo.getReportdangerId()));

        if (null == this.tbYsjdReportdangerPO) {
            setActionResult("3", "该隐患上报已被删除！");
            return;
        }
        int count = 0;
        if (!AssertUtil.isEmpty(this.tbYsjdReportdangerPO.getCommentCount())) {
            count = this.tbYsjdReportdangerPO.getCommentCount();
        }

        this.tbYsjdReportdangerPO.setCommentCount(Integer.valueOf(count + 1));
        this.reportdangerService.updatePO(this.tbYsjdReportdangerPO, false);

    }
    
    @JSONOut(catchException=@CatchException(errCode="2001", successMsg="删除成功", faileMsg="删除失败"))
    public void deleteComment()
      throws Exception, BaseException
    {
      HttpServletRequest request = ServletActionContext.getRequest();
      String commentId = request.getParameter("commentId");
      TbYsjdDangerCommentPo po = (TbYsjdDangerCommentPo)this.reportdangerService.searchByPk(TbYsjdDangerCommentPo.class, commentId);
      if (null == po) {
        logger.error("该评论已删除");
        setActionResult("1000", "该评论已删除");
        return;
      }
      Date date = new Date();
      long time = date.getTime() - po.getCreateTime().getTime();
      long min = time / 60000L;
      if (min < 30L) {
        this.reportdangerService.updateCommentStatus(commentId);
      } else {
        logger.error("该评论提交已超过了30分钟");
        setActionResult("1001", "该评论提交已超过了30分钟,不能删除");
        return;
      }
    }

    @JSONOut(catchException = @CatchException(errCode = "1006", successMsg = "操作成功", faileMsg = "操作失败"))
    public void agreeAudit() throws Exception, BaseException {
        HttpServletRequest request = ServletActionContext.getRequest();

        UserInfoVO userInfo = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());

        String taskId = request.getParameter("askId");
        String reason = request.getParameter("reason");
        TbYsjdReportdangerPo po = this.reportdangerService.searchByPk(TbYsjdReportdangerPo.class, taskId);
        if (null == po) {
            setActionResult("3", "该隐患上报已被删除！");
            return;
        }
        if (StringUtil.isNullEmpty(this.signImg)) {
            this.signImg = "";
        }
        synchronized (logger) {
            this.reportdangerService.agreeAudit(po, reason, userInfo.getUserId(), userInfo.getOrgId(), this.signImg);
        }
    }
    
    @JSONOut(catchException = @CatchException(errCode = "1003", successMsg = "操作成功", faileMsg = "操作失败"))
    public void updataDangerPo() throws Exception, BaseException {
        HttpServletRequest request = ServletActionContext.getRequest();
        UserInfoVO userVO = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());
        String taskId = request.getParameter("askId");
        String reason = this.tbYsjdReportdangerPO.getResult();
        TbYsjdReportdangerPo po = this.reportdangerService.searchByPk(TbYsjdReportdangerPo.class, taskId);
        if (StringUtil.isNullEmpty(this.signImg)) {
            this.signImg = "";
        }
        if (AssertUtil.isEmpty(po)) {
            setActionResult("3", "此请假已删除!");
            return;
        }
        if ("3".equals(po.getStatus())) {
            setActionResult("3", "该隐患上报已完结，请重新进入页面！");
            return;
        }
        this.reportdangerService.updataDangerPo(po, userVO, reason,this.mediaIds,this.imageUrls);
    }

    @JSONOut(catchException = @CatchException(errCode = "1003", successMsg = "操作成功", faileMsg = "操作失败"))
    public void updataAuditStatus() throws Exception, BaseException {
        HttpServletRequest request = ServletActionContext.getRequest();
        boolean isWeChatApp = WxqyhAppContext.isWeChatApp(request);
        UserInfoVO userVO = WxqyhAppContext.getCurrentUser(ServletActionContext.getRequest());
        String flowDpId = request.getParameter("flowDpId");
        String taskId = request.getParameter("askId");
        String status = request.getParameter("status");
        String reason = request.getParameter("reason");
        TbYsjdReportdangerPo po = this.reportdangerService.searchByPk(TbYsjdReportdangerPo.class, taskId);
        if (StringUtil.isNullEmpty(this.signImg)) {
            this.signImg = "";
        }
        
        if (AssertUtil.isEmpty(po)) {
            setActionResult("3", "此请假已删除!");
            return;
        }
        if ("3".equals(po.getStatus())) {
            setActionResult("3", "该隐患上报已完结，请重新进入页面！");
            return;
        }

        Map branchMap = new HashMap();
        branchMap.put("userId", userVO.getUserId());
        branchMap.put("flowDpId", flowDpId);
        branchMap.put("orgId", userVO.getOrgId());
        branchMap.put("choiseFlowUser", this.choiseFlowUser);
        branchMap.put("nextNodeId", this.nextNodeId);
        branchMap.put("currentNodeId", this.currentNodeId);
        branchMap.put("groupId", po.getId());
        branchMap.put("closeReason", new StringBuilder().append(reason).append(this.signImg).toString());
        branchMap.put("definitionVersionsId",
                new StringBuilder().append("reportdanger").append(userVO.getOrgId().replace("-", "")).toString());
        branchMap.put("isWeChatApp", isWeChatApp == true ? "1" : "0");

        this.reportdangerService.updataAuditStatus(po, userVO, status, flowDpId, reason, this.choiseFlowUser,
                this.signImg, branchMap,this.mediaIds,this.imageUrls);
    }

    public String getFlowId() {
        return flowId;
    }

    public void setFlowId(String flowId) {
        this.flowId = flowId;
    }

    public String getFlowDpId() {
        return flowDpId;
    }

    public void setFlowDpId(String flowDpId) {
        this.flowDpId = flowDpId;
    }

    public String getChoiseFlowUser() {
        return choiseFlowUser;
    }

    public void setChoiseFlowUser(String choiseFlowUser) {
        this.choiseFlowUser = choiseFlowUser;
    }

    public String getNextNodeId() {
        return nextNodeId;
    }

    public void setNextNodeId(String nextNodeId) {
        this.nextNodeId = nextNodeId;
    }

    public String getCurrentNodeId() {
        return currentNodeId;
    }

    public void setCurrentNodeId(String currentNodeId) {
        this.currentNodeId = currentNodeId;
    }

    public IFlowTemplateService getFlowTemplateService() {
        return flowTemplateService;
    }

    public IFlowAuditService getFlowAuditService() {
        return flowAuditService;
    }

    public TbYsjdDangerCommentPo getTbYsjdDangerCommentPo() {
        return tbYsjdDangerCommentPo;
    }

    public void setTbYsjdDangerCommentPo(TbYsjdDangerCommentPo tbYsjdDangerCommentPo) {
        this.tbYsjdDangerCommentPo = tbYsjdDangerCommentPo;
    }

    public String getUserIds() {
        return userIds;
    }

    public void setUserIds(String userIds) {
        this.userIds = userIds;
    }

    public String getSignImg() {
        return signImg;
    }

    public void setSignImg(String signImg) {
        this.signImg = signImg;
    }

    public String[] getMediaIds() {
        return mediaIds;
    }

    public void setMediaIds(String[] mediaIds) {
        this.mediaIds = mediaIds;
    }

    public String getLightStatus() {
        return lightStatus;
    }

    public void setLightStatus(String lightStatus) {
        this.lightStatus = lightStatus;
    }


    
}
