package cn.com.do1.component.reportdanger.reportdanger.vo;

import cn.com.do1.common.annotation.bean.FormatMask;
import cn.com.do1.common.framebase.dqdp.IBaseVO;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class TbYsjdRecipientVo
  implements Serializable, IBaseVO
{
  private String recipientId;
  private String reportdangerId;
  private String userId;
  private String userType;
  private String createPerson;

  @FormatMask(type="date", value="yyyy-MM-dd HH:mm:ss")
  private Date createTime;
  private String wxUserId;
  private String personName;
  private String headPic;
  private String mobile;

  public List<String> _getTableNames()
  {
    return null;
  }

  public String getRecipientId() {
    return this.recipientId;
  }

  public void setRecipientId(String recipientId) {
    this.recipientId = recipientId;
  }

  public String getReportdangerId() {
    return this.reportdangerId;
  }

  public void setReportdangerId(String reportdangerId) {
    this.reportdangerId = reportdangerId;
  }

  public String getUserId() {
    return this.userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getUserType() {
    return this.userType;
  }

  public void setUserType(String userType) {
    this.userType = userType;
  }

  public String getCreatePerson() {
    return this.createPerson;
  }

  public void setCreatePerson(String createPerson) {
    this.createPerson = createPerson;
  }

  public Date getCreateTime() {
    return this.createTime;
  }

  public void setCreateTime(Date createTime) {
    this.createTime = createTime;
  }

  public String getPersonName() {
    return this.personName;
  }

  public void setPersonName(String personName) {
    this.personName = personName;
  }

  public String getHeadPic() {
    return this.headPic;
  }

  public void setHeadPic(String headPic) {
    this.headPic = headPic;
  }

  public String getMobile() {
    return this.mobile;
  }

  public void setMobile(String mobile) {
    this.mobile = mobile;
  }

  public String getWxUserId() {
    return this.wxUserId;
  }

  public void setWxUserId(String wxUserId) {
    this.wxUserId = wxUserId;
  }
}