package cn.com.do1.component.reportdanger.reportdanger.ui;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.struts2.ServletActionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.do1.common.annotation.struts.ActionRoles;
import cn.com.do1.common.annotation.struts.CatchException;
import cn.com.do1.common.annotation.struts.JSONOut;
import cn.com.do1.common.annotation.struts.SearchValueType;
import cn.com.do1.common.annotation.struts.SearchValueTypes;
import cn.com.do1.common.dac.Pager;
import cn.com.do1.common.exception.BaseException;
import cn.com.do1.common.framebase.struts.BaseAction;
import cn.com.do1.common.util.AssertUtil;
import cn.com.do1.component.addressbook.contact.model.TbQyPicPO;
import cn.com.do1.component.addressbook.contact.vo.UserInfoVO;
import cn.com.do1.component.addressbook.contact.vo.UserOrgVO;
import cn.com.do1.component.core.WxqyhAppContext;
import cn.com.do1.component.flow.flow.model.TbQyFlowBranchInfoPO;
import cn.com.do1.component.flow.flow.service.IFlowTemplateService;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdReportdangerPo;
import cn.com.do1.component.reportdanger.reportdanger.service.ReportdangerService;
import cn.com.do1.component.reportdanger.reportdanger.util.ErrorCodeDesc;
import cn.com.do1.component.reportdanger.reportdanger.vo.CountDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdApprovalVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdDangerCommentVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdRecipientVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdReportdangerVo;
import cn.com.do1.component.uploadfile.imageupload.service.IFileMediaService;
import cn.com.do1.component.util.TimeHelper;
import cn.com.do1.component.util.WxqyhBaseAction;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司 All rights reserved. User: zoulele
 */
public class ReportdangerAction extends WxqyhBaseAction {
    private final static transient Logger logger = LoggerFactory.getLogger(ReportdangerAction.class);
    private IFlowTemplateService flowTemplateService;
    private ReportdangerService reportdangerService;
    private IFileMediaService fileMediaService;
    private TbYsjdReportdangerPo tbYsjdReportdangerPO;
    private String ids[];
    private String id;

    public ReportdangerService getReportdangerService() {
        return reportdangerService;
    }
    
    @Resource
    public void setFileMediaService(IFileMediaService fileMediaService) {
        this.fileMediaService = fileMediaService;
    }

    @Resource
    public void setReportdangerService(ReportdangerService reportdangerService) {
        this.reportdangerService = reportdangerService;
    }

    @Resource(name = "flowTemplateService")
    public void setFlowTemplateService(IFlowTemplateService flowTemplateService) {
        this.flowTemplateService = flowTemplateService;
    }

    public String[] getIds() {
        return ids;
    }

    public void setIds(String[] ids) {
        this.ids = ids;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     * 列表查询时，页面要传递的参数
     */
    @SearchValueTypes(nameFormat = "false", value = {
            @SearchValueType(name = "creatorTime", type = "date", format = "yyyy-MM-dd HH:mm:ss"),
            @SearchValueType(name = "reportTime", type = "date", format = "yyyy-MM-dd HH:mm:ss"),
            @SearchValueType(name = "handleTime", type = "date", format = "yyyy-MM-dd HH:mm:ss"),
            @SearchValueType(name = "personName", type = "string", format = "%%%s%%"),
            @SearchValueType(name = "handleUser", type = "string", format = "%%%s%%"),
            @SearchValueType(name = "theBanName", type = "string", format = "%%%s%%"),
            @SearchValueType(name = "departmentName", type = "string", format = "%%%s%%") })
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "查询成功", faileMsg = "查询失败"))
    public void ajaxSearch() throws Exception, BaseException {
        Pager pager = new Pager(ServletActionContext.getRequest(), getPageSize());
        pager = reportdangerService.searchTbYsjdReportdanger(getSearchValue(), pager);
        addJsonPager("pageData", pager);
    }
    
    /**
     * 列表查询时，页面要传递的参数
     */
    @SearchValueTypes(nameFormat = "false", value = { @SearchValueType(name = "title", type = "string", format = "%%%s%%") })
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "查询成功", faileMsg = "查询失败"))
    public void searchView() throws Exception, BaseException {
        UserOrgVO userInfoVO = getUser();
        TbYsjdReportdangerVo vo = this.reportdangerService.getTbYsjdReportdangerVo(id);
        
        if (null == vo) {
            logger.error("该隐患上报已删除");
            setActionResult("1000", "该隐患上报已删除");
            return;
        }
        List<TbQyPicPO> picList = this.contactService.getPicListByGroupId(id);
        List<TbQyPicPO> resultList = this.contactService.getPicListByGroupId(id+"result");
        List<TbYsjdRecipientVo> recipient = this.reportdangerService.getDangerRecipient(id, "1");

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("askId", id);
        Pager comments = new Pager(ServletActionContext.getRequest(), 1000);
        comments = this.reportdangerService.getDangerComment(map, comments);
        List<TbYsjdDangerCommentVo> list = (List<TbYsjdDangerCommentVo>) comments.getPageData();
        if (!AssertUtil.isEmpty(list) && list.size() > 0) {
            for (TbYsjdDangerCommentVo cvo : list) {
                cvo.setTime(TimeHelper.getFriendlyDesc(cvo.getCreateTime()));
            }
        }
        
        if("1".equals(vo.getReportType())){
            List<TbYsjdApprovalVo> approvalList = this.reportdangerService.getApprovalVoList(id);
            addJsonArray("approvalList", approvalList);
        }
        
        //获取附件
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("orgId", userInfoVO.getOrgId());
        paramMap.put("groupId", id);
        paramMap.put("groupType", 1);
        addJsonArray("mediaList", fileMediaService.getMediaByGroupId(paramMap));
        
        
        addJsonArray("comments", list);
        addJsonObj("picList", picList);
        addJsonObj("resultList", resultList);
        addJsonObj("recipient", recipient);
        addJsonObj("vo", vo);
    }

    /**
     * 整治情况统计表
     */
    @SearchValueTypes(nameFormat = "false", value = {
            @SearchValueType(name = "startTime", type = "date", format = "yyyy-MM-dd HH:mm:ss"),
            @SearchValueType(name = "endTime", type = "date", format = "yyyy-MM-dd HH:mm:ss") 
            })
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "查询成功", faileMsg = "查询失败"))
    public void searchCountDangerVoList() throws Exception, BaseException {
        List<CountDangerVo> countList = reportdangerService.searchMgrCountDangerVoList(getSearchValue());
        addJsonObj("countList", countList);
    }
    
    /**
     * 整治情况汇总表
     */
    @SearchValueTypes(nameFormat = "false", value = {
            @SearchValueType(name = "startTime", type = "date", format = "yyyy-MM-dd HH:mm:ss"),
            @SearchValueType(name = "endTime", type = "date", format = "yyyy-MM-dd HH:mm:ss") 
            })
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "查询成功", faileMsg = "查询失败"))
    public void searchSummaryDangerVoPager() throws Exception, BaseException {
        Pager pager = new Pager(ServletActionContext.getRequest(), getPageSize());
        pager = reportdangerService.searchSummaryDangerVoPager(getSearchValue(), pager);
        addJsonPager("pageData", pager);
    }

    public void setTbYsjdReportdangerPO(TbYsjdReportdangerPo tbYsjdReportdangerPO) {
        this.tbYsjdReportdangerPO = tbYsjdReportdangerPO;
    }

    public TbYsjdReportdangerPo getTbYsjdReportdangerPO() {
        return this.tbYsjdReportdangerPO;
    }

    @ActionRoles({ "reportdangerAdd" })
    public void addTbYsjdReportdangerPO() throws BaseException {
        super.ajaxAdd(tbYsjdReportdangerPO);
    }

    @ActionRoles({ "reportdangerUpdate" })
    @JSONOut(catchException = @CatchException(errCode = "1001", successMsg = "修改成功", faileMsg = "修改失败"))
    public void modifyTbYsjdReportdangerPO() throws BaseException, Exception {
        PropertyUtils.setProperty(tbYsjdReportdangerPO, tbYsjdReportdangerPO._getPKColumnName(), id);
        this.reportdangerService.updatePO(tbYsjdReportdangerPO, false);
    }

    @ActionRoles({ "reportdangerUpdate" })
    public void updateTbYsjdReportdangerPO() {
        super.ajaxUpdate(tbYsjdReportdangerPO);
    }

    @ActionRoles({ "reportdangerDel" })
    public void deleteTbYsjdReportdangerPO() {
        if (AssertUtil.isEmpty(id))
            id = ids[0];
        tbYsjdReportdangerPO._setPKValue(id);
        super.ajaxDelete(tbYsjdReportdangerPO);
    }

    @ActionRoles({ "reportdangerDel" })
    public void batchDeleteTbYsjdReportdangerPO() {
        super.ajaxBatchDelete(TbYsjdReportdangerPo.class, ids);
    }

    @ActionRoles({ "reportdangerView" })
    @JSONOut(catchException = @CatchException(errCode = "1005", successMsg = "查询成功", faileMsg = "查询失败"))
    public void ajaxView() throws Exception, BaseException {
        TbYsjdReportdangerPo tbYsjdReportdangerPO = reportdangerService.searchByPk(TbYsjdReportdangerPo.class, id);
        addJsonFormateObj("tbYsjdReportdangerPO", tbYsjdReportdangerPO);//注意，PO才用addJsonFormateObj，如果是VO，要采用addJsonObj
    }

    @JSONOut(catchException = @CatchException(errCode = "-1", successMsg = "保存成功", faileMsg = "保存失败"))
    public void ajaxUpdataBranchFlow() throws Exception, BaseException {
        UserOrgVO userInfoVO = getUser();
        Map params = getSearchValue();
        String flowBranchJson = (String) params.get("flowBranchJson");
        if (StringUtils.isEmpty(flowBranchJson)) {
            setActionResult(ErrorCodeDesc.branch_json_is_null.getCode(), ErrorCodeDesc.branch_json_is_null.getDesc());
            return;
        }
        Map flowInfoMap = new HashMap();
        String branchFlowId = "reportdanger" + userInfoVO.getOrgId().replace("-", "");
        flowInfoMap.put("definitionId", branchFlowId);
        flowInfoMap.put("definitionVersionsId", branchFlowId);
        flowInfoMap.put("title", userInfoVO.getOrgName() + "隐患处置流程");
        flowInfoMap.put("creator", userInfoVO.getUserName());
        flowInfoMap.put("orgId", userInfoVO.getOrgId());
        flowInfoMap.put("agentCode", "reportdanger");
        this.reportdangerService.saveBranchFlow(flowBranchJson, flowInfoMap, userInfoVO);
    }

    @JSONOut(catchException = @CatchException(errCode = "-1", successMsg = "保存成功", faileMsg = "保存失败"))
    public void ajaxViewBranchJson() throws Exception, BaseException {
        UserOrgVO userInfoVO = getUser();
        List<TbQyFlowBranchInfoPO> flowJsonList = this.flowTemplateService.searchFlowBranchByVersionsId("reportdanger"
                + userInfoVO.getOrgId().replace("-", ""), 0);
        StringBuffer flowJson = new StringBuffer();
        if (!AssertUtil.isEmpty(flowJsonList)) {
            for (TbQyFlowBranchInfoPO po : flowJsonList)
                flowJson.append(po.getFlowJson());
        } else {
            flowJson = null;
        }
        addJsonObj("flowJson", flowJson == null ? flowJson : flowJson.toString());
    }

}
