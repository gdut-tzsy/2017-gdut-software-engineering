package cn.com.do1.component.reportdanger.reportdanger.vo;

import java.util.Arrays;
import java.util.List;

import cn.com.do1.common.annotation.bean.DictDesc;
import cn.com.do1.common.annotation.bean.PageView;
import cn.com.do1.common.annotation.bean.Validation;
import cn.com.do1.common.framebase.dqdp.IBaseVO;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司 All rights reserved. User: zoulele
 */
public class TbYsjdDangerVo implements IBaseVO {
    private String id;

    @Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$", name = "danger")
    @PageView(showType = "input", showOrder = 1, showName = "danger", showLength = 36)
    private String danger;

    @Validation(must = false, length = 2, fieldType = "pattern", regex = "^.*$", name = "lightStatus")
    @PageView(showType = "input", showOrder = 2, showName = "lightStatus", showLength = 2)
    private String lightStatus;

    @Validation(must = false, length = 19, fieldType = "datetime", name = "creatorTime")
    @PageView(showType = "datetime", showOrder = 3, showName = "creatorTime", showLength = 19)
    private String creatorTime;

    @Validation(must = false, length = 11, fieldType = "pattern", regex = "^\\\\d*$", name = "sort")
    @PageView(showType = "input", showOrder = 4, showName = "sort", showLength = 11)
    private String sort;

    @Validation(must = false, length = 100, fieldType = "pattern", regex = "^.*$", name = "remark")
    @PageView(showType = "input", showOrder = 5, showName = "remark", showLength = 100)
    private String remark;
    
    @Validation(must=false, length=100, fieldType = "pattern",  regex = "^.*$", name ="regulationDepart") 
    @PageView(showType = "input", showOrder = 6, showName ="regulationDepart", showLength=100) 
    private java.lang.String regulationDepart;
    
    @DictDesc(refField = "lightStatus", typeName = "lightType")
    private java.lang.String lightType;
    
    private List<String> tableNames;

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return this.id;
    }

    public void setDanger(String danger) {
        this.danger = danger;
    }

    public String getDanger() {
        return this.danger;
    }

    public void setLightStatus(String lightStatus) {
        this.lightStatus = lightStatus;
    }

    public String getLightStatus() {
        return this.lightStatus;
    }

    public void setCreatorTime(String creatorTime) {
        this.creatorTime = creatorTime;
    }

    public String getCreatorTime() {
        return this.creatorTime;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public String getSort() {
        return this.sort;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getRemark() {
        return this.remark;
    }

    public java.lang.String getRegulationDepart() {
        return this.regulationDepart;
    }

    public void setRegulationDepart(java.lang.String regulationDepart) {
        this.regulationDepart = regulationDepart;
    }

    public java.lang.String getLightType() {
        return lightType;
    }

    public void setLightType(java.lang.String lightType) {
        this.lightType = lightType;
    }

    /**
     * 获取数据库中对应的表名
     * 
     * @return
     */
    public List<String> _getTableNames() {
        if (tableNames == null || tableNames.isEmpty()) {
            tableNames = Arrays.asList("TB_YSJD_DANGER".split(","));
        }
        return tableNames;
    }
}
