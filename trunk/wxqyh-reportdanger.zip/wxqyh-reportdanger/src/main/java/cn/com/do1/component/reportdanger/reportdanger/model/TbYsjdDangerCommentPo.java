package cn.com.do1.component.reportdanger.reportdanger.model;

import cn.com.do1.common.annotation.bean.PageView;
import cn.com.do1.common.annotation.bean.Validation;
import cn.com.do1.common.framebase.dqdp.IBaseDBVO;
import cn.com.do1.common.util.reflation.ConvertUtil;
import cn.com.do1.component.flow.flow.vo.IComment;
import java.util.Date;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class TbYsjdDangerCommentPo implements IBaseDBVO, IComment {
    private String commentId;

    @Validation(must = false, length = 64, fieldType = "pattern", regex = "^.*$")
    @PageView(showName = "reportdangerId", showType = "input", showOrder = 1, showLength = 64)
    private String reportdangerId;

    @Validation(must = false, length = 1024, fieldType = "pattern", regex = "^.*$")
    @PageView(showName = "content", showType = "input", showOrder = 2, showLength = 1024)
    private String content;

    @Validation(must = false, length = 36, fieldType = "pattern", regex = "^.*$")
    @PageView(showName = "creator", showType = "input", showOrder = 3, showLength = 36)
    private String creator;

    @Validation(must = false, length = 19, fieldType = "datetime", regex = "")
    @PageView(showName = "createTime", showType = "datetime", showOrder = 4, showLength = 19)
    private Date createTime;

    @Validation(must = false, length = 8, fieldType = "pattern", regex = "^.*$")
    @PageView(showName = "status", showType = "input", showOrder = 5, showLength = 8)
    private String status;
    private String personName;
    private String wxUserId;
    private String headPic;
    private String departmentName;
    private String departmentId;
    private String type;

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setCommentId(String commentId) {
        this.commentId = commentId;
    }

    public String getCommentId() {
        return this.commentId;
    }

    public void setReportdangerId(String reportdangerId) {
        this.reportdangerId = reportdangerId;
    }
    
    public String getReportdangerId() {
        return reportdangerId;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getContent() {
        return this.content;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getCreator() {
        return this.creator;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = ConvertUtil.cvStUtildate(createTime);
    }

    public Date getCreateTime() {
        return this.createTime;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return this.status;
    }

    public String _getTableName() {
        return "tb_ysjd_danger_comment";
    }

    public String _getPKColumnName() {
        return "commentId";
    }

    public String _getPKValue() {
        return String.valueOf(this.commentId);
    }

    public void _setPKValue(Object value) {
        this.commentId = ((String) value);
    }

    public String toString() {
        return new ReflectionToStringBuilder(this, ToStringStyle.SIMPLE_STYLE).toString();
    }

    public String getPersonName() {
        return this.personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getWxUserId() {
        return this.wxUserId;
    }

    public void setWxUserId(String wxUserId) {
        this.wxUserId = wxUserId;
    }

    public String getHeadPic() {
        return this.headPic;
    }

    public void setHeadPic(String headPic) {
        this.headPic = headPic;
    }

    public String getDepartmentName() {
        return this.departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getDepartmentId() {
        return this.departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void setUserIds(String userIds) {
    }
}
