/*
 * Copyright © 2014 广州市道一信息技术有限公司
 * All rights reserved.
 */
package cn.com.do1.component.reportdanger.reportdanger.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.sf.json.JSONObject;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.Region;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.do1.common.dac.Pager;
import cn.com.do1.common.exception.BaseException;
import cn.com.do1.common.framebase.struts.BaseAction;
import cn.com.do1.common.util.AssertUtil;
import cn.com.do1.component.addressbook.contact.service.IContactService;
import cn.com.do1.component.addressbook.contact.vo.TbManagerPersonVO;
import cn.com.do1.component.addressbook.contact.vo.TbQyUserInfoVO;
import cn.com.do1.component.addressbook.contact.vo.UserOrgVO;
import cn.com.do1.component.log.operationlog.service.IOperationlogService;
import cn.com.do1.component.report.report.model.TbReportTaskPO;
import cn.com.do1.component.report.report.vo.ReportTaskVO;
import cn.com.do1.component.reportdanger.reportdanger.service.ReportdangerService;
import cn.com.do1.component.reportdanger.reportdanger.vo.CountDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.SummaryDangerVo;
import cn.com.do1.component.systemmgr.person.model.TbDqdpPersonPO;
import cn.com.do1.component.util.Configuration;
import cn.com.do1.component.util.HttpUploadFileUtil;
import cn.com.do1.dqdp.core.DqdpAppContext;

public class DangerUtil extends BaseAction {
    private static final transient Logger logger = LoggerFactory.getLogger(DangerUtil.class);
    private static IOperationlogService operationlogService = (IOperationlogService) DqdpAppContext.getSpringContext()
            .getBean("operationlogService", IOperationlogService.class);
    private static IContactService contactService = (IContactService) DqdpAppContext.getSpringContext().getBean(
            "contactService", IContactService.class);
    private static ReportdangerService reportdangerService = (ReportdangerService) DqdpAppContext.getSpringContext()
            .getBean("reportdangerService", ReportdangerService.class);

    public static void exportDanger(ReportTaskVO report) {
        logger.info("导出整治情况统计表开始");
        OutputStream os = null;
        Map map = getSearchValue(report.getParam());
        if (AssertUtil.isEmpty(map)) {
            map = new HashMap();
        }
        String fileName = UUID.randomUUID().toString().replace("-", "").toLowerCase();
        File file = new File(Configuration.REPORT_FILE_TEMP_PATH + fileName + ".xlsx");
        try {
            os = new FileOutputStream(file);
            fileName = URLEncoder.encode(fileName, "UTF-8");

            HSSFWorkbook writeWB = new HSSFWorkbook();
            
            HSSFSheet writeSheet = writeWB.createSheet("整治情况统计表");
            int rowIndex = 0;
            HSSFRow writeRow = writeSheet.createRow(rowIndex);
            writeRow.createCell(0).setCellValue("社区 ");
            writeRow.createCell(1).setCellValue("红类出租屋（栋）");
            writeRow.createCell(2).setCellValue("隐患类别及描述");
            writeRow.createCell(3).setCellValue("整治部门");
            writeRow.createCell(4).setCellValue("期限内整治");
            writeRow.createCell(7).setCellValue("超时整治");

            rowIndex = rowIndex + 1;
            writeRow = writeSheet.createRow(rowIndex);
            writeRow.createCell(4).setCellValue("已治理 ");
            writeRow.createCell(5).setCellValue("处理中");
            writeRow.createCell(6).setCellValue("整治率");
            writeRow.createCell(7).setCellValue("已治理");
            writeRow.createCell(8).setCellValue("处理中");
            writeRow.createCell(9).setCellValue("整治率");
            
            //参数1：行号 参数2：起始列号 参数3：行号 参数4：终止列号
            Region region1 = new Region(0, (short) 0, 1, (short) 0);
            Region region2 = new Region(0, (short) 1, 1, (short) 1);
            Region region3 = new Region(0, (short) 2, 1, (short) 2);
            Region region4 = new Region(0, (short) 3, 1, (short) 3);
            Region region5 = new Region(0, (short) 4, 0, (short) 6);
            Region region6 = new Region(0, (short) 7, 0, (short) 9);
            writeSheet.addMergedRegion(region1);
            writeSheet.addMergedRegion(region2);
            writeSheet.addMergedRegion(region3);
            writeSheet.addMergedRegion(region4);
            writeSheet.addMergedRegion(region5);
            writeSheet.addMergedRegion(region6);

            String userId = report.getCreator();
            UserOrgVO userInfoVO = contactService.getOrgByUserId(userId);
            if (userInfoVO == null) {
                logger.error("获取登录人" + userId + "orgId的信息为空");
            } else {
                List<CountDangerVo> list = reportdangerService.searchMgrCountDangerVoList(map);
                if (list.size() > 0){
                    String communityName="";
                    int num = 0;
                    for (CountDangerVo vo : list) {
                        rowIndex++;
                        writeRow = writeSheet.createRow(rowIndex);
                        if("".equals(communityName)||!communityName.equals(vo.getCommunityName())){
                            writeRow.createCell(0).setCellValue(vo.getCommunityName());
                            if(!"".equals(communityName)){
                                if(num>1){
                                    //参数1：行号 参数2：起始列号 参数3：行号 参数4：终止列号
                                    Region region = new Region(rowIndex-num, (short) 0, rowIndex-1, (short) 0);
                                    writeSheet.addMergedRegion(region);
                                }
                                num = 0;
                            }
                            communityName = vo.getCommunityName();
                        }
                        writeRow.createCell(1).setCellValue(vo.getCountNum());
                        writeRow.createCell(2).setCellValue(vo.getDescribes());
                        writeRow.createCell(3).setCellValue(vo.getHandleDept());
                        writeRow.createCell(4).setCellValue(vo.getLeftHandle());
                        writeRow.createCell(5).setCellValue(vo.getLeftUntreated());
                        if(!"0".equals(vo.getProgressLeft())){
                            writeRow.createCell(6).setCellValue(vo.getProgressLeft()+"%");
                        }else{
                            writeRow.createCell(6).setCellValue(vo.getProgressLeft());
                        }
                        writeRow.createCell(7).setCellValue(vo.getRightHandle());
                        writeRow.createCell(8).setCellValue(vo.getRightUntreated());
                        if(!"0".equals(vo.getProgressRight())){
                            writeRow.createCell(9).setCellValue(vo.getProgressRight()+"%");
                        }else{
                            writeRow.createCell(9).setCellValue(vo.getProgressRight());
                        }
                        num ++;
                    }
                }
            }

            writeWB.write(os);
            updateReport(report, file, fileName);
        } catch (Exception e) {
            logger.error("导出整治情况统计表出错：" + e.getMessage(), e);
            report.setState("-1");
            report.setResultDesc(e.getMessage());
        } catch (BaseException e) {
            logger.error("导出整治情况统计表出错：" + e.getMessage(), e);
            report.setState("-1");
            report.setResultDesc(e.getMessage());
        } finally {
            try {
                if (os != null) {
                    os.close();
                }
                updateReportTask(report);
                if ((!AssertUtil.isEmpty(file)) && (file.exists()))
                    file.delete();
            } catch (IOException e) {
                logger.error("导出整治情况统计表,关闭io异常！！", e);
            } catch (SQLException e) {
                logger.error("导出整治情况统计表：" + e.getMessage(), e);
            }
        }
    }
    
    public static void exportSummaryDanger(ReportTaskVO report){
        logger.info("导出整治情况汇总表开始");
        OutputStream os = null;
        Map map = getSearchValue(report.getParam());
        if (AssertUtil.isEmpty(map)) {
            map = new HashMap();
        }
        String fileName = UUID.randomUUID().toString().replace("-", "").toLowerCase();
        File file = new File(Configuration.REPORT_FILE_TEMP_PATH + fileName + ".xlsx");
        try {
            os = new FileOutputStream(file);
            fileName = URLEncoder.encode(fileName, "UTF-8");
            Workbook writeWB = new SXSSFWorkbook(500);
            Pager pager = new Pager(Configuration.EXPORT_PAGE_SIZE);
            Sheet writeSheet = writeWB.createSheet("整治情况汇总表");
            int rowIndex = 0;
                  
            Row writeRow = writeSheet.createRow(rowIndex);
            writeRow.createCell(0).setCellValue("社区");
            writeRow.createCell(1).setCellValue("网格");
            writeRow.createCell(2).setCellValue("楼栋地址");
            writeRow.createCell(3).setCellValue("业主姓名");
            writeRow.createCell(4).setCellValue("业主电话");
            writeRow.createCell(5).setCellValue("隐患类别及描述");
            writeRow.createCell(6).setCellValue("采集时间");
            writeRow.createCell(7).setCellValue("整治进度");
            writeRow.createCell(8).setCellValue("整治时间");
            writeRow.createCell(9).setCellValue("处理结果");
            writeRow.createCell(10).setCellValue("备注");
            String userId = report.getCreator();
            UserOrgVO userInfoVO = contactService.getOrgByUserId(userId);
            if (userInfoVO == null) {
                logger.error("获取登录人" + userId + "orgId的信息为空");
            } else {
                pager = reportdangerService.searchSummaryDangerVoPager(map, pager);
                List<SummaryDangerVo> list = new ArrayList<SummaryDangerVo>();
                if(!AssertUtil.isEmpty(pager)){
                    list = (List<SummaryDangerVo>) pager.getPageData();
                }
                
                if (!AssertUtil.isEmpty(list) && list.size() > 0){
                    for (SummaryDangerVo vo : list) {
                        rowIndex++;
                        writeRow = writeSheet.createRow(rowIndex);
                        writeRow.createCell(0).setCellValue(vo.getCommunityName());
                        writeRow.createCell(1).setCellValue(vo.getGridName());
                        writeRow.createCell(2).setCellValue(vo.getBanAddress());
                        writeRow.createCell(3).setCellValue(vo.getOwner());
                        writeRow.createCell(4).setCellValue(vo.getOwnerPhone());
                        writeRow.createCell(5).setCellValue(vo.getDescribes());
                        writeRow.createCell(6).setCellValue(vo.getCreatorTime());
                        writeRow.createCell(7).setCellValue(vo.getStatusDesc());
                        writeRow.createCell(8).setCellValue(vo.getHandleTime());
                        writeRow.createCell(9).setCellValue(vo.getResult());
                        writeRow.createCell(10).setCellValue(vo.getRemark());
                    }
                }
            }
            writeWB.write(os);
            updateReport(report, file, fileName);
        } catch (Exception e) {
            logger.error("导出整治情况汇总表出错：" + e.getMessage(), e);
            report.setState("-1");
            report.setResultDesc(e.getMessage());
        } catch (BaseException e) {
            logger.error("导出整治情况汇总表出错：" + e.getMessage(), e);
            report.setState("-1");
            report.setResultDesc(e.getMessage());
        } finally {
            try {
                if (os != null) {
                    os.close();
                }
                updateReportTask(report);
                if ((!AssertUtil.isEmpty(file)) && (file.exists()))
                file.delete();
            } catch (IOException e) {
                logger.error("导出整治情况汇总表,关闭io异常！！", e);
            } catch (SQLException e) {
                logger.error("导出整治情况汇总表：" + e.getMessage(), e);
            }
        }
    }

    public static void updateReportTask(ReportTaskVO report) throws SQLException {
        TbReportTaskPO po = new TbReportTaskPO();
        po.setId(report.getId());
        po.setState(report.getState());
        po.setFilePath(report.getFilePath());
        po.setFileSize(report.getFileSize());
        po.setResultDesc(report.getResultDesc());
        po.setFileType(report.getFileType());
        operationlogService.updatePO(po, false);
    }

    public static void updateReport(ReportTaskVO report, File file, String fileName) {
        String urlString = HttpUploadFileUtil.uploadFile(file, "xlsx", false, report.getOrgId(), "file", fileName);
        if (!AssertUtil.isEmpty(urlString)) {
            report.setFilePath(urlString);
            report.setState("1");
            report.setResultDesc("导出成功");
            report.setFileType("xlsx");
            report.setFileSize(Long.valueOf(file.length()));
        }
    }

    public static Map<String, Object> getSearchValue(Object object) {
        HashMap data = new HashMap();

        JSONObject jsonObject = JSONObject.fromObject(object);
        Iterator it = jsonObject.keys();

        while (it.hasNext()) {
            String key = String.valueOf(it.next());
            String value = (String) jsonObject.get(key);
            data.put(key, value);
        }
        if (AssertUtil.isEmpty(data)) {
            data = new HashMap();
        }
        return data;
    }

}
