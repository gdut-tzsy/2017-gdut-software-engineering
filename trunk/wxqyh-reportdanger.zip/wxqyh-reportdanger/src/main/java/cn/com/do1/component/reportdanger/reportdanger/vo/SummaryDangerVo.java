package cn.com.do1.component.reportdanger.reportdanger.vo;

import cn.com.do1.common.annotation.bean.FormatMask;


/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司 All rights reserved. User: zoulele
 */
public class SummaryDangerVo{
    private String id;
    private String community;
    private String communityName;
    private String grid;
    private String gridName;
    private String banAddress;
    private String owner;
    private String ownerPhone;
    private String describes;
    @FormatMask(type = "date", value = "yyyy-MM-dd HH:mm")
    private String creatorTime;
    private String statusDesc;
    @FormatMask(type = "date", value = "yyyy-MM-dd HH:mm")
    private String handleTime;
    private String address;
    private String result;
    private String remark;
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getCommunity() {
        return community;
    }
    public void setCommunity(String community) {
        this.community = community;
    }
    public String getCommunityName() {
        return communityName;
    }
    public void setCommunityName(String communityName) {
        this.communityName = communityName;
    }
    public String getGrid() {
        return grid;
    }
    public void setGrid(String grid) {
        this.grid = grid;
    }
    public String getGridName() {
        return gridName;
    }
    public void setGridName(String gridName) {
        this.gridName = gridName;
    }
    public String getBanAddress() {
        return banAddress;
    }
    public void setBanAddress(String banAddress) {
        this.banAddress = banAddress;
    }
    public String getOwner() {
        return owner;
    }
    public void setOwner(String owner) {
        this.owner = owner;
    }
    public String getOwnerPhone() {
        return ownerPhone;
    }
    public void setOwnerPhone(String ownerPhone) {
        this.ownerPhone = ownerPhone;
    }
    public String getDescribes() {
        return describes;
    }
    public void setDescribes(String describes) {
        this.describes = describes;
    }
    public String getCreatorTime() {
        return creatorTime;
    }
    public void setCreatorTime(String creatorTime) {
        this.creatorTime = creatorTime;
    }
    public String getStatusDesc() {
        return statusDesc;
    }
    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }
    public String getHandleTime() {
        return handleTime;
    }
    public void setHandleTime(String handleTime) {
        this.handleTime = handleTime;
    }
    public String getResult() {
        return result;
    }
    public void setResult(String result) {
        this.result = result;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
}
