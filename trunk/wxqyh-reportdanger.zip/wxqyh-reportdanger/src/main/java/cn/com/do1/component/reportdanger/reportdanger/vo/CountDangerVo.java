package cn.com.do1.component.reportdanger.reportdanger.vo;


/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司 All rights reserved. User: zoulele
 */
public class CountDangerVo{
    private String handleDept;
    private String communityName;
    private String describes;
    private String title;
    private String titleSmallLeft;
    private String titleSmallRight;
    private String progressLeft;
    private String progressRight;
    private String leftUntreated;
    private String leftHandle;
    private String rightUntreated;
    private String rightHandle;
    private String community;
    private String countNum;
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getTitleSmallLeft() {
        return titleSmallLeft;
    }
    public void setTitleSmallLeft(String titleSmallLeft) {
        this.titleSmallLeft = titleSmallLeft;
    }
    public String getTitleSmallRight() {
        return titleSmallRight;
    }
    public void setTitleSmallRight(String titleSmallRight) {
        this.titleSmallRight = titleSmallRight;
    }
    public String getProgressLeft() {
        return progressLeft;
    }
    public void setProgressLeft(String progressLeft) {
        this.progressLeft = progressLeft;
    }
    public String getProgressRight() {
        return progressRight;
    }
    public void setProgressRight(String progressRight) {
        this.progressRight = progressRight;
    }
    public String getLeftUntreated() {
        return leftUntreated;
    }
    public void setLeftUntreated(String leftUntreated) {
        this.leftUntreated = leftUntreated;
    }
    public String getLeftHandle() {
        return leftHandle;
    }
    public void setLeftHandle(String leftHandle) {
        this.leftHandle = leftHandle;
    }
    public String getRightUntreated() {
        return rightUntreated;
    }
    public void setRightUntreated(String rightUntreated) {
        this.rightUntreated = rightUntreated;
    }
    public String getRightHandle() {
        return rightHandle;
    }
    public void setRightHandle(String rightHandle) {
        this.rightHandle = rightHandle;
    }
    public String getCommunity() {
        return community;
    }
    public void setCommunity(String community) {
        this.community = community;
    }
    public String getHandleDept() {
        return handleDept;
    }
    public void setHandleDept(String handleDept) {
        this.handleDept = handleDept;
    }
    public String getCommunityName() {
        return communityName;
    }
    public void setCommunityName(String communityName) {
        this.communityName = communityName;
    }
    public String getDescribes() {
        return describes;
    }
    public void setDescribes(String describes) {
        this.describes = describes;
    }
    public String getCountNum() {
        return countNum;
    }
    public void setCountNum(String countNum) {
        this.countNum = countNum;
    }
    
}
