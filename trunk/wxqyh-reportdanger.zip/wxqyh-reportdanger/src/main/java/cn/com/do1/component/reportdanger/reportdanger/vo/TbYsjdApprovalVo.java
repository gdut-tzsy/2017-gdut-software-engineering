package cn.com.do1.component.reportdanger.reportdanger.vo;

import cn.com.do1.common.framebase.dqdp.IBaseVO;
import cn.com.do1.common.util.reflation.ConvertUtil;
import cn.com.do1.common.annotation.bean.PageView;
import cn.com.do1.common.annotation.bean.Validation;
import cn.com.do1.common.annotation.bean.DictDesc;
import cn.com.do1.common.annotation.bean.FormatMask;

import java.util.Date;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司 All rights reserved. User: zoulele
 */
public class TbYsjdApprovalVo {
    private java.lang.String id;
    private java.lang.String reportdangerId;
    private java.lang.String approvalName;
    private java.lang.String describes;
    private java.lang.String userId;
    private java.lang.String wxUserId;
    private java.lang.String createUser;
    @FormatMask(type = "date", value = "yyyy-MM-dd HH:mm")
    private java.lang.String createTime;
    @FormatMask(type = "date", value = "yyyy-MM-dd HH:mm:ss")
    private java.lang.String updateTime;
    private String status;
    private java.lang.String sort;
    private java.lang.String remarks;


    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return this.id;
    }

    public java.lang.String getReportdangerId() {
        return reportdangerId;
    }

    public void setReportdangerId(java.lang.String reportdangerId) {
        this.reportdangerId = reportdangerId;
    }

    public java.lang.String getApprovalName() {
        return approvalName;
    }

    public void setApprovalName(java.lang.String approvalName) {
        this.approvalName = approvalName;
    }

    public java.lang.String getDescribes() {
        return describes;
    }

    public void setDescribes(java.lang.String describes) {
        this.describes = describes;
    }

    public java.lang.String getUserId() {
        return userId;
    }

    public void setUserId(java.lang.String userId) {
        this.userId = userId;
    }

    public java.lang.String getWxUserId() {
        return wxUserId;
    }

    public void setWxUserId(java.lang.String wxUserId) {
        this.wxUserId = wxUserId;
    }

    public java.lang.String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(java.lang.String createUser) {
        this.createUser = createUser;
    }

    public java.lang.String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(java.lang.String createTime) {
        this.createTime = createTime;
    }

    public java.lang.String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(java.lang.String updateTime) {
        this.updateTime = updateTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public java.lang.String getSort() {
        return sort;
    }

    public void setSort(java.lang.String sort) {
        this.sort = sort;
    }

    public java.lang.String getRemarks() {
        return remarks;
    }

    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }
}
