package cn.com.do1.component.reportdanger.reportdanger.job;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.do1.common.exception.BaseException;
import cn.com.do1.common.util.AssertUtil;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdReportdangerPo;
import cn.com.do1.component.reportdanger.reportdanger.service.ReportdangerService;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdReportdangerVo;
import cn.com.do1.dqdp.core.ConfigMgr;
import cn.com.do1.dqdp.core.DqdpAppContext;

/**
 * 
 * <p>
 * ClassName: 个人主页定时任务
 * </p>
 * <p>
 * Description: 定时发布等调用的类
 * </p>
 * <p>
 * Author: cuijianpeng
 * </p>
 * <p>
 * Date: 2016年12月5日
 * </p>
 */
public class ReportdangerTask implements Job {
    private static final transient Logger logger = LoggerFactory.getLogger(ReportdangerTask.class);
    private ReportdangerService reportdangerService = (ReportdangerService) DqdpAppContext.getSpringContext().getBean(
            "reportdangerService", ReportdangerService.class);

    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        try {
            logger.info("##隐患信息定时任务开始");

            sendDangerTask();

            logger.info("##隐患信息定时任务结束");
        } catch (Exception e) {
            logger.error("隐患信息定时任务失败", e);
        } catch (BaseException e) {
            logger.error("隐患信息定时任务失败", e);
        }
    }

    /**
     * 
     * <p>
     * Description: 发送定时的信息
     * </p>
     * 
     * @throws Exception
     * @throws BaseException
     */
    private void sendDangerTask() throws Exception, BaseException {
        
        //获取定时发送的集合数据
        List<TbYsjdReportdangerVo> list = this.reportdangerService.getReportdangerVo();

        if (!AssertUtil.isEmpty(list)  && list.size() > 0) {
            logger.debug("____________获取到没有处理的隐患信息" + list.size() + "定时任务_________________");
            for (TbYsjdReportdangerVo vo : list) {
                if(isOvertimeStatus(vo.getReportTime())){
                    TbYsjdReportdangerPo po = new TbYsjdReportdangerPo();
                    po.setId(vo.getId());
                    po.setOvertimeStatus("1");
                    this.reportdangerService.updatePO(po, false);
                }
            }
            logger.debug("____________定时任务结束--隐患信息" + list.size() + "定时任务_________________");
        }
        
    }
    
    private Boolean isOvertimeStatus(String reportTime) {
        String overtimeDay=ConfigMgr.get("reportdanger", "overtimeDay", "7");
        Integer overtime = Integer.parseInt(overtimeDay);
        SimpleDateFormat dft = new SimpleDateFormat("yyyy-MM-dd");
        Date beginDate = new Date();
        Calendar date = Calendar.getInstance();
        date.setTime(beginDate);
        date.set(Calendar.DATE, date.get(Calendar.DATE) - overtime);
        try {
            Date bt=dft.parse(reportTime);
            Date et = dft.parse(dft.format(date.getTime()));
            if (bt.before(et)){ 
                //表示bt小于et 未超时
                return true;
            }else{ 
                // 超时 
                return false;
            } 
        } catch (ParseException e) {
            return false;
        }
    }
}
