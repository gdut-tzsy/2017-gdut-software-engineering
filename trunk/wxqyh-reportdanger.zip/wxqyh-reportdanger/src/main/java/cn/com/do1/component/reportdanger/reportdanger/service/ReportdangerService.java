package cn.com.do1.component.reportdanger.reportdanger.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import cn.com.do1.common.dac.Pager;
import cn.com.do1.common.exception.BaseException;
import cn.com.do1.common.exception.CannotSafeDelException;
import cn.com.do1.common.exception.DataConfictException;
import cn.com.do1.common.exception.ObjectNotFoundException;
import cn.com.do1.common.framebase.dqdp.IBaseService;
import cn.com.do1.common.util.security.EncryptionUtils;
import cn.com.do1.component.addressbook.contact.vo.UserInfoVO;
import cn.com.do1.component.addressbook.contact.vo.UserOrgVO;
import cn.com.do1.component.addressbook.department.vo.TbDepartmentInfoVO;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdDangerCommentPo;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdReportdangerPo;
import cn.com.do1.component.reportdanger.reportdanger.vo.CountDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.SummaryDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdApprovalVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdBanVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdRecipientVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdReportdangerVo;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司
 * All rights reserved.
 * User: zoulele
 */
public interface ReportdangerService extends IBaseService {

	Pager searchTbYsjdReportdanger(Map<String, Object> searchValue, Pager pager)
			throws Exception, BaseException;

	List<TbYsjdReportdangerVo> searchTbYsjdReportdangerList(
			Map<String, Object> searchValue) throws SQLException;

	void casAdd(TbYsjdReportdangerPo po) throws Exception, DataConfictException;

	List<TbYsjdReportdangerPo> casQuery(String[] fields, Object[] values,
			String appendSql) throws Exception,
			EncryptionUtils.EncryptionException;

	void casDel(String id) throws Exception, ObjectNotFoundException,
			CannotSafeDelException;
	
	public abstract void saveBranchFlow(String paramString, Map<String, String> paramMap, UserOrgVO paramUserOrgVO)
	          throws Exception, BaseException;
	
    public TbDepartmentInfoVO searchDepartmentInfoVO(String deptFullName) throws SQLException;
    public List<TbYsjdBanVo> searchYsjdBanVo(Map<String, Object> map) throws SQLException;
    public List<TbYsjdDangerVo> searchYsjdDangerVo(String lightStatus) throws SQLException;
    /**
     * 新增一般隐患上报
     * <p>Description: TODO</p>
     * @param po
     * @param userInfoVO
     * @param relatives
     * @param imageUrls
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年8月29日</p>
     */
    public void addReportdangerPO(TbYsjdReportdangerPo po, UserInfoVO userInfoVO, String relatives, String imageUrls) throws Exception,BaseException;
    /**
     * 新增重点隐患上报
     * <p>Description: TODO</p>
     * @param po
     * @param userInfoVO
     * @param relatives
     * @param imageUrls
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年8月29日</p>
     */
    public void addReportdangerPO(TbYsjdReportdangerPo po, UserInfoVO userInfoVO, String relatives, String imageUrls, String flowId, String flowDpId, String choiseFlowUser, Map<String, String> branchMap) throws Exception, BaseException;
    public List<TbYsjdDangerCommentPo> getCommentsByUserID(String userId, String reportdangerId) throws BaseException, Exception;
    public List<String> getDangerUser(Map<String, Object> paramMap) throws Exception, BaseException;
    public TbYsjdReportdangerVo getTbYsjdReportdangerVo(String id) throws SQLException;
    public List<TbYsjdReportdangerVo> getReportdangerVo() throws Exception, BaseException;
    public List<TbYsjdRecipientVo> getDangerRecipient(String reportdangerId, String type) throws Exception, BaseException;
    public void agreeAudit(TbYsjdReportdangerPo po, String reason, String userId, String orgId, String signImg)
            throws Exception, BaseException;
    public void updataAuditStatus(TbYsjdReportdangerPo po, UserInfoVO operatorUser, String status, String dpId, String reason, String choiseFlowUser, String signImg, Map<String, String> branchMap,String[] mediaIds,String imageUrls)
            throws Exception, BaseException;
    public void updataStatus(TbYsjdReportdangerPo po, UserInfoVO operatorUser, String status, String reason, String[] mediaIds,String imageUrls) throws Exception,BaseException;
    public void updataDangerPo(TbYsjdReportdangerPo po, UserInfoVO operatorUser, String reason,String[] mediaIds,String imageUrls) throws Exception,BaseException;
    /**
     * 获取评论信息
     * <p>Description: TODO</p>
     * @param map
     * @param comments
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年8月25日</p>
     */
    public Pager getDangerComment(Map map, Pager comments) throws BaseException, Exception;
    
    /**
     * 删除评论
     * <p>Description: TODO</p>
     * @param commentId
     * @throws BaseException
     * @throws Exception
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年8月25日</p>
     */
    public void updateCommentStatus(String commentId) throws BaseException, Exception;
    
    /**
     * 查询上报处理信息
     * <p>Description: TODO</p>
     * @param reportdangerId 上报ID
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年8月30日</p>
     */
    public List<TbYsjdApprovalVo> getApprovalVoList(String reportdangerId) throws Exception, BaseException;

    /**
     * 查询隐患统计
     * <p>Description: TODO</p>
     * @param reportdangerId 上报ID
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年9月1日</p>
     */
    public List<CountDangerVo> searchCountDangerVoList(Map<String, Object> paramMap) throws Exception, BaseException;

    /**
     * 查询隐患统计
     * <p>Description: TODO</p>
     * @param reportdangerId 上报ID
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年9月1日</p>
     */
    public List<CountDangerVo> searchMgrCountDangerVoList(Map<String, Object> paramMap) throws Exception, BaseException;

    /**
     * 整治情况汇总表
     * <p>Description: TODO</p>
     * @param reportdangerId 上报ID
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年9月1日</p>
     */
    public Pager searchSummaryDangerVoPager(Map searchValue,Pager pager) throws Exception, BaseException;
}
