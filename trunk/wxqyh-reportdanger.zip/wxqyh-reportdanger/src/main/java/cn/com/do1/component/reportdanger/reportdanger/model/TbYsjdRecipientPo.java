package cn.com.do1.component.reportdanger.reportdanger.model;

import cn.com.do1.common.annotation.bean.PageView;
import cn.com.do1.common.annotation.bean.Validation;
import cn.com.do1.common.framebase.dqdp.IBaseDBVO;
import cn.com.do1.common.util.reflation.ConvertUtil;
import cn.com.do1.component.flow.flow.vo.IReceive;
import java.util.Date;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class TbYsjdRecipientPo implements IBaseDBVO, IReceive {
    private String recipientId;

    @Validation(must = false, length = 64, fieldType = "pattern", regex = "^.*$")
    @PageView(showName = "reportdangerId", showType = "input", showOrder = 1, showLength = 64)
    private String reportdangerId;

    @Validation(must = false, length = 64, fieldType = "pattern", regex = "^.*$")
    @PageView(showName = "userId", showType = "input", showOrder = 2, showLength = 64)
    private String userId;

    @Validation(must = false, length = 8, fieldType = "pattern", regex = "^.*$")
    @PageView(showName = "userType", showType = "input", showOrder = 3, showLength = 8)
    private String userType;

    @Validation(must = false, length = 64, fieldType = "pattern", regex = "^.*$")
    @PageView(showName = "createPerson", showType = "input", showOrder = 4, showLength = 64)
    private String createPerson;

    @Validation(must = false, length = 19, fieldType = "datetime", regex = "")
    @PageView(showName = "createTime", showType = "datetime", showOrder = 5, showLength = 19)
    private Date createTime;
    private String isAudit;
    private String personName;
    private String wxUserId;
    private String headPic;
    private String departmentName;
    private String departmentId;
    private Integer recipientOrder;

    public Integer getRecipientOrder() {
        return this.recipientOrder;
    }

    public void setRecipientOrder(Integer recipientOrder) {
        this.recipientOrder = recipientOrder;
    }

    public void setRecipientId(String recipientId) {
        this.recipientId = recipientId;
    }

    public String getRecipientId() {
        return this.recipientId;
    }

    public void setReportdangerId(String reportdangerId) {
        this.reportdangerId = reportdangerId;
    }

    public String getReportdangerId() {
        return this.reportdangerId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getUserType() {
        return this.userType;
    }

    public void setCreatePerson(String createPerson) {
        this.createPerson = createPerson;
    }

    public String getCreatePerson() {
        return this.createPerson;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = ConvertUtil.cvStUtildate(createTime);
    }

    public Date getCreateTime() {
        return this.createTime;
    }

    public String _getTableName() {
        return "tb_ysjd_recipient";
    }

    public String _getPKColumnName() {
        return "recipientId";
    }

    public String _getPKValue() {
        return String.valueOf(this.recipientId);
    }

    public void _setPKValue(Object value) {
        this.recipientId = ((String) value);
    }

    public String toString() {
        return new ReflectionToStringBuilder(this, ToStringStyle.SIMPLE_STYLE).toString();
    }

    public String getPersonName() {
        return this.personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getWxUserId() {
        return this.wxUserId;
    }

    public void setWxUserId(String wxUserId) {
        this.wxUserId = wxUserId;
    }

    public String getHeadPic() {
        return this.headPic;
    }

    public void setHeadPic(String headPic) {
        this.headPic = headPic;
    }

    public String getDepartmentName() {
        return this.departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getDepartmentId() {
        return this.departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public String getIsAudit() {
        return this.isAudit;
    }

    public void setIsAudit(String isAudit) {
        this.isAudit = isAudit;
    }

    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void setSort(Integer sort) {
    }
}
