package cn.com.do1.component.reportdanger.reportdanger.service.impl;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.com.do1.common.dac.Pager;
import cn.com.do1.common.exception.BaseException;
import cn.com.do1.common.exception.CannotSafeDelException;
import cn.com.do1.common.exception.DataConfictException;
import cn.com.do1.common.exception.NonePrintException;
import cn.com.do1.common.exception.ObjectNotFoundException;
import cn.com.do1.common.framebase.dqdp.BaseService;
import cn.com.do1.common.util.AssertUtil;
import cn.com.do1.common.util.DateUtil;
import cn.com.do1.common.util.security.EncryptionUtils;
import cn.com.do1.common.util.string.StringUtil;
import cn.com.do1.component.addressbook.contact.model.ExtOrgPO;
import cn.com.do1.component.addressbook.contact.model.TbQyPicPO;
import cn.com.do1.component.addressbook.contact.service.IContactService;
import cn.com.do1.component.addressbook.contact.vo.TbQyUserInfoVO;
import cn.com.do1.component.addressbook.contact.vo.UserDeptInfoExpandVO;
import cn.com.do1.component.addressbook.contact.vo.UserInfoVO;
import cn.com.do1.component.addressbook.contact.vo.UserOrgVO;
import cn.com.do1.component.addressbook.contact.vo.UserRedundancyInfoVO;
import cn.com.do1.component.addressbook.department.vo.TbDepartmentInfoVO;
import cn.com.do1.component.defatgroup.defatgroup.service.IDefatgroupService;
import cn.com.do1.component.flow.flow.model.TbQyFlowBranchInfoPO;
import cn.com.do1.component.flow.flow.model.TbQyFlowNodePO;
import cn.com.do1.component.flow.flow.model.TbQyFlowRefPO;
import cn.com.do1.component.flow.flow.model.TbQyFlowTemplatePO;
import cn.com.do1.component.flow.flow.model.TbQyNodeBranchGroupPO;
import cn.com.do1.component.flow.flow.model.TbQyNodeConditionPO;
import cn.com.do1.component.flow.flow.service.IFlowAuditService;
import cn.com.do1.component.flow.flow.service.IFlowTemplateService;
import cn.com.do1.component.flow.flow.util.FlowUtil;
import cn.com.do1.component.flow.flow.vo.FlowAuditHelpVO;
import cn.com.do1.component.flow.flow.vo.FlowAuditStatusResult;
import cn.com.do1.component.flow.flow.vo.FlowAuditVO;
import cn.com.do1.component.reportdanger.reportdanger.dao.ReportdangerDao;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdApprovalPo;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdBanPO;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdDangerCommentPo;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdRecipientPo;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdReportdangerPo;
import cn.com.do1.component.reportdanger.reportdanger.service.ReportdangerService;
import cn.com.do1.component.reportdanger.reportdanger.vo.CountDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.SummaryDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdApprovalVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdBanVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdRecipientVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdReportdangerVo;
import cn.com.do1.component.todo.todo.service.IToDoService;
import cn.com.do1.component.uploadfile.imageupload.service.IFileMediaService;
import cn.com.do1.component.util.Configuration;
import cn.com.do1.component.util.ListUtil;
import cn.com.do1.component.util.UUID32;
import cn.com.do1.component.workflow.workflow.service.IWorkflowService;
import cn.com.do1.component.wxcgiutil.WxMessageUtil;
import cn.com.do1.component.wxcgiutil.message.NewsMessageVO;
import cn.com.do1.dqdp.core.ConfigMgr;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司 All rights reserved. User: zoulele
 */
@Service("reportdangerService")
public class ReportdangerServiceImpl extends BaseService implements ReportdangerService {
    private final static transient Logger logger = LoggerFactory.getLogger(ReportdangerServiceImpl.class);
    public final static String REPORTDANGER_CODE = "reportdanger";
    private ReportdangerDao reportdangerDao;
    private IContactService contactService;
    private IFlowAuditService flowAuditService;
    private IFlowTemplateService flowTemplateService;
    private IToDoService todoService;
    private IDefatgroupService defatgroupService;
    private IWorkflowService workflowService;
    private IFileMediaService fileMediaService;
    
    @Resource
    public void setFileMediaService(IFileMediaService fileMediaService) {
        this.fileMediaService = fileMediaService;
    }
    
    @Resource(name = "defatgroupService")
    public void setDefatgroupService(IDefatgroupService defatgroupService) {
        this.defatgroupService = defatgroupService;
    }

    @Resource
    public void setReportdangerDAO(ReportdangerDao reportdangerDao) {
        this.reportdangerDao = reportdangerDao;
        setDAO(reportdangerDao);
    }

    @Resource(name = "flowAuditService")
    public void setFlowAuditService(IFlowAuditService flowAuditService) {
        this.flowAuditService = flowAuditService;
    }

    @Resource(name = "flowTemplateService")
    public void setFlowTemplateService(IFlowTemplateService flowTemplateService) {
        this.flowTemplateService = flowTemplateService;
    }

    @Resource(name = "todoService")
    public void setTodoService(IToDoService todoService) {
        this.todoService = todoService;
    }

    @Resource(name = "workflowService")
    public void setWorkflowService(IWorkflowService workflowService) {
        this.workflowService = workflowService;
    }

    public IContactService getContactService() {
        return this.contactService;
    }

    @Resource(name = "contactService")
    public void setContactService(IContactService contactService) {
        this.contactService = contactService;
    }

    @Override
    public Pager searchTbYsjdReportdanger(Map<String, Object> searchMap , Pager pager) throws Exception, BaseException {
        if(searchMap.containsKey("status")){
            String status = (String) searchMap.get("status");
            searchMap.put("status", status.split(","));
        }
        if(searchMap.containsKey("overtimeStatus")){
            String overtimeStatus = (String) searchMap.get("overtimeStatus");
            searchMap.put("overtimeStatus", overtimeStatus.split(","));
        }
        Pager pageData = reportdangerDao.searchTbYsjdReportdanger(searchMap, pager);
        if (!AssertUtil.isEmpty(pageData.getPageData())) {
            List<TbYsjdReportdangerVo> list = (List<TbYsjdReportdangerVo>) pageData.getPageData();
            for (TbYsjdReportdangerVo vo : list) {
                List<TbQyPicPO> picList = this.contactService.getPicListByGroupId(vo.getId());
            }
        }
        return pageData;
    }

    private Boolean isOvertimeStatus(String reportTime) {
        String overtimeDay = ConfigMgr.get("reportdanger", "overtimeDay", "7");
        Integer overtime = Integer.parseInt(overtimeDay);
        SimpleDateFormat dft = new SimpleDateFormat("yyyy-MM-dd");
        Date beginDate = new Date();
        Calendar date = Calendar.getInstance();
        date.setTime(beginDate);
        date.set(Calendar.DATE, date.get(Calendar.DATE) - overtime);
        try {
            Date bt = dft.parse(reportTime);
            Date et = dft.parse(dft.format(date.getTime()));
            if (bt.before(et)) {
                //表示bt小于et 未超时
                return true;
            } else {
                // 超时 
                return false;
            }
        } catch (ParseException e) {
            return false;
        }
    }

    @Override
    public List<TbYsjdReportdangerVo> searchTbYsjdReportdangerList(Map<String, Object> searchValue) throws SQLException {
        return reportdangerDao.searchTbYsjdReportdangerList(searchValue);
    }

    @Override
    public TbYsjdReportdangerVo getTbYsjdReportdangerVo(String id) throws SQLException {
        return reportdangerDao.getTbYsjdReportdangerVo(id);
    }

    /**
     * 删除对象，只需要对象里的主键有值即可
     * 
     * @param userPO
     * @throws Exception
     */
    public void delPO(TbYsjdReportdangerPo po) throws Exception, ObjectNotFoundException, CannotSafeDelException {
        reportdangerDao.delete(po);
    }

    @Override
    public void casAdd(TbYsjdReportdangerPo po) throws Exception, DataConfictException {
        reportdangerDao.insert(po);
    }

    @Override
    public List<TbYsjdReportdangerPo> casQuery(String[] fields, Object[] values, String appendSql) throws Exception,
            EncryptionUtils.EncryptionException {
        return reportdangerDao.searchByField(TbYsjdReportdangerPo.class, fields, values, appendSql);
    }

    @Override
    public void casDel(String id) throws Exception, ObjectNotFoundException, CannotSafeDelException {
        TbYsjdReportdangerPo po = new TbYsjdReportdangerPo();
        po._setPKValue(id);
        reportdangerDao.delete(po);
    }

    public void saveBranchFlow(String flowBranchJson, Map<String, String> flowInfoMap, UserOrgVO userInfoVO)
            throws Exception, BaseException {
        Map dataMap = FlowUtil.handFlowBranchInfo(null, flowBranchJson, flowInfoMap);

        delOldBrancData((Map) dataMap.get("delMap"));

        Boolean hasFlowTemplate = (Boolean) dataMap.get("hasFlowTemplate");
        if (!hasFlowTemplate.booleanValue()) {
            TbQyFlowTemplatePO flowTemplateInfo = (TbQyFlowTemplatePO) dataMap.get("flowTemplateInfo");
            insertPO(flowTemplateInfo, false);
        }

        Boolean hasRefPO = (Boolean) dataMap.get("hasRefPO");
        if (!hasRefPO.booleanValue()) {
            TbQyFlowRefPO tbQyFlowRefPO = (TbQyFlowRefPO) dataMap.get("tbQyFlowRefPO");
            insertPO(tbQyFlowRefPO, false);
        }

        List flowBranchList = (List) dataMap.get("flowBranchList");
        if (!AssertUtil.isEmpty(flowBranchList))
            batchInsertflowBranchPO(flowBranchList);
        else {
            throw new NonePrintException(1014, "保存失败，分支信息为空");
        }

        List nodePOList = (List) dataMap.get("nodePOList");
        if (!AssertUtil.isEmpty(nodePOList)) {
            batchInsertNodePO(nodePOList);
        }
        this.flowTemplateService.batchInsertNodeRefInfo(((TbQyFlowBranchInfoPO) flowBranchList.get(0)).getFlowId(),
                dataMap);

        List groupPOList = (List) dataMap.get("groupPOList");
        if (!AssertUtil.isEmpty(groupPOList)) {
            batchInsertGroupPO(groupPOList);
        }

        List conditionPOList = (List) dataMap.get("conditionPOList");
        if (!AssertUtil.isEmpty(conditionPOList)) {
            batchInsertConditionPO(conditionPOList);
        }
        this.contactService.insertOperationLog(userInfoVO.getUserName(), userInfoVO.getPersonName(), "更新分支流程", "edit",
                "ask", userInfoVO.getOrgId(), "更新成功");
    }

    private void delOldBrancData(Map<String, List<String>> delMap) throws Exception, BaseException {
        if (!AssertUtil.isEmpty(delMap)) {
            List delNodeList = (List) delMap.get("delNodeList");
            List delFlowBranchList = (List) delMap.get("delFlowBranchList");
            List delBranchGroupList = (List) delMap.get("delBranchGroupList");
            List delNodeConditionList = (List) delMap.get("delNodeConditionList");
            if (!AssertUtil.isEmpty(delNodeList)) {
                String[] delNodeIds = (String[]) delNodeList.toArray(new String[delNodeList.size()]);
                batchDel(TbQyFlowNodePO.class, delNodeIds);
            }
            if (!AssertUtil.isEmpty(delFlowBranchList)) {
                String[] delFlowBranchIds = (String[]) delFlowBranchList.toArray(new String[delFlowBranchList.size()]);
                batchDel(TbQyFlowBranchInfoPO.class, delFlowBranchIds);
            }
            if (!AssertUtil.isEmpty(delBranchGroupList)) {
                String[] delBranchGroupIds = (String[]) delBranchGroupList
                        .toArray(new String[delBranchGroupList.size()]);
                batchDel(TbQyNodeBranchGroupPO.class, delBranchGroupIds);
            }
            if (!AssertUtil.isEmpty(delNodeConditionList)) {
                String[] delNodeConditionIds = (String[]) delNodeConditionList.toArray(new String[delNodeConditionList
                        .size()]);
                batchDel(TbQyNodeConditionPO.class, delNodeConditionIds);
            }
        }
    }

    private void batchInsertflowBranchPO(List<TbQyFlowBranchInfoPO> flowBranchList) throws BaseException, Exception {
        this.reportdangerDao.execBatchInsert(flowBranchList);
    }

    public void batchInsertNodePO(List<TbQyFlowNodePO> nodePOList) throws BaseException, Exception {
        this.reportdangerDao.execBatchInsert(nodePOList);
    }

    public void batchInsertGroupPO(List<TbQyNodeBranchGroupPO> groupPOList) throws BaseException, Exception {
        this.reportdangerDao.execBatchInsert(groupPOList);
    }

    public void batchInsertConditionPO(List<TbQyNodeConditionPO> conditionPOList) throws BaseException, Exception {
        this.reportdangerDao.execBatchInsert(conditionPOList);
    }

    public TbDepartmentInfoVO searchDepartmentInfoVO(String deptFullName) throws SQLException {
        return this.reportdangerDao.searchDepartmentInfoVO(deptFullName);
    }

    @Override
    public List<TbYsjdBanVo> searchYsjdBanVo(Map<String, Object> map) throws SQLException {
        return this.reportdangerDao.searchYsjdBanVo(map);
    }

    @Override
    public List<TbYsjdDangerVo> searchYsjdDangerVo(String lightStatus) throws SQLException {
        return this.reportdangerDao.searchYsjdDangerVo(lightStatus);
    }

    @Override
    public void addReportdangerPO(TbYsjdReportdangerPo po, UserInfoVO userInfoVO, String relatives, String imageUrls,
            String flowId, String flowDpId, String choiseFlowUser, Map<String, String> branchMap) throws Exception,
            BaseException {
        String userIds = null;
        FlowAuditHelpVO helpVO = null;
        helpVO = new FlowAuditHelpVO(REPORTDANGER_CODE);
        String incharges = this.flowAuditService.handleBranchFlowAudit(branchMap, true, true, helpVO);
        po.setCurrentNodeId(helpVO.getCurrentNodeId());
        String title = "网格员" + userInfoVO.getPersonName() + "_" + DateUtil.format(new Date(), "yyyyMMdd") + "_隐患";
        po.setTitle(title);
        po.setReportType("0");
        po.setHandleUserId(userIds);
        userIds = incharges;
        List<UserDeptInfoExpandVO> list = this.contactService.findUserDeptByUserIds(userIds.split(","));
        String userNames = "";
        for (UserDeptInfoExpandVO vo : list) {
            userNames += "," + vo.getPersonName();
        }
        if (!AssertUtil.isEmpty(userNames)) {
            userNames = userNames.substring(1);
        }
        this.todoService.addFlowTodoInfoByStrs(REPORTDANGER_CODE, po.getId(), incharges, po.getCreatorUser(),
                userInfoVO.getOrgId(), "新建", helpVO.getCurrentNodeId());

        if (!AssertUtil.isEmpty(incharges)) {
            this.defatgroupService.addOldGivenInfo(incharges, "0", po.getCreatorUser(), userInfoVO.getOrgId(),
                    REPORTDANGER_CODE, null);
            incharges = insertRecipient(po, incharges, "0");
        }

        if (!AssertUtil.isEmpty(relatives)) {
            this.defatgroupService.addOldGivenInfo(relatives, "1", po.getCreatorUser(), userInfoVO.getOrgId(),
                    REPORTDANGER_CODE, null);
            relatives = insertRecipient(po, relatives, "1");
        }
        if ((null != helpVO) && (null != helpVO.getAutomaticAuditUserIds())) {
            if (helpVO.getIsOver().booleanValue()) {
                this.todoService.deleteTodoInfoByRefId(po.getId());
                incharges = "";
            }
            flowAutomaticAuditInfoByStr(po, userInfoVO, userIds, helpVO, null);
        }

        if (!StringUtil.isNullEmpty(imageUrls)) {
            String[] images = imageUrls.split(",");
            this.contactService.insertPicAttach(po.getId(), po.getCreatorUser(), userInfoVO.getOrgId(), images);
        }
        po.setHandleUser(userNames);
        insertPO(po, false);
        if (AssertUtil.isEmpty(flowId)) {
            this.workflowService.addApprove(po.getId(), "reportdanger", null, po.getCreatorUser(), userIds, false);
        }

        //修改楼栋亮灯情况
        TbYsjdBanPO banPO = this.contactService.searchByPk(TbYsjdBanPO.class, po.getTheBan());
        if(!"2".equals(banPO.getLight())){
            banPO.setLight(po.getLightStatus());
            updatePO(banPO, false);
        }
        sendMsg(incharges, relatives, po.getCreatorUser(), po);
    }

    public Map<String, String> getWxUserIds(UserInfoVO userInfoVO,TbYsjdBanPO banPo) throws Exception, BaseException {
        Map<String, String> retMap = new HashMap<String, String>();
        String personName = "";
        String userId = "";
        String wxUserId = "";
        //业主信息
        //TbQyUserInfoVO owner = this.contactService.findUserInfoByUserId(banPo.getOwnerId());
        TbQyUserInfoVO owner = this.contactService.findUsersByPhone(userInfoVO.getOrgId(), banPo.getOwnerPhone());
        //楼栋长信息
        //TbQyUserInfoVO banLong = this.contactService.findUserInfoByUserId(banPo.getBanLongId());
        TbQyUserInfoVO banLong = this.contactService.findUsersByPhone(userInfoVO.getOrgId(), banPo.getBanLongPhone());

        if(!AssertUtil.isEmpty(owner)){
            personName = owner.getPersonName();
            userId = owner.getUserId();
            wxUserId = owner.getWxUserId();
        }
        if(!AssertUtil.isEmpty(banLong)){
            if(!AssertUtil.isEmpty(personName)){
                if(!AssertUtil.isEmpty(banLong.getPersonName()) && !personName.equals(banLong.getPersonName())){
                    personName += ","+banLong.getPersonName();
                }
            }else{
                if(!AssertUtil.isEmpty(banLong.getPersonName())){
                    personName  = banLong.getPersonName();
                } 
            }
            
            if(!AssertUtil.isEmpty(userId)){
                if(!AssertUtil.isEmpty(banLong.getUserId()) && !userId.equals(banLong.getUserId())){
                    userId += ","+banLong.getUserId();
                }
            }else{
                if(!AssertUtil.isEmpty(banLong.getUserId())){
                    userId  = banLong.getUserId();
                } 
            }
            
            if(!AssertUtil.isEmpty(wxUserId)){
                if(!AssertUtil.isEmpty(banLong.getWxUserId()) && !wxUserId.equals(banLong.getWxUserId())){
                    wxUserId += ","+banLong.getWxUserId();
                }
            }else{
                if(!AssertUtil.isEmpty(banLong.getWxUserId())){
                    wxUserId  = banLong.getWxUserId();
                } 
            }
        }
        retMap.put("personName", personName);
        retMap.put("userId", userId);
        retMap.put("wxUserId", wxUserId);
        return retMap;
    }
    /**
     * 新增一般隐患上报
     * <p>Description: TODO</p>
     * @param po
     * @param userInfoVO
     * @param relatives
     * @param imageUrls
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年8月29日</p>
     */
    @Override
    public void addReportdangerPO(TbYsjdReportdangerPo po, UserInfoVO userInfoVO, String relatives, String imageUrls) throws Exception,BaseException {
        
        TbYsjdBanPO banPo = this.reportdangerDao.searchByPk(TbYsjdBanPO.class,po.getTheBan());
        if(AssertUtil.isEmpty(banPo)){
            throw new BaseException("楼栋信息为空，请确认楼栋信息是否正确！");
        }
        
        Map<String, String> retMap = getWxUserIds(userInfoVO, banPo);
        String personName = retMap.get("personName");
        String userId = retMap.get("userId");
        String wxUserId = retMap.get("wxUserId");
        
       /* if(AssertUtil.isEmpty(wxUserId)){
            throw new BaseException("没有查询到楼栋的业主及楼栋长，请确认楼栋资料是否填写相关信息！");
        }*/
        String title = "网格员" + userInfoVO.getPersonName() + "_" + DateUtil.format(new Date(), "yyyyMMdd") + "_隐患";
        po.setTitle(title);
        po.setReportType("1");
        po.setHandleUser(personName);
        //新增上报
        insertPO(po, false);
        
        //添加提交结点
        TbYsjdApprovalPo approvalPo = new TbYsjdApprovalPo();
        approvalPo.setId(UUID.randomUUID().toString());
        approvalPo.setReportdangerId(po.getId());
        approvalPo.setApprovalName("提交");
        approvalPo.setDescribes(userInfoVO.getPersonName()+" 提交");
        approvalPo.setCreateUser(userInfoVO.getUserId());
        approvalPo.setCreateTime(new Date());
        approvalPo.setUpdateTime(new Date());
        approvalPo.setStatus("1");
        approvalPo.setSort(1);
        insertPO(approvalPo, false);
        
        //添加业主处理结点
        approvalPo = new TbYsjdApprovalPo();
        approvalPo.setId(UUID.randomUUID().toString());
        approvalPo.setReportdangerId(po.getId());
        approvalPo.setApprovalName("业主处理");
        approvalPo.setDescribes(personName+" 未处理");
        approvalPo.setUserId(userId);
        approvalPo.setWxUserId(wxUserId);
        approvalPo.setCreateUser(userInfoVO.getUserId());
        approvalPo.setCreateTime(new Date());
        approvalPo.setStatus("0");
        approvalPo.setSort(2);
        insertPO(approvalPo, false);
        
        if (!StringUtil.isNullEmpty(imageUrls)) {
            String[] images = imageUrls.split(",");
            this.contactService.insertPicAttach(po.getId(), po.getCreatorUser(), userInfoVO.getOrgId(), images);
        }

        //新增相关人信息
        if (!AssertUtil.isEmpty(relatives)) {
            relatives = insertRecipient(po, relatives, "1");
        }
        
        //新增负责人信息
        if (!AssertUtil.isEmpty(userId)) {
            insertRecipient(po, userId, "0");
        }
        
        //修改楼栋亮灯情况
        if(!"2".equals(banPo.getLight())){
            banPo.setLight(po.getLightStatus());
            updatePO(banPo, false);
        }
        
        sendMsg(wxUserId, relatives, po.getCreatorUser(), po);
    }

    private void flowAutomaticAuditInfoByStr(TbYsjdReportdangerPo po, UserInfoVO userInfoVo, String incharges,
            FlowAuditHelpVO helpVO, Date date) throws Exception, BaseException {
        incharges = incharges.replace(",", "|");
        if (helpVO.getAutomaticAuditUserIds().size() > 0) {
            Set insertUserIds = new HashSet();
            int num = helpVO.getAutomaticAuditUserIds().size();
            Calendar calendar = Calendar.getInstance();
            if (null == date) {
                date = new Date();
            }
            calendar.setTime(date);
            calendar.add(13, 1);
            for (int i = 0; i < helpVO.getAutomaticAuditUserIds().size(); i++) {
                if (i > 0) {
                    calendar.add(13, 1);
                }
                num--;
                String userId = (String) helpVO.getAutomaticAuditUserIds().get(i);
                String nodeType = (String) helpVO.getNodeType().get(i);
                if (new StringBuilder().append("|").append(incharges).append("|").toString()
                        .indexOf(new StringBuilder().append("|").append(userId).append("|").toString()) > -1) {
                    if (helpVO.getIsOver().booleanValue()) {
                        this.todoService.deleteTodoInfoByRefIdAndUserId(po.getId(), userId);
                    }
                } else if (insertUserIds.add(userId)) {
                    insertRecipient(po, userId, "0");
                }
                String content = "";
                if ("1".equals(nodeType))
                    content = "审批通过";
                else if ("2".equals(nodeType))
                    content = "已确认";
                else {
                    content = "已办理";
                }
                conmitFormComment(po.getId(), userInfoVo, content, 1, "1", calendar.getTime());
                Thread.sleep(1L);

            }
        }
    }

    private void sendMsg(String incharges, String relatives, String userId, TbYsjdReportdangerPo po) throws Exception,
            BaseException {
        TbQyUserInfoVO sendUser = this.contactService.findUserInfoByUserId(userId);
        ExtOrgPO orgPO = (ExtOrgPO) this.contactService.searchByPk(ExtOrgPO.class, sendUser.getOrgId());
        StringBuffer send = new StringBuffer();

        if (!AssertUtil.isEmpty(incharges)) {
            String[] personlist = incharges.split(",");
            for (String person : personlist) {
                if ((send.indexOf(person.trim()) < 0) && (!person.trim().equals(sendUser.getWxUserId()))) {
                    send.append(new StringBuilder().append("|").append(person.trim()).toString());
                }
            }

        }

        String content = "";

        String title = "重点隐患处理通知";
        if("1".equals(po.getReportType())){
            title = "一般隐患处理通知";
        }
        NewsMessageVO newsMessageVO = WxMessageUtil.newsMessageVO.clone();

        content = new StringBuilder().append("你收到一个新的隐患需要处理，赶紧去处理吧！").toString();

        if (send.length() > 0) {
            newsMessageVO = WxMessageUtil.newsMessageVO.clone();
            newsMessageVO.setTouser(send.toString());
            newsMessageVO.setDuration("0");
            newsMessageVO.setTitle(title);
            newsMessageVO.setDescription(content);
            if("1".equals(po.getReportType())){
                newsMessageVO.setUrl(new StringBuilder().append(Configuration.WX_PORT)
                        .append("/jsp/xentwap/reportdanger/reportdetail.jsp?selType=1&id=").append(po.getId()).toString());
            }else{
                newsMessageVO.setUrl(new StringBuilder().append(Configuration.WX_PORT)
                        .append("/jsp/xentwap/reportdanger/detail.jsp?selType=1&id=").append(po.getId()).toString());  
            }
            newsMessageVO.setCorpId(orgPO.getCorpId());
            newsMessageVO.setAgentCode(REPORTDANGER_CODE);
            newsMessageVO.setOrgId(orgPO.getOrganizationId());
            WxMessageUtil.sendNewsMessage(newsMessageVO);
        }

        if (AssertUtil.isEmpty(relatives)) {
            return;
        }
        StringBuffer send2 = new StringBuffer();

        if (!AssertUtil.isEmpty(relatives)) {
            String[] personlist = relatives.split(",");
            for (String person : personlist) {
                String toPersonId = person.trim();

                if ((send2.indexOf(toPersonId) < 0) && (!toPersonId.equals(sendUser.getWxUserId()))
                        && (send.indexOf(toPersonId) < 0)) {
                    send2.append(new StringBuilder().append("|").append(toPersonId).toString());
                }
            }
        }

        content = new StringBuilder().append("你收到一个新的隐患信息，赶紧去查看吧！").toString();

        if (send2.length() > 0) {
            send2.deleteCharAt(0);
            newsMessageVO = WxMessageUtil.newsMessageVO.clone();
            newsMessageVO.setTouser(send2.toString());
            newsMessageVO.setDuration("0");
            newsMessageVO.setTitle(title);
            newsMessageVO.setDescription(content);
            if("1".equals(po.getReportType())){
                newsMessageVO.setUrl(new StringBuilder().append(Configuration.WX_PORT)
                        .append("/jsp/xentwap/reportdanger/reportdetail.jsp?selType=2&id=").append(po.getId()).toString());
            }else{
                newsMessageVO.setUrl(new StringBuilder().append(Configuration.WX_PORT)
                        .append("/jsp/xentwap/reportdanger/detail.jsp?selType=2&id=").append(po.getId()).toString()); 
            }

            newsMessageVO.setCorpId(orgPO.getCorpId());
            newsMessageVO.setAgentCode(REPORTDANGER_CODE);
            newsMessageVO.setOrgId(orgPO.getOrganizationId());
            WxMessageUtil.sendNewsMessage(newsMessageVO);
        }
    }

    public String insertRecipient(TbYsjdReportdangerPo reportdangerPo, String persons, String type)
            throws BaseException, Exception {
        if (!StringUtil.isNullEmpty(persons)) {
            StringBuffer wxUserIds = new StringBuffer();
            String[] personlist = persons.replaceAll(" ", "").split(",");
            List<TbYsjdRecipientPo> inlist = new ArrayList<TbYsjdRecipientPo>();
            int index = 1;
            Map userRedundancyInfos = this.contactService.getUserRedundancyListByUserId(personlist);
            UserRedundancyInfoVO sendUser = null;
            for (String person : personlist) {
                sendUser = (UserRedundancyInfoVO) userRedundancyInfos.get(person);
                if (sendUser != null) {
                    TbYsjdRecipientPo po = new TbYsjdRecipientPo();
                    po.setRecipientId(UUID32.getID());
                    po.setReportdangerId(reportdangerPo.getId());
                    po.setUserId(person.trim());
                    po.setUserType(type);
                    po.setCreatePerson(reportdangerPo.getCreatorUser());
                    po.setPersonName(sendUser.getPersonName());
                    po.setHeadPic(sendUser.getHeadPic());
                    po.setWxUserId(sendUser.getWxUserId());
                    po.setDepartmentId(sendUser.getDeptId());
                    po.setDepartmentName(FlowUtil.getDeptFullName(sendUser.getDeptFullName()));
                    po.setCreateTime(new Date());
                    po.setIsAudit("1");
                    po.setRecipientOrder(Integer.valueOf(index++));
                    inlist.add(po);
                    wxUserIds.append(new StringBuilder().append(",").append(sendUser.getWxUserId()).toString());
                }
            }
            if (!AssertUtil.isEmpty(personlist)) {
                this.contactService.updateCommonUser(reportdangerPo.getCreatorUser(), ListUtil.toList(personlist),
                        Integer.valueOf(1));
            }
            if (!AssertUtil.isEmpty(inlist)) {
                this.reportdangerDao.execBatchInsert(inlist);
            }
            if (wxUserIds.length() > 0) {
                wxUserIds.deleteCharAt(0);
                return wxUserIds.toString();
            }
        }
        return null;
    }

    private void conmitFormComment(String id, UserInfoVO userInfoVO, String content, int status, String type, Date date)
            throws Exception, BaseException {

        TbYsjdDangerCommentPo dangerCommentPo = new TbYsjdDangerCommentPo();
        String commentId = UUID.randomUUID().toString();
        dangerCommentPo.setCommentId(commentId);
        dangerCommentPo.setCreator(userInfoVO.getUserId());
        dangerCommentPo.setPersonName(userInfoVO.getPersonName());
        dangerCommentPo.setDepartmentId(userInfoVO.getDeptIdsForRedundancy());
        dangerCommentPo.setDepartmentName(FlowUtil.getDeptFullName(userInfoVO.getDeptFullNamesForRedundancy()));
        dangerCommentPo.setHeadPic(userInfoVO.getHeadPic());
        dangerCommentPo.setWxUserId(userInfoVO.getWxUserId());
        if (null == date) {
            dangerCommentPo.setCreateTime(new Date());
        } else {
            dangerCommentPo.setCreateTime(date);
        }
        dangerCommentPo.setReportdangerId(id);
        dangerCommentPo.setStatus(type);
        dangerCommentPo.setContent(content);
        dangerCommentPo.setType("1");
        insertPO(dangerCommentPo, false);

    }

    @Override
    public List<TbYsjdDangerCommentPo> getCommentsByUserID(String userId, String reportdangerId) throws BaseException,
            Exception {
        return this.reportdangerDao.getCommentsByUserID(userId, reportdangerId);
    }

    public List<String> getDangerUser(Map<String, Object> paramMap) throws Exception, BaseException {
        return this.reportdangerDao.getDangerUser(paramMap);
    }

    @Override
    public List<TbYsjdReportdangerVo> getReportdangerVo() throws Exception, BaseException {
        return this.reportdangerDao.getReportdangerVo();
    }

    @Override
    public List<TbYsjdRecipientVo> getDangerRecipient(String reportdangerId, String type) throws Exception,
            BaseException {
        return this.reportdangerDao.getDangerRecipient(reportdangerId, type);
    }
    @Override
    public void agreeAudit(TbYsjdReportdangerPo po, String reason, String userId, String orgId, String signImg)
            throws Exception, BaseException {
        StringBuffer thisats = new StringBuffer("");
        UserRedundancyInfoVO sendUser = this.contactService.getUserRedundancyInfoByUserId(userId);
        this.todoService.deleteTodoInfoByRefIdAndUserId(po.getId(), userId);

        this.reportdangerDao.updateRecipientTypeAndStatusByAskIdAndUserId(po.getId(), userId, "0", "2");
        List<TbYsjdRecipientVo> list = this.reportdangerDao.getNotAuditUserById(po.getId());
        if (!AssertUtil.isEmpty(list)) {
            for (TbYsjdRecipientVo user : list) {
                String uid = user.getUserId();
                UserRedundancyInfoVO userVO = this.contactService.getUserRedundancyInfoByUserId(uid);
                if ((userVO != null) && (sendUser.getOrgId().equals(userVO.getOrgId()))) {
                    thisats.append(new StringBuilder().append("@").append(userVO.getPersonName()).append(" ")
                            .toString());
                }
            }
        }
        String content = new StringBuilder().append(thisats).append("审批意见：").append(reason).toString();
        TbYsjdDangerCommentPo commentPO = new TbYsjdDangerCommentPo();
        String commentId = UUID.randomUUID().toString();
        commentPO.setCommentId(commentId);
        commentPO.setCreator(userId);
        commentPO.setPersonName(sendUser.getPersonName());
        commentPO.setHeadPic(sendUser.getHeadPic());
        commentPO.setWxUserId(sendUser.getWxUserId());
        commentPO.setDepartmentId(sendUser.getDeptId());
        commentPO.setDepartmentName(sendUser.getDeptFullName());
        commentPO.setCreateTime(new Date());
        commentPO.setReportdangerId(po.getId());
        commentPO.setContent(new StringBuilder().append(content).append(signImg).toString());
        commentPO.setType("1");
        commentPO.setStatus("2");
        insertPO(commentPO, false);
    }
    @Override
    public void updataDangerPo(TbYsjdReportdangerPo po, UserInfoVO operatorUser, String reason,String[] mediaIds,String imageUrls) throws Exception,
            BaseException {
            //删除原有处理结果图片
            this.contactService.delPicListByGroupId(po.getId()+"result", operatorUser.getUserId());
        
            //保存处理结果图片
            if (!StringUtil.isNullEmpty(imageUrls)) {
                String[] images = imageUrls.split(",");
                this.contactService.insertPicAttach(po.getId()+"result", po.getCreatorUser(), operatorUser.getOrgId(), images);
            }
            //保存处理结果附件
            if (mediaIds != null && mediaIds.length > 0) {
                this.fileMediaService.startMediaStatus(mediaIds, po.getId(), operatorUser.getOrgId(), 1);
            }else{
                this.fileMediaService.delFileGroupRefByGroupId(po.getId(), 1);
            }
            po.setResult(reason);
            Integer commentCount = 0;
            if (!AssertUtil.isEmpty(po.getCommentCount())) {
                commentCount = po.getCommentCount();
            }
            po.setCommentCount(commentCount + 1);
            this.updatePO(po, false);
            //记录评论信息
            String  content = operatorUser.getPersonName()+"更新隐患上报处理结果。";
            Date date = new Date();
            conmitFormComment(po.getId(), operatorUser, content, 1, "1", date);

            //发送消息给创建人，提示更新信息
            String msgTitle = new StringBuilder().append("隐患结果更新").toString();
            String msgContent = new StringBuilder().append(operatorUser.getPersonName()).append("更新了隐患的处理结果，赶紧去查看一下吧！").toString();
            TbQyUserInfoVO creatorUserVO = this.contactService.findUserInfoByUserId(po.getCreatorUser());
            if (null != creatorUserVO) {
                sendWxMsg(creatorUserVO.getWxUserId(), msgTitle, msgContent, po.getId(), creatorUserVO.getCorpId(), creatorUserVO.getOrgId(), po.getReportType());
            }
    }
    
    
    
    @Override
    public void updataAuditStatus(TbYsjdReportdangerPo po, UserInfoVO operatorUser, String status, String dpId,
            String reason, String choiseFlowUser, String signImg, Map<String, String> branchMap,String[] mediaIds,String imageUrls) throws Exception,
            BaseException {
        if ("1".equals(status)) {
            //删除原有处理结果图片
            this.contactService.delPicListByGroupId(po.getId()+"result", operatorUser.getUserId());
        
            //保存处理结果图片
            if (!StringUtil.isNullEmpty(imageUrls)) {
                String[] images = imageUrls.split(",");
                this.contactService.insertPicAttach(po.getId()+"result", po.getCreatorUser(), operatorUser.getOrgId(), images);
            }
            //保存处理结果附件
            if (mediaIds != null && mediaIds.length > 0) {
                this.fileMediaService.startMediaStatus(mediaIds, po.getId(), operatorUser.getOrgId(), 1);
            }
            po.setStatus("2");
        } else if ("2".equals(status)) {
            //修改楼栋亮灯情况
            TbYsjdBanPO banPO = this.contactService.searchByPk(TbYsjdBanPO.class, po.getTheBan());
            
            //查询楼栋除当前转灯信息外，其他的隐患亮灯信息中最严重的亮灯情况
            TbYsjdReportdangerVo vo = this.reportdangerDao.getTbYsjdReportdangerVo(po.getTheBan(), po.getId());
            if(!AssertUtil.isEmpty(vo)&&!AssertUtil.isEmpty(banPO)){
                if(!AssertUtil.isEmpty(vo.getLightStatus())&&!vo.getLightStatus().equals(banPO.getLight())){
                    banPO.setLight(vo.getLightStatus());
                    updatePO(banPO, false);
                }
            }else{
                banPO.setLight("0");
                updatePO(banPO, false);
            }
            po.setStatus("3");
        }
        po.setResult(reason);
        
        StringBuffer thisats = new StringBuffer("");
        Set thissend = new HashSet();
        String orgId = operatorUser.getOrgId();
        String corpId = operatorUser.getCorpId();
        String operatorUserId = operatorUser.getUserId();
        String currentNodeId = (String) branchMap.get("currentNodeId");
        boolean isSystemAudit = branchMap.containsKey("systemAudit");
        TbQyUserInfoVO creatorUserVO = this.contactService.findUserInfoByUserId(po.getCreatorUser());

        List<TbQyUserInfoVO> userList = new ArrayList<TbQyUserInfoVO>();
        FlowAuditVO flowAuditVO = null;
        if (!AssertUtil.isEmpty(currentNodeId))
            flowAuditVO = this.flowAuditService.getFlowAuditVOByNodeIdAndRefId(po.getId(), currentNodeId,
                    Boolean.valueOf("1".equals(branchMap.get("isWeChatApp"))), signImg, isSystemAudit);
        else {
            flowAuditVO = this.flowAuditService.getAlreadyInstanceNotAuditNode(po.getId(),
                    "1".equals(branchMap.get("isWeChatApp")), signImg, isSystemAudit);
        }

        if (AssertUtil.isEmpty(flowAuditVO)) {
            throw new NonePrintException("1003", "该流程已结束，请刷新页面重试！");
        }

        String nodeType = flowAuditVO.getNodeType();
        int todoNum = 1;

        if (!isSystemAudit) {
            FlowUtil.initAddTag(flowAuditVO);
            todoNum = FlowUtil.getSignRemainNum(flowAuditVO, operatorUserId);
        }

        if ((todoNum <= 1) || "0".equals(status)) {
            boolean sendOverMesg = true;
            FlowAuditHelpVO helpVO = new FlowAuditHelpVO(REPORTDANGER_CODE);
            boolean is_over = false;

            if (isSystemAudit) {
                is_over = this.flowAuditService.sysTemAuditFlowInfo(po.getId(), operatorUser, !"0".equals("3"),
                        currentNodeId, (String) branchMap.get("nextNodeId"), orgId, po.getResult(),
                        Integer.parseInt(status), userList, helpVO);
            } else {
                is_over = this.flowAuditService.auditBranchFlowInfo(branchMap, Integer.parseInt(status), userList,
                        helpVO);
                po.setCurrentNodeId(helpVO.getCurrentNodeId());
            }

            if (FlowAuditStatusResult.END.value().toString().equals(status)) {
                status =  FlowAuditStatusResult.AGREE.value().toString();
            }
            if ((null != helpVO) && (null != helpVO.getAutomaticAuditUserIds())
                    && (helpVO.getAutomaticAuditUserIds().size() > 0)) {
                if (helpVO.getIsOver().booleanValue()) {
                    is_over = true;
                }

                String content = "已处理";
                if(!AssertUtil.isEmpty(reason)){
                    content = new StringBuilder().append("，办理意见为\"").append(reason).append("\"").toString();
                }

                Date date = new Date();
                conmitFormComment(po.getId(), operatorUser, content, 1, "1", date);
                sendOverMesg = false;
                flowAutomaticAuditInfoByList(po, operatorUser, userList, helpVO, date);
            }

            String msgTitle = "";
            String createUserContent = "";

            String msgContent = "";
            String content = "";

            if (is_over) {
                this.todoService.deleteTodoInfoByRefId(po.getId());

                this.reportdangerDao.updateAskRecipientAuditStatusByAskId(po.getId(), "0", "2");
                content = new StringBuilder().append("隐患结果已确认，流程已结束。").toString();
                conmitFormComment(po.getId(), operatorUser, content, 1, "1", null);
                msgTitle = new StringBuilder().append("隐患结果已确认").toString();
                msgContent = new StringBuilder().append("您已确认隐患处理结果！").toString();
                createUserContent = new StringBuilder().append("您已确认隐患处理结果！").toString();

                if (null != creatorUserVO) {
                    sendWxMsg(creatorUserVO.getWxUserId(), msgTitle, createUserContent, po.getId(), corpId, orgId, po.getReportType());
                }
            } else {
                if (AssertUtil.isEmpty(userList)) {
                    throw new BaseException("获取审批人为空,请联系管理员");
                }

                this.todoService.addTodoInfoByList(REPORTDANGER_CODE, po.getId(), userList, operatorUser.getUserId(),
                        operatorUser.getOrgId(), "");
                for (TbQyUserInfoVO userVO : userList)
                    if ((null != userVO) && (thissend.add(userVO.getWxUserId()))
                            && (!"-1".equals(userVO.getUserStatus()))) {
                        thisats.append(new StringBuilder().append("@").append(userVO.getPersonName()).append(" ")
                                .toString());
                    }
                if (sendOverMesg) {
                    content = new StringBuilder().append(thisats).append("隐患上报信息已处理,请确认处理结果！").toString();
                    conmitFormComment(po.getId(), operatorUser, content, 1, "1", null);
                }
                msgTitle = new StringBuilder().append("重点隐患处理结果确认通知").toString();
                if("1".equals(po.getReportType())){
                    msgTitle = new StringBuilder().append("一般隐患处理结果确认通知").toString(); 
                }
                msgContent = new StringBuilder().append(operatorUser.getPersonName()).append("提交了隐患的处理结果，赶紧去确认一下处理结果吧！").toString();

                if (thissend.size() > 0) {
                    NewsMessageVO newsMessageVO = WxMessageUtil.newsMessageVO.clone();
                    newsMessageVO.setTouser(StringUtil.uniteArry(thissend.toArray(), "|"));
                    newsMessageVO.setDuration("0");
                    newsMessageVO.setTitle(msgTitle);
                    newsMessageVO.setDescription(msgContent);
                    newsMessageVO
                            .setUrl(new StringBuilder().append(Configuration.WX_PORT)
                                    .append("/jsp/xentwap/reportdanger/detail.jsp?selType=1&id=").append(po.getId())
                                    .toString());
                    newsMessageVO.setCorpId(corpId);
                    newsMessageVO.setAgentCode(REPORTDANGER_CODE);
                    newsMessageVO.setOrgId(orgId);
                    WxMessageUtil.sendNewsMessage(newsMessageVO);
                }

                this.reportdangerDao.updateAskRecipientAuditStatusByAskId(po.getId(), "0", "2");

                addAuditRecipient(po.getId(), userList, operatorUser.getUserId(), orgId, "0");
            }
        }
        Integer commentCount = 0;
        if (!AssertUtil.isEmpty(po.getCommentCount())) {
            commentCount = po.getCommentCount();
        }
        po.setHandleTime(new Date());
        po.setCommentCount(commentCount + 1);
        updatePO(po, false);
    }
    @Override
    public void updataStatus(TbYsjdReportdangerPo po, UserInfoVO operatorUser, String status, String reason, String[] mediaIds,String imageUrls) throws Exception,
            BaseException {
        //创建人
        TbQyUserInfoVO userVo = this.contactService.findUserInfoByUserId(po.getCreatorUser());
        if (AssertUtil.isEmpty(userVo)) {
            throw new BaseException("获取创建人为空,请联系管理员");
        }
        //查询处理人信息
        String userId = operatorUser.getUserId();//当前登录人
        String toUser = "";//处理人wxUSerID
        String toUserName = "";//处理人姓名
        boolean isApproval = false;//当前登录人是否为处理人员；
        List<TbYsjdRecipientVo> recipient = this.reportdangerDao.getDangerRecipient(po.getId(), "0");
        for (TbYsjdRecipientVo user : recipient) {
            toUserName +=","+user.getPersonName();
            if (!userId.equals(user.getUserId())&&!userVo.getUserId().equals(user.getUserId())) {
                toUser +="|"+user.getWxUserId();
            }
            if(!isApproval){
                if (userId.equals(user.getUserId())) {
                    isApproval = true;
                }
            }
        }
        /*//查询相关人
        List<TbYsjdRecipientVo> recipient1 = this.reportdangerDao.getDangerRecipient(po.getId(), "1");
        for (TbYsjdRecipientVo user : recipient1) {
            if (!userId.equals(user.getUserId())&&!userVo.getUserId().equals(user.getUserId())) {
                toUser +="|"+user.getWxUserId();
            }
        }*/
        if(!AssertUtil.isEmpty(toUser)){
            toUser = toUser.substring(1);
        }
        if(!AssertUtil.isEmpty(toUserName)){
            toUserName = toUserName.substring(1);
        }
        String msgTitle = "";
        String msgContent = "";
        String content = "";
        if ("1".equals(status)) {
            //删除原有处理结果图片
            this.contactService.delPicListByGroupId(po.getId()+"result", operatorUser.getUserId());
        
            //保存处理结果图片
            if (!StringUtil.isNullEmpty(imageUrls)) {
                String[] images = imageUrls.split(",");
                this.contactService.insertPicAttach(po.getId()+"result", po.getCreatorUser(), operatorUser.getOrgId(), images);
            }
            //保存处理结果附件
            if (mediaIds != null && mediaIds.length > 0) {
                this.fileMediaService.startMediaStatus(mediaIds, po.getId(), operatorUser.getOrgId(), 1);
            }
            po.setStatus("2");

            //查询审批信息
            List<TbYsjdApprovalVo> voList = this.reportdangerDao.getApprovalVoList(po.getId());
            TbYsjdApprovalPo odlApprovalPo = new TbYsjdApprovalPo();
            for (TbYsjdApprovalVo approvalVo : voList) {
                if("0".equals(approvalVo.getStatus())){
                    odlApprovalPo.setId(approvalVo.getId());
                    odlApprovalPo.setStatus("1");
                    if(userId.equals(userVo.getUserId())&&!isApproval){//处理人为网格员
                        odlApprovalPo.setDescribes(toUserName+"已处理,网格员代传处理结果");
                    }else{
                        odlApprovalPo.setDescribes(operatorUser.getPersonName()+" 已处理");
                    }
                    odlApprovalPo.setUpdateTime(new Date());
                }
            }
            if(AssertUtil.isEmpty(odlApprovalPo)){
                throw new BaseException("获取当前审批信息错误,请联系管理员");
            }
            this.reportdangerDao.update(odlApprovalPo, false);
            
            //添加网格员处理结点
            TbYsjdApprovalPo approvalPo = new TbYsjdApprovalPo();
            approvalPo.setId(UUID.randomUUID().toString());
            approvalPo.setReportdangerId(po.getId());
            approvalPo.setApprovalName("网格员确认结果");
            if(userId.equals(userVo.getUserId())){
                approvalPo.setDescribes(userVo.getPersonName()+" 已确认");
                approvalPo.setStatus("1");
                approvalPo.setUpdateTime(new Date());
            }else{
                approvalPo.setDescribes(userVo.getPersonName()+" 未确认");
                approvalPo.setStatus("0");
            }
            approvalPo.setUserId(userVo.getUserId());
            approvalPo.setWxUserId(userVo.getWxUserId());
            approvalPo.setCreateUser(operatorUser.getUserId());
            approvalPo.setCreateTime(new Date());
            approvalPo.setSort(3);
            insertPO(approvalPo, false);

            if(userId.equals(userVo.getUserId())&&!isApproval){//处理人为网格员
                //修改楼栋亮灯情况
                TbYsjdBanPO banPO = this.contactService.searchByPk(TbYsjdBanPO.class, po.getTheBan());
                
                //查询楼栋除当前转灯信息外，其他的隐患亮灯信息中最严重的亮灯情况
                TbYsjdReportdangerVo vo = this.reportdangerDao.getTbYsjdReportdangerVo(po.getTheBan(), po.getId());
                if(!AssertUtil.isEmpty(vo)&&!AssertUtil.isEmpty(banPO)){
                    if(!AssertUtil.isEmpty(vo.getLightStatus())&&!vo.getLightStatus().equals(banPO.getLight())){
                        banPO.setLight(vo.getLightStatus());
                        updatePO(banPO, false);
                    }
                }else{
                    banPO.setLight("0");
                    updatePO(banPO, false);
                }
                po.setStatus("3");
                
                content = new StringBuilder().append("隐患结果已提交，流程已结束。").toString();
                msgTitle = new StringBuilder().append("重点隐患处理结果确认通知").toString();
                if("1".equals(po.getReportType())){
                    msgTitle = new StringBuilder().append("一般隐患处理结果确认通知").toString(); 
                }
                msgContent = new StringBuilder()
                        .append("您已提交隐患上报处理结果，赶紧看一下吧！").toString();
            }else{
                content = new StringBuilder().append("@"+userVo.getPersonName()).append(" 您提交的隐患上报已处理,请确认处理结果！").toString();
                msgTitle = new StringBuilder().append("重点隐患处理结果确认通知").toString();
                if("1".equals(po.getReportType())){
                    msgTitle = new StringBuilder().append("一般隐患处理结果确认通知").toString(); 
                }
                msgContent = new StringBuilder().append(operatorUser.getPersonName()).append("处理了")
                        .append("您提交的隐患上报，赶紧去确认一下处理结果吧！").toString();
            }
            
            conmitFormComment(po.getId(), operatorUser, content, 1, "1", null);
            
            //推送消息到创建人，确认结果
            if (!AssertUtil.isEmpty(userVo)) {
                NewsMessageVO newsMessageVO = WxMessageUtil.newsMessageVO.clone();
                newsMessageVO.setTouser(userVo.getWxUserId());
                newsMessageVO.setDuration("0");
                newsMessageVO.setTitle(msgTitle);
                newsMessageVO.setDescription(msgContent);
                newsMessageVO
                        .setUrl(new StringBuilder().append(Configuration.WX_PORT)
                                .append("/jsp/xentwap/reportdanger/reportdetail.jsp?selType=1&id=").append(po.getId())
                                .toString());
                newsMessageVO.setCorpId(operatorUser.getCorpId());
                newsMessageVO.setAgentCode(REPORTDANGER_CODE);
                newsMessageVO.setOrgId(operatorUser.getOrgId());
                WxMessageUtil.sendNewsMessage(newsMessageVO);
            }
            po.setResult(reason);
            Integer commentCount = 0;
            if (!AssertUtil.isEmpty(po.getCommentCount())) {
                commentCount = po.getCommentCount();
            }
            po.setHandleTime(new Date());
            po.setCommentCount(commentCount + 1);
            updatePO(po, false);
        } else if ("2".equals(status)) {
            statusTo2(po, operatorUser, userVo, toUser,reason,"1");
        }
        
    }

    private void statusTo2(TbYsjdReportdangerPo po, UserInfoVO operatorUser, TbQyUserInfoVO userVo, String toUser,String reason,String type)
            throws Exception, SQLException, BaseException {
        String msgTitle = "";
        String msgContent = "";
        String content = "";
        //修改楼栋亮灯情况
        TbYsjdBanPO banPO = this.contactService.searchByPk(TbYsjdBanPO.class, po.getTheBan());
        
        //查询楼栋除当前转灯信息外，其他的隐患亮灯信息中最严重的亮灯情况
        TbYsjdReportdangerVo vo = this.reportdangerDao.getTbYsjdReportdangerVo(po.getTheBan(), po.getId());
        if(!AssertUtil.isEmpty(vo)&&!AssertUtil.isEmpty(banPO)){
            if(!AssertUtil.isEmpty(vo.getLightStatus())&&!vo.getLightStatus().equals(banPO.getLight())){
                banPO.setLight(vo.getLightStatus());
                updatePO(banPO, false);
            }
        }else{
            banPO.setLight("0");
            updatePO(banPO, false);
        }
        po.setStatus("3");
        
        if("1".equals(type)){//判断是否需要更新处理结点信息
            //查询审批信息
            List<TbYsjdApprovalVo> voList = this.reportdangerDao.getApprovalVoList(po.getId());
            TbYsjdApprovalPo odlApprovalPo = new TbYsjdApprovalPo();
            for (TbYsjdApprovalVo approvalVo : voList) {
                if("0".equals(approvalVo.getStatus())){
                    odlApprovalPo.setId(approvalVo.getId());
                    odlApprovalPo.setStatus("1");
                    odlApprovalPo.setDescribes(operatorUser.getPersonName()+" 已确认");
                    odlApprovalPo.setUpdateTime(new Date());
                }
            }
            if(AssertUtil.isEmpty(odlApprovalPo)){
                throw new BaseException("获取当前审批信息错误,请联系管理员");
            }
            this.reportdangerDao.update(odlApprovalPo, false);
        }
        
        content = new StringBuilder().append("隐患结果已确认，流程已结束。").toString();
        conmitFormComment(po.getId(), operatorUser, content, 1, "1", null);
        
        msgTitle = new StringBuilder().append("重点隐患结果已确认").toString();
        if("1".equals(po.getReportType())){
            msgTitle = new StringBuilder().append("一般隐患结果已确认").toString(); 
        }
        msgContent = new StringBuilder().append(userVo.getPersonName()+"已确认隐患处理结果！").toString();
        if (!AssertUtil.isEmpty(toUser)) {
            sendWxMsg(toUser, msgTitle, msgContent, po.getId(), operatorUser.getCorpId(), operatorUser.getOrgId(), po.getReportType());
        }
        po.setResult(reason);
        Integer commentCount = 0;
        if (!AssertUtil.isEmpty(po.getCommentCount())) {
            commentCount = po.getCommentCount();
        }
        po.setHandleTime(new Date());
        po.setCommentCount(commentCount + 1);
        updatePO(po, false);
    }

    private void flowAutomaticAuditInfoByList(TbYsjdReportdangerPo po, UserInfoVO userInfoVo,
            List<TbQyUserInfoVO> userList, FlowAuditHelpVO helpVO, Date date) throws Exception, BaseException {
        String incharges = "";
        List<TbYsjdRecipientVo> toList = this.reportdangerDao.getDangerRecipient(po.getId(), "0");
        if ((!AssertUtil.isEmpty(toList)) && (toList.size() > 0)) {
            for (TbYsjdRecipientVo vo : toList) {
                if (!"".equals(incharges)) {
                    incharges = new StringBuilder().append(incharges).append("|").toString();
                }
                incharges = new StringBuilder().append(incharges).append(vo.getUserId()).toString();
            }
        }
        flowAutomaticAuditInfoByStr(po, userInfoVo, incharges, helpVO, date);
    }

    public void sendWxMsg(String targetUserId, String title, String content, String askId, String corpId, String orgId,String reportType)
            throws BaseException, Exception {
        logger.debug(new StringBuilder().append("sendWxMsg>>>>").append(targetUserId).toString());
        NewsMessageVO newsMessageVO = WxMessageUtil.newsMessageVO.clone();
        newsMessageVO.setTouser(targetUserId);
        newsMessageVO.setDuration("0");
        newsMessageVO.setTitle(title);
        newsMessageVO.setDescription(content);
        if("1".equals(reportType)){
            newsMessageVO.setUrl(new StringBuilder().append(Configuration.WX_PORT)
                    .append("/jsp/xentwap/reportdanger/reportdetail.jsp?selType=0&id=").append(askId).toString());
        }else{
            newsMessageVO.setUrl(new StringBuilder().append(Configuration.WX_PORT)
                    .append("/jsp/xentwap/reportdanger/detail.jsp?selType=0&id=").append(askId).toString());
        }
        newsMessageVO.setCorpId(corpId);
        newsMessageVO.setAgentCode(REPORTDANGER_CODE);
        newsMessageVO.setOrgId(orgId);
        WxMessageUtil.sendNewsMessage(newsMessageVO);
    }

    private String handFormTitle(String title) {
        StringBuffer formTile = new StringBuffer("");
        if (!AssertUtil.isEmpty(title)) {
            if (title.length() > 20)
                formTile.append(new StringBuilder().append(title.substring(0, 20)).append("...").toString());
            else {
                formTile.append(title);
            }
        }
        return formTile.toString();
    }

    private void addAuditRecipient(String askId, List<TbQyUserInfoVO> userList, String userId, String orgId, String type)
            throws Exception, BaseException {
        if (!AssertUtil.isEmpty(userList)) {
            List<TbYsjdRecipientVo> receiveVOs = this.reportdangerDao.getDangerRecipient(askId, "0");

            List<TbYsjdRecipientVo> receiveVOs1 = this.reportdangerDao.getDangerRecipient(askId, "1");
            Set repeatSet = new HashSet();
            if (receiveVOs != null) {
                for (TbYsjdRecipientVo receive : receiveVOs) {
                    repeatSet.add(receive.getUserId());
                }
            }
            if (("1".equals(type)) && (receiveVOs1 != null)) {
                for (TbYsjdRecipientVo receive : receiveVOs1) {
                    repeatSet.add(receive.getUserId());
                }
            }

            int index = 0;
            if(!AssertUtil.isEmpty(receiveVOs)&&receiveVOs.size()>0){
                index = receiveVOs.size() + 1;
            }
            List userIdList = new ArrayList();
            List inlist = new ArrayList();
            for (TbQyUserInfoVO userVO : userList)
                if (!AssertUtil.isEmpty(userVO)) {
                    if (!repeatSet.add(userVO.getUserId())) {
                        this.reportdangerDao.updateRecipientTypeAndStatusByAskIdAndUserId(askId, userVO.getUserId(),
                                "0", "1");
                    } else {
                        TbYsjdRecipientPo po = new TbYsjdRecipientPo();
                        po.setRecipientId(UUID32.getID());
                        po.setPersonName(userVO.getPersonName());
                        po.setWxUserId(userVO.getWxUserId());
                        po.setDepartmentName(FlowUtil.getDeptFullName(userVO.getDepartmentName()));
                        po.setHeadPic(userVO.getHeadPic());
                        po.setReportdangerId(askId);
                        po.setCreatePerson(userId);
                        po.setUserId(userVO.getUserId());
                        po.setUserType(type);
                        po.setCreateTime(new Date());
                        po.setUserType("0");
                        po.setIsAudit("1");
                        po.setRecipientOrder(Integer.valueOf(index++));

                        inlist.add(po);
                        userIdList.add(po.getUserId());
                    }
                }
            if (!AssertUtil.isEmpty(inlist)) {
                this.reportdangerDao.execBatchInsert(inlist);
            }

            if (!AssertUtil.isEmpty(userIdList))
                this.contactService.updateCommonUser(userId, userIdList, Integer.valueOf(1));
        }
    }

    /**
     * 获取评论信息
     * <p>Description: TODO</p>
     * @param map
     * @param comments
     * @return
     * @throws Exception
     * @throws BaseException 
     * <p>Author: 邹乐乐</p>
     * <p>Date: 2017年8月25日</p>
     */
    @Override
    public Pager getDangerComment(Map map, Pager comments) throws BaseException, Exception {
        return this.reportdangerDao.getDangerComment(map, comments);
    }

    public void updateCommentStatus(String commentId) throws BaseException, Exception {
        TbYsjdDangerCommentPo po = (TbYsjdDangerCommentPo) this.reportdangerDao.searchByPk(TbYsjdDangerCommentPo.class, commentId);
        TbYsjdReportdangerPo ask = (TbYsjdReportdangerPo) this.reportdangerDao.searchByPk(TbYsjdReportdangerPo.class, po.getReportdangerId());
        ask.setCommentCount(Integer.valueOf(ask.getCommentCount().intValue() - 1));
        this.reportdangerDao.update(ask, false);
        this.reportdangerDao.delete(po);
    }
    
    /**
     * 查询上报处理信息
     * <p>Description: TODO</p>
     * @param reportdangerId 上报ID
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年8月30日</p>
     */
    @Override
    public List<TbYsjdApprovalVo> getApprovalVoList(String reportdangerId) throws Exception, BaseException{
        return this.reportdangerDao.getApprovalVoList(reportdangerId);
    }
    
    /**
     * 查询隐患统计
     * <p>Description: TODO</p>
     * @param reportdangerId 上报ID
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年9月1日</p>
     */
    @Override
    public List<CountDangerVo> searchCountDangerVoList(Map<String, Object> paramMap) throws Exception, BaseException{
        if(paramMap.containsKey("startTime")&&!AssertUtil.isEmpty(paramMap.get("startTime"))){
            String startTime = paramMap.get("startTime")+" 00:00:00";
            paramMap.put("startTime", startTime);
        }
        if(paramMap.containsKey("endTime")&&!AssertUtil.isEmpty(paramMap.get("endTime"))){
            String endTime = paramMap.get("endTime")+" 23:59:59";
            paramMap.put("endTime", endTime);
        }
        return this.reportdangerDao.searchCountDangerVoList(paramMap);
    }
    
    /**
     * 后台查询隐患统计
     * <p>Description: TODO</p>
     * @param reportdangerId 上报ID
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年9月1日</p>
     */
    @Override
    public List<CountDangerVo> searchMgrCountDangerVoList(Map<String, Object> paramMap) throws Exception, BaseException {
        List<CountDangerVo> countList = this.reportdangerDao.searchMgrCountDangerVoList(paramMap);
        if (!AssertUtil.isEmpty(countList)) {
            Integer countNum = 0;
            Integer leftHandle = 0;
            Integer leftUntreated = 0;
            Integer rightHandle = 0;
            Integer rightUntreated = 0;
            for (CountDangerVo vo : countList) {
                countNum = countNum + Integer.parseInt(vo.getCountNum());
                leftHandle = leftHandle + Integer.parseInt(vo.getLeftHandle());
                leftUntreated = leftUntreated + Integer.parseInt(vo.getLeftUntreated());
                rightHandle = rightHandle + Integer.parseInt(vo.getRightHandle());
                rightUntreated = rightUntreated + Integer.parseInt(vo.getRightUntreated());
                vo.setProgressLeft(searchNum(vo.getProgressLeft()));
                vo.setProgressRight(searchNum(vo.getProgressRight()));
            }
            CountDangerVo vo = new CountDangerVo();
            vo.setCommunityName("合计");
            vo.setCountNum(countNum+"");
            vo.setLeftHandle(leftHandle+"");
            vo.setLeftUntreated(leftUntreated+"");
            vo.setRightHandle(rightHandle+"");
            vo.setRightUntreated(rightUntreated+"");
            Double leftCount = leftHandle+leftUntreated+0.0;
            Double leftHandle1 = leftHandle+0.0;
            Double rightCount = rightHandle+rightUntreated+0.0;
            Double rightHandle1 = rightHandle+0.0;
  
            Double progressLeft = leftCount>0?leftHandle1/leftCount*100:0;
            Double progressRight = rightCount>0?rightHandle1/rightCount*100:0;
            vo.setProgressLeft(searchNum(progressLeft+""));
            vo.setProgressRight(searchNum(progressRight+""));
            countList.add(vo);
        }
        return countList;
    }
    
    public String searchNum(String countNum) {
        DecimalFormat df = new DecimalFormat("#.00");
        if (!AssertUtil.isEmpty(countNum)) {
            Double number = Double.parseDouble(countNum);
            if (number <= 0) {
                return "0";
            } else {
                countNum = df.format(number);
            }
            return countNum;
        } else {
            return "0";
        }
    }
    /**
     * 整治情况汇总表
     * <p>Description: TODO</p>
     * @param reportdangerId 上报ID
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年9月1日</p>
     */
    @Override
    public Pager searchSummaryDangerVoPager(Map searchValue,Pager pager) throws Exception, BaseException {
        return this.reportdangerDao.searchSummaryDangerVoPager(searchValue,pager);
    }
}
