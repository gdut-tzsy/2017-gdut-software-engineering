package cn.com.do1.component.reportdanger.reportdanger.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import cn.com.do1.common.dac.Pager;
import cn.com.do1.common.exception.BaseException;
import cn.com.do1.common.framebase.dqdp.IBaseDAO;
import cn.com.do1.component.reportdanger.reportdanger.vo.CommunityVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdCommunityUserVo;

public interface IDangerDescribeDao extends IBaseDAO {

    /**
     * <p>Description: 分页查询隐患描述</p>
     * @param searchMap 条件
     * @param pager 分页
     * @return Pager 隐患描述信息
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     */
    Pager searchTbYsjdDangerPO(Map<String, Object> searchMap, Pager pager) throws Exception, BaseException;

    /**
     * <p>Description: 根据隐患描述id删除负责人</p>
     * @param id 隐患描述id
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     */
    public void deleteCommunityByDangerId(String id) throws Exception, BaseException;

    /**
     * <p>Description: 查询社区</p>
     * @param depIdSys 社区节点id
     * @return List 社区名称
     * @throws SQLException SQLException异常
     */
    List<CommunityVo> getCommunity(String depIdSys) throws SQLException;

    /**
     * <p>Description: 查询负责人</p>
     * @param id 隐患描述id
     * @param communityId 社区id
     * @return List 负责人list
     * @throws Exception Exception异常
     * @throws BaseException BaseException异常
     */
    List<TbYsjdCommunityUserVo> getCommunityUserByComIdAndDesId(String id, String communityId) throws Exception, BaseException;

}
