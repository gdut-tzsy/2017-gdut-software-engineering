package cn.com.do1.component.reportdanger.reportdanger.dao.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.do1.common.annotation.po.Security;
import cn.com.do1.common.dac.Pager;
import cn.com.do1.common.exception.BaseException;
import cn.com.do1.common.exception.NonePrintException;
import cn.com.do1.common.framebase.dqdp.BaseDAOImpl;
import cn.com.do1.common.util.AssertUtil;
import cn.com.do1.component.addressbook.department.vo.TbDepartmentInfoVO;
import cn.com.do1.component.reportdanger.reportdanger.dao.ReportdangerDao;
import cn.com.do1.component.reportdanger.reportdanger.model.TbYsjdDangerCommentPo;
import cn.com.do1.component.reportdanger.reportdanger.util.ErrorCodeDesc;
import cn.com.do1.component.reportdanger.reportdanger.vo.CountDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.SummaryDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdApprovalVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdBanVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdDangerCommentVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdDangerVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdRecipientVo;
import cn.com.do1.component.reportdanger.reportdanger.vo.TbYsjdReportdangerVo;

/**
 * Copyright &copy; 2010 广州市道一信息技术有限公司 All rights reserved. User: zoulele
 */
public class ReportdangerDaoImpl extends BaseDAOImpl implements ReportdangerDao {
    private final static transient Logger logger = LoggerFactory.getLogger(ReportdangerDaoImpl.class);

    final static String searchSQL = "select * from tb_ysjd_reportdanger where 1=1 and report_type =:reportType and title like :title ";

    final static String countSQL = "select count(1) from ("
            + searchSQL.replaceAll("(?i)\\basc\\b|\\bdesc\\b", "").replaceAll(
                    "(?i)order\\s+by\\s+\\S+(\\s*[,\\s*\\S+])*", "") + "  ) a ";

    @Override
    public Pager searchTbYsjdReportdanger(Map searchValue, @Security(encode = "") Pager pager) throws Exception,
            BaseException {
        /*String searchSQL = "select rd.*,u.PERSON_NAME from tb_ysjd_reportdanger rd left join tb_qy_user_info u "
                + "ON rd.creator_user = u.user_id LEFT JOIN tb_qy_user_department_ref dr ON rd.handle_user_id = dr.user_id "
                + "LEFT JOIN tb_department_info d ON dr.department_id = d.id WHERE 1=1 "
                + "AND department_name LIKE :departmentName and report_type =:reportType and title like :title "
                + "and creator_user=:userId and status in (:status) and overtime_status in (:overtimeStatus) "
                + "and u.person_Name like :personName and rd.handle_User like :handleUser and rd.the_ban_name like :theBanName "
                + "and rd.light_status=:lightStatus";
        if (searchValue.containsKey("selType") && "1".equals(searchValue.get("selType"))) {
            //searchSQL = "select * from tb_ysjd_reportdanger where 1=1 and report_type =:reportType and title like :title and handle_user_id=:userId and status=:status and overtime_status=:overtimeStatus";
            searchSQL = "SELECT rd.*,u.PERSON_NAME FROM tb_ysjd_reportdanger rd "
                    + "LEFT JOIN tb_ysjd_recipient rp ON rd.id = rp.reportdanger_id "
                    + "left join tb_qy_user_info u ON rd.creator_user = u.user_id "
                    + "LEFT JOIN tb_qy_user_department_ref dr ON rd.handle_user_id = dr.user_id LEFT "
                    + "JOIN tb_department_info d ON dr.department_id = d.id WHERE 1=1 "
                    + "AND department_name LIKE :departmentName and rp.user_type = '0' and rd.report_type =:reportType and rd.title like :title "
                    + "AND rp.user_id = :userId and rd.status in (:status) and rd.overtime_status in (:overtimeStatus) "
                    + "and u.person_Name like :personName and rd.handle_User like :handleUser and rd.the_ban_name like :theBanName "
                    + "and rd.light_status=:lightStatus";
        } else if (searchValue.containsKey("selType") && "2".equals(searchValue.get("selType"))) {
            searchSQL = "SELECT rd.*,u.PERSON_NAME FROM tb_ysjd_reportdanger rd "
                    + "LEFT JOIN tb_ysjd_recipient rp ON rd.id = rp.reportdanger_id "
                    + "left join tb_qy_user_info u ON rd.creator_user = u.user_id "
                    + "LEFT JOIN tb_qy_user_department_ref dr ON rd.handle_user_id = dr.user_id LEFT JOIN tb_department_info d "
                    + "ON dr.department_id = d.id WHERE 1=1 AND department_name LIKE :departmentName and rp.user_type = '1' and rd.report_type =:reportType and rd.title like :title "
                    + "AND rp.user_id = :userId and rd.status in (:status) and rd.overtime_status in (:overtimeStatus) "
                    + "and u.person_Name like :personName and rd.handle_User like :handleUser and rd.the_ban_name like :theBanName "
                    + "and rd.light_status=:lightStatus";
        }*/
        String searchSQL = "select rd.*,u.PERSON_NAME from tb_ysjd_reportdanger rd left join tb_qy_user_info u "
                + "ON rd.creator_user = u.user_id "
                + "LEFT JOIN view_user_dept ud ON rd.handle_user_id = ud.user_id WHERE 1=1 "
                + "AND department_name LIKE :departmentName and report_type =:reportType and title like :title "
                + "and creator_user=:userId and status in (:status) and overtime_status in (:overtimeStatus) "
                + "and u.person_Name like :personName and rd.handle_User like :handleUser and rd.the_ban_name like :theBanName "
                + "and rd.light_status=:lightStatus";
        if (searchValue.containsKey("selType") && "1".equals(searchValue.get("selType"))) {
            //searchSQL = "select * from tb_ysjd_reportdanger where 1=1 and report_type =:reportType and title like :title and handle_user_id=:userId and status=:status and overtime_status=:overtimeStatus";
            searchSQL = "SELECT rd.*,u.PERSON_NAME FROM tb_ysjd_reportdanger rd "
                    + "LEFT JOIN tb_ysjd_recipient rp ON rd.id = rp.reportdanger_id "
                    + "left join tb_qy_user_info u ON rd.creator_user = u.user_id "
                    + "LEFT JOIN view_user_dept ud ON rd.handle_user_id = ud.user_id WHERE 1=1 "
                    + "AND department_name LIKE :departmentName and rp.user_type = '0' and rd.report_type =:reportType and rd.title like :title "
                    + "AND rp.user_id = :userId and rd.status in (:status) and rd.overtime_status in (:overtimeStatus) "
                    + "and u.person_Name like :personName and rd.handle_User like :handleUser and rd.the_ban_name like :theBanName "
                    + "and rd.light_status=:lightStatus";
        } else if (searchValue.containsKey("selType") && "2".equals(searchValue.get("selType"))) {
            searchSQL = "SELECT rd.*,u.PERSON_NAME FROM tb_ysjd_reportdanger rd "
                    + "LEFT JOIN tb_ysjd_recipient rp ON rd.id = rp.reportdanger_id "
                    + "left join tb_qy_user_info u ON rd.creator_user = u.user_id "
                    + "LEFT JOIN view_user_dept ud ON rd.handle_user_id = ud.user_id WHERE 1=1 "
                    + "AND department_name LIKE :departmentName and rp.user_type = '1' and rd.report_type =:reportType and rd.title like :title "
                    + "AND rp.user_id = :userId and rd.status in (:status) and rd.overtime_status in (:overtimeStatus) "
                    + "and u.person_Name like :personName and rd.handle_User like :handleUser and rd.the_ban_name like :theBanName "
                    + "and rd.light_status=:lightStatus";
        }
        searchValue.remove("selType");
        String countSQL = "select count(1) from ("
                + searchSQL.replaceAll("(?i)\\basc\\b|\\bdesc\\b", "").replaceAll(
                        "(?i)order\\s+by\\s+\\S+(\\s*[,\\s*\\S+])*", "") + "  ) a ";
        return super.pageSearchByField(TbYsjdReportdangerVo.class, countSQL, searchSQL + " order by report_time desc ",
                searchValue, pager);
    }

    @Override
    public TbYsjdReportdangerVo getTbYsjdReportdangerVo(String id) throws SQLException {
        String sql = "SELECT rd.*,u.PERSON_NAME,u.head_pic,d.department_name AS community_name FROM tb_ysjd_reportdanger rd LEFT JOIN tb_qy_user_info u ON rd.creator_user = u.user_id LEFT JOIN tb_department_info d ON rd.community = d.id WHERE rd.id=:id";
        preparedSql(sql);
        setPreValue("id", id);
        return super.executeQuery(TbYsjdReportdangerVo.class);
    }

    @Override
    public List<TbYsjdReportdangerVo> searchTbYsjdReportdangerList(Map<String, Object> searchValue) throws SQLException {
        preparedSql(searchSQL);
        setPreValues(searchValue);
        return getList(TbYsjdReportdangerVo.class);
    }

    @Override
    public TbDepartmentInfoVO searchDepartmentInfoVO(String deptFullName) throws SQLException {
        String sql = "select * from tb_department_info where dept_full_name=:deptFullName ";
        preparedSql(sql);
        setPreValue("deptFullName", deptFullName);
        List<TbDepartmentInfoVO> list = getList(TbDepartmentInfoVO.class);
        if (!AssertUtil.isEmpty(list) && list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }

    @Override
    public List<TbYsjdBanVo> searchYsjdBanVo(Map<String, Object> paramMap) throws SQLException {
        String sql = "SELECT * FROM tb_ysjd_ban WHERE grid = :grid AND ban_address LIKE :architectureName ";
        if (paramMap.containsKey("architectureName")) {
            paramMap.put("architectureName", "%" + paramMap.get("architectureName") + "%");
        }
        return searchByField(TbYsjdBanVo.class, sql, paramMap);
    }

    @Override
    public List<TbYsjdDangerVo> searchYsjdDangerVo(String lightStatus) throws SQLException {
        String sql = "SELECT * FROM tb_ysjd_danger WHERE light_status=:lightStatus order by sort ";
        preparedSql(sql);
        setPreValue("lightStatus", lightStatus);
        return getList(TbYsjdDangerVo.class);
    }

    @Override
    public List<TbYsjdDangerCommentPo> getCommentsByUserID(String userId, String reportdangerId) throws Exception,
            BaseException {
        String sql = "select t.* from tb_ysjd_danger_comment t where 1=1 and t.reportdanger_id =:reportdangerId and t.creator =:userId order by t.create_time desc ";
        preparedSql(sql);
        setPreValue("reportdangerId", reportdangerId);
        setPreValue("userId", userId);
        return getList(TbYsjdDangerCommentPo.class);
    }

    @Override
    public List<TbYsjdRecipientVo> getDangerRecipient(String reportdangerId, String type) throws Exception,
            BaseException {
        StringBuffer sql = new StringBuffer(
                "select t.* from tb_ysjd_recipient t where t.reportdanger_id =:reportdangerId ");
        if (null != type) {
            sql.append(" and t.user_type =:type");
        }
        sql.append(" order by recipient_order ");
        preparedSql(sql.toString());
        setPreValue("reportdangerId", reportdangerId);
        if (null != type) {
            setPreValue("type", type);
        }
        return getList(TbYsjdRecipientVo.class);
    }

    public void updateRecipientTypeAndStatusByAskIdAndUserId(String askId, String userId, String type, String status)
            throws Exception, BaseException {
        StringBuffer sql = new StringBuffer(
                "update tb_ysjd_recipient set is_audit=:status where reportdanger_id=:askId and user_type=:type and user_id=:userId");
        preparedSql(sql.toString());
        setPreValue("type", type);
        setPreValue("status", status);
        setPreValue("askId", askId);
        setPreValue("userId", userId);
        executeUpdate();
    }

    public List<TbYsjdRecipientVo> getNotAuditUserById(String askId) throws Exception, SQLException {
        StringBuffer sql = new StringBuffer(
                "select t.* from tb_ysjd_recipient t where t.reportdanger_id =:askId  and t.user_type=:type and is_audit=:status");

        preparedSql(sql.toString());
        setPreValue("askId", askId);
        setPreValue("type", "0");
        setPreValue("status", "1");
        return getList(TbYsjdRecipientVo.class);
    }

    public void updateAskRecipientAuditStatusByAskId(String askId, String type, String status) throws Exception,
            BaseException {
        StringBuffer sql = new StringBuffer(
                "update tb_ysjd_recipient set is_audit=:status where reportdanger_id=:askId and user_type=:type");

        preparedSql(sql.toString());
        setPreValue("askId", askId);
        setPreValue("type", type);
        setPreValue("status", status);
        executeUpdate();
    }

    @Override
    public List<String> getDangerUser(Map<String, Object> paramMap) throws Exception, BaseException {
        StringBuffer sql = new StringBuffer(
                "SELECT user_id FROM tb_ysjd_community_user WHERE danger_id=:dangerId AND community_id=:communityId ");
        return searchByField(String.class, sql.toString(), paramMap);
    }

    @Override
    public List<TbYsjdReportdangerVo> getReportdangerVo() throws Exception, BaseException {
        StringBuffer sql = new StringBuffer("SELECT * FROM tb_ysjd_reportdanger WHERE handle_time IS NULL ");
        preparedSql(sql.toString());
        return getList(TbYsjdReportdangerVo.class);
    }

    /**
     * 获取评论信息
     * <p>Description: TODO</p>
     * @param map
     * @param comments
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年8月25日</p>
     */
    public Pager getDangerComment(Map map, Pager comments) throws Exception, BaseException {
        if ((!map.containsKey("askId")) && (!map.containsKey("commentStatus"))) {
            throw new NonePrintException(ErrorCodeDesc.query_parameters_is_null.getCode(),
                    ErrorCodeDesc.query_parameters_is_null.getDesc());
        }
        String searchSql = "select t.comment_id,t.CONTENT,t.create_time,t.status,t.creator, t.reportdanger_id ,t.person_name,t.head_pic,t.type from tb_ysjd_danger_comment t where  t.reportdanger_id =:askId and status<>:commentStatus order by t.create_time desc";
        String countSql = "select count(1) from tb_ysjd_danger_comment t where t.reportdanger_id =:askId and status<>:commentStatus";
        return pageSearchByField(TbYsjdDangerCommentVo.class, countSql, searchSql, map, comments);
    }
    
    /**
     * 查询楼栋除当前转灯信息外其他的隐患亮灯信息中最严重的亮灯情况
     * <p>Description: TODO</p>
     * @param theBan 楼栋ID
     * @param id 当前隐患ID
     * @return
     * @throws SQLException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年8月29日</p>
     */
    @Override
    public TbYsjdReportdangerVo getTbYsjdReportdangerVo(String theBan,String id) throws SQLException {
        String sql = "SELECT * FROM tb_ysjd_reportdanger rd WHERE rd.the_ban=:theBan AND rd.status<3 AND id<>:id ORDER BY rd.light_status DESC LIMIT 1";
        preparedSql(sql);
        setPreValue("theBan", theBan);
        setPreValue("id", id);
        return super.executeQuery(TbYsjdReportdangerVo.class);
    }

    /**
     * 查询上报处理信息
     * <p>Description: TODO</p>
     * @param reportdangerId 上报ID
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年8月30日</p>
     */
    @Override
    public List<TbYsjdApprovalVo> getApprovalVoList(String reportdangerId) throws Exception, BaseException {
        StringBuffer sql = new StringBuffer("SELECT * FROM tb_ysjd_approval WHERE reportdanger_id=:reportdangerId order by sort");
        preparedSql(sql.toString());
        setPreValue("reportdangerId", reportdangerId);
        return getList(TbYsjdApprovalVo.class);
    }
    
    /**
     * 查询隐患统计
     * <p>Description: TODO</p>
     * @param reportdangerId 上报ID
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年9月1日</p>
     */
    @Override
    public List<CountDangerVo> searchCountDangerVoList(Map<String, Object> paramMap) throws Exception, BaseException {
        StringBuffer sql = new StringBuffer("");
        sql.append("SELECT d.department_name AS title,rd.community,'限期内整治率' AS title_Small_Left,'超时整治率' AS title_Small_Right,COUNT(1) AS count_num, ");
        sql.append("(SUM(CASE WHEN rd.overtime_status = '0' AND rd.status = 3 THEN 1 ELSE 0 END)/SUM(CASE WHEN rd.overtime_status = '0' THEN 1 ELSE 0 END))*100 AS progress_Left, ");
        sql.append("(SUM(CASE WHEN rd.overtime_status = '1' AND rd.status = 3 THEN 1 ELSE 0 END)/SUM(CASE WHEN rd.overtime_status = '1' THEN 1 ELSE 0 END))*100 AS progress_Right, ");
        sql.append("SUM(CASE WHEN rd.overtime_status = '0' AND rd.status = 3 THEN 1 ELSE 0 END) AS left_Handle, ");
        sql.append("SUM(CASE WHEN rd.overtime_status = '0' AND rd.status < 3 THEN 1 ELSE 0 END) AS left_Untreated, ");
        sql.append("SUM(CASE WHEN rd.overtime_status = '1' AND rd.status = 3 THEN 1 ELSE 0 END) AS right_Handle, ");
        sql.append("SUM(CASE WHEN rd.overtime_status = '1' AND rd.status < 3 THEN 1 ELSE 0 END) AS right_Untreated  ");
        sql.append("FROM tb_ysjd_reportdanger rd LEFT JOIN tb_department_info d ON rd.community = d.id ");
        sql.append("WHERE rd.report_type = '0' and rd.creator_time >:startTime AND creator_time <:endTime GROUP BY community ");
        if(paramMap.containsKey("overtimeStatus")){//按类型查询
            sql = new StringBuffer("");
            sql.append("SELECT rd.describes AS title,rd.community, tab.node_name AS title_Small_Left,COUNT(1) AS count_num, ");
            sql.append("(SUM(CASE WHEN rd.status = 3 THEN 1 ELSE 0 END)/COUNT(1))*100 AS progress_Left, ");
            sql.append("SUM(CASE WHEN rd.status = 3 THEN 1 ELSE 0 END) AS left_Handle, ");
            sql.append("SUM(CASE WHEN rd.status < 3 THEN 1 ELSE 0 END) AS left_Untreated ");
            sql.append("FROM tb_ysjd_reportdanger rd left join tb_ysjd_danger yd on rd.danger_type = yd.id LEFT JOIN ");
            sql.append("(SELECT ref_id,node_name FROM tb_qy_flow_branch_audit_log WHERE node_name IN ('派出所','社区工作站','消安委办')) tab ON rd.id = tab.ref_id  ");
            sql.append("WHERE rd.report_type = '0' AND rd.overtime_status=:overtimeStatus and rd.community=:community and rd.creator_time >:startTime AND rd.creator_time <:endTime ");
            sql.append("GROUP BY rd.danger_type  order by yd.sort ");
        }
        return searchByField(CountDangerVo.class, sql.toString(), paramMap);
    }
    
    
    /**
     * 整治情况统计表
     * <p>Description: TODO</p>
     * @param paramMap 
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年9月1日</p>
     */
    @Override
    public List<CountDangerVo> searchMgrCountDangerVoList(Map<String, Object> paramMap) throws Exception, BaseException {
        StringBuffer sql = new StringBuffer("");
        sql.append("SELECT d.department_name AS community_Name,rd.community,rd.danger_type,rd.describes,tab.node_name AS handle_dept,COUNT(1) AS count_num, "); 
        sql.append("(SUM(CASE WHEN rd.overtime_status = '0' AND rd.status = 3 THEN 1 ELSE 0 END)/SUM(CASE WHEN rd.overtime_status = '0' THEN 1 ELSE 0 END))*100 AS progress_Left, ");  
        sql.append("(SUM(CASE WHEN rd.overtime_status = '1' AND rd.status = 3 THEN 1 ELSE 0 END)/SUM(CASE WHEN rd.overtime_status = '1' THEN 1 ELSE 0 END))*100 AS progress_Right,  "); 
        sql.append("SUM(CASE WHEN rd.overtime_status = '0' AND rd.status = 3 THEN 1 ELSE 0 END) AS left_Handle,  "); 
        sql.append("SUM(CASE WHEN rd.overtime_status = '0' AND rd.status < 3 THEN 1 ELSE 0 END) AS left_Untreated,  "); 
        sql.append("SUM(CASE WHEN rd.overtime_status = '1' AND rd.status = 3 THEN 1 ELSE 0 END) AS right_Handle, "); 
        sql.append("SUM(CASE WHEN rd.overtime_status = '1' AND rd.status < 3 THEN 1 ELSE 0 END) AS right_Untreated   "); 
        sql.append("FROM tb_ysjd_reportdanger rd LEFT JOIN tb_department_info d ON rd.community = d.id  LEFT JOIN "); 
        sql.append("(SELECT ref_id,node_name FROM tb_qy_flow_branch_audit_log WHERE node_name IN ('派出所','社区工作站','消安委办')) tab ON rd.id = tab.ref_id  ");   
        sql.append("WHERE rd.report_type = '0' AND rd.creator_time >:startTime AND creator_time <:endTime GROUP BY rd.community,rd.danger_type  ORDER BY rd.community ");
        return searchByField(CountDangerVo.class, sql.toString(), paramMap);
    }
   
    /**
     * 整治情况汇总表
     * <p>Description: TODO</p>
     * @param reportdangerId 上报ID
     * @return
     * @throws Exception
     * @throws BaseException
     * <p>Author: 邹乐乐  </p>
     * <p>Date: 2017年9月1日</p>
     */
    @Override
    public Pager searchSummaryDangerVoPager(Map searchValue, @Security(encode = "") Pager pager) throws Exception, BaseException {
        StringBuffer sql = new StringBuffer("");
        sql.append("SELECT rd.id,yb.community,yb.community_name,yb.grid,yb.grid_name,yb.ban_address,rd.address, ");   
        sql.append("yb.owner,yb.owner_phone,rd.describes,rd.creator_time,(CASE WHEN rd.overtime_status = '0'  ");   
        sql.append("AND rd.status = 3 THEN '已整治' WHEN rd.overtime_status = '0' AND rd.status < 3 THEN '处理中' ");   
        sql.append("WHEN rd.overtime_status = '1' AND rd.status = 3 THEN '超时已整治' ELSE '超时处理中' END) AS status_desc, ");   
        sql.append("rd.handle_time ,rd.result ,rd.remark FROM tb_ysjd_reportdanger rd ");   
        sql.append("LEFT JOIN tb_ysjd_ban yb ON rd.the_ban = yb.ID ");   
        sql.append("WHERE 1=1 and rd.creator_time >:startTime AND rd.creator_time <:endTime ");
        String countSQL = "select count(1) from ("
                + sql.toString().replaceAll("(?i)\\basc\\b|\\bdesc\\b", "").replaceAll(
                        "(?i)order\\s+by\\s+\\S+(\\s*[,\\s*\\S+])*", "") + "  ) a ";
        return super.pageSearchByField(SummaryDangerVo.class, countSQL, sql + " ORDER BY rd.creator_time desc ",
                searchValue, pager);
    }
}
